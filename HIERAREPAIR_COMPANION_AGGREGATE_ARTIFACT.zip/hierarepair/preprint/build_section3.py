#!/usr/bin/env python3
"""Generate Section 3 evidence artifacts from frozen P-3 JSON only."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    Image,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


EXPECTED_LATTICE_SHA256 = (
    "009e54e3cc5b41289fb140a28e05aaaabb86d72292ffb824523a4298ba3c3e7e"
)
EXPECTED_AUDIT_SHA256 = (
    "8ddbb5a8701ec538394cfcc65984213215c0540f9520c7792c2259e1663d2a4e"
)
EXPECTED_P2_AUDIT_SHA256 = (
    "c92ec5eafeadb49990dab03f4d37c43c55df74e5a182da1bd6085fc7b6e79051"
)
SOURCE_ORDER = [
    "doc2dial",
    "myfixit",
    "human_knowhow",
    "openpi",
    "wiqa",
    "xwlp",
]
SOURCE_LABELS = {
    "doc2dial": "Doc2Dial",
    "myfixit": "MyFixit",
    "human_knowhow": "Human Know-How",
    "openpi": "OpenPI",
    "wiqa": "WIQA",
    "xwlp": "X-WLP",
}
LAYER_ORDER = ["C2", "C3", "C5"]
LAYER_LABELS = {
    "C2": "Content-only (C2)",
    "C3": "Container-only (C3)",
    "C5": "Union (C5)",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_verified(path: Path, expected: str) -> dict[str, Any]:
    actual = sha256(path)
    if actual != expected:
        raise ValueError(
            f"hash mismatch for {path}: expected {expected}, found {actual}"
        )
    return json.loads(path.read_text(encoding="utf-8"))


def select_rows(lattice: dict[str, Any]) -> list[dict[str, Any]]:
    eligible = lattice["sources"]["gate_eligible"]
    if set(eligible) != set(SOURCE_ORDER):
        raise ValueError(f"unexpected gate-eligible sources: {eligible}")
    selected = [
        row
        for row in lattice["records"]
        if row["source"] in SOURCE_ORDER and row["config"] in LAYER_ORDER
    ]
    by_key = {(row["source"], row["config"]): row for row in selected}
    if len(selected) != 18 or len(by_key) != 18:
        raise ValueError(
            f"expected one C2/C3/C5 row for six sources, found {len(selected)}"
        )
    return [
        by_key[(source, config)]
        for source in SOURCE_ORDER
        for config in LAYER_ORDER
    ]


def format_share(value: float) -> str:
    return f"{value:.6f}"


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = [
        "source",
        "layer",
        "config",
        "tau",
        "n_components",
        "top1_share_units",
        "effective_components",
    ]
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    "source": SOURCE_LABELS[row["source"]],
                    "layer": LAYER_LABELS[row["config"]],
                    "config": row["config"],
                    "tau": row["tau"],
                    "n_components": row["n_components"],
                    "top1_share_units": repr(row["top1_share_units"]),
                    "effective_components": repr(row["effective_components"]),
                }
            )


def write_values(
    path: Path,
    by_key: dict[tuple[str, str], dict[str, Any]],
    audit: dict[str, Any],
    p2_audit: dict[str, Any],
) -> None:
    gate = audit["gate"]
    if gate["qualifying_sources"] != ["myfixit", "doc2dial"]:
        raise ValueError(f"unexpected qualifying sources: {gate}")
    known = set(p2_audit["gate"]["qualifying_sources"])
    additional = set(gate["qualifying_sources"]) - known
    if known != {"myfixit"} or additional != {"doc2dial"}:
        raise ValueError("unexpected known/additional qualifier identity")
    screened = int(audit["n_candidate_sources_screened"])
    values = {
        "DocDialContentShare": by_key[("doc2dial", "C2")][
            "top1_share_units"
        ],
        "DocDialContainerShare": by_key[("doc2dial", "C3")][
            "top1_share_units"
        ],
        "DocDialUnionShare": by_key[("doc2dial", "C5")]["top1_share_units"],
        "DocDialUnionComponents": by_key[("doc2dial", "C5")]["n_components"],
        "DocDialUnionEffective": by_key[("doc2dial", "C5")][
            "effective_components"
        ],
        "MyFixitContentShare": by_key[("myfixit", "C2")]["top1_share_units"],
        "MyFixitContainerShare": by_key[("myfixit", "C3")][
            "top1_share_units"
        ],
        "MyFixitUnionShare": by_key[("myfixit", "C5")]["top1_share_units"],
        "MyFixitUnionComponents": by_key[("myfixit", "C5")]["n_components"],
        "MyFixitUnionEffective": by_key[("myfixit", "C5")][
            "effective_components"
        ],
        "WIQAContentShare": by_key[("wiqa", "C2")]["top1_share_units"],
        "WIQAContainerShare": by_key[("wiqa", "C3")]["top1_share_units"],
        "WIQAUnionShare": by_key[("wiqa", "C5")]["top1_share_units"],
        "WIQAContentEdges": by_key[("wiqa", "C2")]["n_edges"],
    }
    lines = [
        "% Generated by build_section3.py from frozen JSON; do not edit.",
        rf"\newcommand{{\QualifyingSources}}{{{gate['n_qualifying_sources']}}}",
        rf"\newcommand{{\EligibleSources}}{{{len(audit['gate_eligible_sources'])}}}",
        rf"\newcommand{{\QualifyingRatio}}{{{gate['n_qualifying_sources']}/{len(audit['gate_eligible_sources'])}}}",
        rf"\newcommand{{\QualifyingFamilies}}{{{gate['n_qualifying_provenance_families']}}}",
        rf"\newcommand{{\CandidateSourcesScreened}}{{{screened}}}",
        rf"\newcommand{{\AdditionalQualifyingSources}}{{{len(additional)}}}",
        r"\newcommand{\StressCriterion}{A1}",
        r"\newcommand{\CriteriaATwoToAFour}{A2--A4}",
    ]
    for name, value in values.items():
        if name.endswith("Share"):
            rendered = f"{100 * float(value):.2f}\\%"
        elif name.endswith("Effective"):
            rendered = f"{float(value):.3f}"
        else:
            rendered = f"{int(value):,}"
        lines.append(rf"\newcommand{{\{name}}}{{{rendered}}}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_latex_table(path: Path, rows: list[dict[str, Any]]) -> None:
    near_taus = {
        float(row["tau"])
        for row in rows
        if row["config"] in {"C2", "C5"} and isinstance(row["tau"], (int, float))
    }
    if len(near_taus) != 1:
        raise ValueError(f"unexpected C2/C5 tau values: {near_taus}")
    core_tau = next(iter(near_taus))
    lines = [
        "% Generated by build_section3.py from frozen JSON; do not edit.",
        r"\begin{table}[t]",
        r"\centering",
        rf"\caption{{Closure metrics for the gate-eligible sources. C2 and C5 use the frozen near-duplicate threshold $\tau={core_tau:g}$; C3 uses exact container identity. $N_{{\mathrm{{eff}}}}=(\sum_j p_j^2)^{{-1}}$ for component unit shares $p_j$.}}",
        r"\label{tab:section3-lattice}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{5pt}",
        r"\begin{tabular}{llrrr}",
        r"\toprule",
        r"Source & Layer & Components & Largest share & $N_{\mathrm{eff}}$ \\",
        r"\midrule",
    ]
    last_source = None
    for row in rows:
        source = row["source"]
        if last_source is not None and source != last_source:
            lines.append(r"\addlinespace[2pt]")
        source_text = SOURCE_LABELS[source] if source != last_source else ""
        lines.append(
            f"{source_text} & {LAYER_LABELS[row['config']]} & "
            f"{row['n_components']:,} & {format_share(row['top1_share_units'])} & "
            f"{row['effective_components']:.3f} \\\\"
        )
        last_source = source
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{table}"])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def build_figure(
    project_root: Path,
    output_root: Path,
    pdf_path: Path,
    png_path: Path,
    by_key: dict[tuple[str, str], dict[str, Any]],
    qualifiers: set[str],
    tectonic: str | None,
    pdftoppm: str | None,
) -> None:
    """Delegate the publication figure to the embedded-font native-LaTeX builder.

    The ReportLab implementation below is retained only as inaccessible historical
    source context for the earlier review figure. This return prevents it from
    generating the current Figure 1.
    """
    command = [
        sys.executable,
        str(project_root / "scripts/build_section3_figure.py"),
        "--project-root",
        str(project_root),
        "--output-root",
        str(output_root),
    ]
    if tectonic:
        command.extend(["--tectonic", tectonic])
    if pdftoppm:
        command.extend(["--pdftoppm", pdftoppm])
    subprocess.run(command, check=True)
    if not pdf_path.is_file() or not png_path.is_file():
        raise RuntimeError("native-LaTeX Figure 1 builder produced no PDF or PNG")
    return


def add_page_number(canvas: Any, doc: Any) -> None:
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(colors.HexColor("#5F6670"))
    canvas.drawRightString(7.6 * inch, 0.45 * inch, f"Section 3 review - {doc.page}")
    canvas.restoreState()


def build_review_pdf(
    path: Path,
    figure_png: Path,
    rows: list[dict[str, Any]],
    audit: dict[str, Any],
    p2_audit: dict[str, Any],
    pdftoppm_path: str | None = None,
) -> None:
    by_key = {(row["source"], row["config"]): row for row in rows}
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="SectionTitle",
            parent=styles["Heading1"],
            fontName="Helvetica-Bold",
            fontSize=18,
            leading=22,
            spaceAfter=12,
            textColor=colors.HexColor("#20242A"),
        )
    )
    styles.add(
        ParagraphStyle(
            name="BodyCompact",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=10,
            leading=14,
            spaceAfter=9,
            alignment=TA_LEFT,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Caption",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=8,
            leading=10,
            spaceBefore=4,
            spaceAfter=8,
        )
    )
    doc = SimpleDocTemplate(
        str(path),
        pagesize=letter,
        rightMargin=0.58 * inch,
        leftMargin=0.58 * inch,
        topMargin=0.58 * inch,
        bottomMargin=0.62 * inch,
        title="Section 3 Review",
        author="",
    )
    dd_c2 = by_key[("doc2dial", "C2")]
    dd_c3 = by_key[("doc2dial", "C3")]
    dd_c5 = by_key[("doc2dial", "C5")]
    mf_c2 = by_key[("myfixit", "C2")]
    mf_c3 = by_key[("myfixit", "C3")]
    mf_c5 = by_key[("myfixit", "C5")]
    wiqa_c2 = by_key[("wiqa", "C2")]
    wiqa_c3 = by_key[("wiqa", "C3")]
    wiqa_c5 = by_key[("wiqa", "C5")]
    core_tau = float(by_key[("doc2dial", "C2")]["tau"])
    if not all(
        float(by_key[(source, config)]["tau"]) == core_tau
        for source in SOURCE_ORDER
        for config in ("C2", "C5")
    ):
        raise ValueError("inconsistent frozen near-duplicate threshold")
    ratio = (
        f"{audit['gate']['n_qualifying_sources']}/"
        f"{len(audit['gate_eligible_sources'])}"
    )
    known = set(p2_audit["gate"]["qualifying_sources"])
    additional = set(audit["gate"]["qualifying_sources"]) - known
    if known != {"myfixit"} or additional != {"doc2dial"}:
        raise ValueError("unexpected known/additional qualifier identity")
    story = [
        Paragraph(
            "3. Union-induced collapse appears in "
            f"{audit['gate']['n_qualifying_sources']} of "
            f"{len(audit['gate_eligible_sources'])} sources",
            styles["SectionTitle"],
        ),
        Paragraph(
            "Doc2Dial is the clearest case by collapse magnitude. Its largest "
            "component contains "
            f"{100 * dd_c2['top1_share_units']:.2f}% of units under the content-only "
            f"layer and {100 * dd_c3['top1_share_units']:.2f}% under the container-only "
            f"layer. Under transitive closure of their union, the share becomes "
            f"{100 * dd_c5['top1_share_units']:.2f}%. The union has "
            f"{dd_c5['n_components']:,} components and an effective component count "
            f"of {dd_c5['effective_components']:.3f}.",
            styles["BodyCompact"],
        ),
        Paragraph(
            "MyFixit shows a second, less extreme instance: "
            f"{100 * mf_c2['top1_share_units']:.2f}% (content-only) and "
            f"{100 * mf_c3['top1_share_units']:.2f}% (container-only) become "
            f"{100 * mf_c5['top1_share_units']:.2f}% under the union, with "
            f"{mf_c5['n_components']:,} components and an effective count of "
            f"{mf_c5['effective_components']:.3f}.",
            styles["BodyCompact"],
        ),
        Paragraph(
            "Under the frozen audit criteria, MyFixit is the only qualifying source "
            "whose individual layers both pass all four registered criteria. Each "
            "Doc2Dial individual layer fails only A1 and passes A2-A4.",
            styles["BodyCompact"],
        ),
        Image(str(figure_png), width=7.15 * inch, height=3.42 * inch),
        Paragraph(
            "<b>Figure 1.</b> Largest-component share under the two individual layers "
            "and their union for all six gate-eligible sources. The vertical axis is "
            "logarithmic. Highlighting marks the frozen source-gate outcome, not a "
            "causal explanation.",
            styles["Caption"],
        ),
        Paragraph(
            "WIQA is a negative case: its union share is "
            f"{100 * wiqa_c5['top1_share_units']:.2f}%, only modestly above "
            f"{100 * wiqa_c2['top1_share_units']:.2f}% and "
            f"{100 * wiqa_c3['top1_share_units']:.2f}% for its individual layers, "
            f"and its content layer contains only {wiqa_c2['n_edges']:,} edges. "
            "Union formation alone therefore does not entail collapse; "
            "cross-container content repetition must be present in the measured graph.",
            styles["BodyCompact"],
        ),
        Paragraph(
            f"The {ratio} value is a descriptive panel fraction, not an estimate from "
            "independent trials or a prevalence estimate. MyFixit was the previously "
            f"known qualifying source; among {audit['n_candidate_sources_screened']} "
            "additionally screened candidates, Doc2Dial was the sole qualifier. The "
            "two qualifying sources belong to two distinct provenance families, "
            "DOC2DIAL_GOV and IFIXIT.",
            styles["BodyCompact"],
        ),
        PageBreak(),
        Paragraph("Table 1. Source-by-layer closure metrics", styles["SectionTitle"]),
    ]
    table_data = [
        ["Source", "Layer", "Components", "Largest share", "Effective components"]
    ]
    for row in rows:
        table_data.append(
            [
                SOURCE_LABELS[row["source"]],
                LAYER_LABELS[row["config"]],
                f"{row['n_components']:,}",
                f"{row['top1_share_units']:.6f}",
                f"{row['effective_components']:.3f}",
            ]
        )
    table = Table(
        table_data,
        colWidths=[1.2 * inch, 1.45 * inch, 1.0 * inch, 1.1 * inch, 1.25 * inch],
        repeatRows=1,
        hAlign="LEFT",
    )
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E9EEF4")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#20242A")),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
                ("FONTSIZE", (0, 0), (-1, -1), 7.8),
                ("LEADING", (0, 0), (-1, -1), 9.4),
                ("ALIGN", (2, 1), (-1, -1), "RIGHT"),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("LINEBELOW", (0, 0), (-1, 0), 0.8, colors.HexColor("#505760")),
                ("LINEBELOW", (0, 1), (-1, -1), 0.25, colors.HexColor("#D9DDE3")),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8F9FB")]),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
        )
    )
    story.extend(
        [
            table,
            Spacer(1, 6),
            Paragraph(
                f"C2 and C5 use the frozen near-duplicate threshold tau = {core_tau:g}; "
                "C3 uses exact container identity. Effective components is the inverse "
                "Simpson concentration over component unit shares.",
                styles["Caption"],
            ),
        ]
    )
    doc.build(story, onFirstPage=add_page_number, onLaterPages=add_page_number)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--tectonic")
    parser.add_argument("--pdftoppm")
    args = parser.parse_args()
    lattice_path = args.project_root / "raw/phaseB/p3_edge_family_lattice.json"
    audit_path = args.project_root / "raw/phaseB/p3_audit_criteria.json"
    p2_audit_path = args.project_root / "raw/phaseB/p2_audit_criteria.json"
    lattice = load_verified(lattice_path, EXPECTED_LATTICE_SHA256)
    audit = load_verified(audit_path, EXPECTED_AUDIT_SHA256)
    p2_audit = load_verified(p2_audit_path, EXPECTED_P2_AUDIT_SHA256)
    rows = select_rows(lattice)
    by_key = {(row["source"], row["config"]): row for row in rows}
    qualifiers = set(audit["gate"]["qualifying_sources"])

    tables = args.output_root / "tables"
    figures = args.output_root / "figures"
    tables.mkdir(parents=True, exist_ok=True)
    figures.mkdir(parents=True, exist_ok=True)
    write_csv(tables / "section3_lattice.csv", rows)
    write_latex_table(tables / "section3_lattice.tex", rows)
    write_values(tables / "section3_values.tex", by_key, audit, p2_audit)
    build_figure(
        args.project_root.resolve(),
        args.output_root.resolve(),
        figures / "section3_union_collapse.pdf",
        figures / "section3_union_collapse.png",
        by_key,
        qualifiers,
        args.tectonic,
        args.pdftoppm,
    )
    build_review_pdf(
        args.output_root / "section3_review.pdf",
        figures / "section3_union_collapse.png",
        rows,
        audit,
        p2_audit,
        args.pdftoppm,
    )
    print("SECTION3_BUILD_OK")


if __name__ == "__main__":
    main()
