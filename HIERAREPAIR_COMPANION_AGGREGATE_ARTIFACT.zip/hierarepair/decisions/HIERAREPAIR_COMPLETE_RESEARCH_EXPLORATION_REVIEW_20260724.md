# HieraRepair / Route C 完整研究探索档案

**用途：** 交给外部技术审阅者（Claude）独立检查研究方向、创新性、证据充分性、失败解释、WSDM Main Track 可行性与下一步优先级。  
**项目目标会议：** WSDM 2027 Main Track。  
**权威科学计划：** `WSDM2027_HIERAREPAIR_MAIN_TRACK_MASTER_PLAN.md`，当前控制版本 v1.7.22，Section S 为有效主线。  
**档案截止：** 2026-07-24 EDT；包含 Hellbender C2 v0.4 stage 作业 `15301401` 的终态。  
**诚实边界：** 本文件区分真实结果、探索性信号、协议/容量审计、基础设施失败和尚未发生的实验。没有把排队、设计、部分日志或 synthetic test 写成科研结果。

## 1. 技术摘要：项目已从“训练更强检索器”收缩为“先证明评价合同是否可信”

项目最初从维修程序场景出发，希望研究 hierarchical/dependency-aware procedural retrieval：查询不仅要主题相关，还要同时满足父级目标、资源、步骤、状态或依赖关系。早期内部方案包括 DARHP、SGCR、RFCR、PIIR，以及 relation heads、latent anchor、soft-min conjunction、counterfactual negatives、violation localization 等组件。

经过数据审计、强基线 kill tests 和两轮 Deep Research，宽泛主张已经被主动退休。程序图检索、instruction/constraint-aware retrieval、relevant-but-invalid negatives、support/refute/unknown、local completeness、proof/certificate、anchor sets、marginalization、selective abstention、adaptive dimensions 等单项均有直接 prior art。项目现在不声称发明这些组件。

当前唯一活动路线是 **Route C：coverage、duplicate leakage 与 benchmark/evaluation-policy distortion audit**。核心可证伪问题是：

> 在异构分层程序来源中，未观察到的关系经常表示“来源没有覆盖”，而不是“关系为假”。把 missing 直接当 negative、按 unit/group 而非 duplicate component 划分数据，是否会系统性改变标签分布、可构造样本容量、检索评价指标和论文结论？

当前项目**没有训练任何 proposed model**。此前 GPU 工作全部是冻结模型的 inference-only baseline/shortcut evaluation。Route C C0/C1 是 deterministic complete-population CPU audit；C2 计划也是 deterministic CPU census，而不是训练。

截至本档案：

- MyFixit/X-WLP 完整分析宇宙为 **239,464 units、19,274 source groups、5,372 duplicate components**；
- C1 已独立复现，MyFixit/X-WLP 的 `UNRESOLVED / naive-negative` pair exposure 分别为 **0.844160 / 0.604631**，但这些是 policy exposure，不是 factual false-negative rate；
- MyFixit observed-support mass 的 top component share 为 **0.996103**，X-WLP 为 **0.127607**，显示极强 source asymmetry；
- C2 scientific core 已冻结并通过两位 result-blind reviewer，v0.4 protocol 为 **111/111**；
- 但 C2 尚无 empirical result：四次 immutable-stage setup 都在科学计算前失败，formal C2、preflight、GPU、query authoring、training、final collection 均未运行；
- 最新失败 `15301401` 已精确复现为 validator self-test 继承外层 `SLURM_*` 环境的 test-harness leak，不是数据或科学 Gate 失败。

因此，WSDM Main Track 当前是 **NOT_YET_GO**。最有价值的现有贡献是严谨的负结果、数据/评价现象和可重放审计合同；是否足够成为 WSDM Main 论文，取决于 C2 能否证明至少一种常见 policy 会稳定改变预注册结论，而不是只产生大但描述性的计数差异。

## 2. 当前到底在研究什么，训练什么，想得到什么结果

### 2.1 研究对象

对象不是“维修问答”本身，而是更一般的 **heterogeneous hierarchical procedures**：维修指南、实验流程、how-to graphs、步骤层级、资源/位置/前置关系等。维修只是最早且数据最完整的实例。

当前最小 grain 固定为：

`source → source_group → duplicate_component → unit → requested_value`

给定 source、anchor 和 relation interpretation，每个 candidate/requested value 只能进入：

- `SUPPORTED`：来源边或完整字段提供可重放 witness；
- `REFUTED`：来源给出显式 counter-witness，或 coverage、cardinality/exclusivity 和 sound negative-entailment rule 合法推出排除；
- `UNRESOLVED`：来源未声明、scope 不完整、版本/字段 universe 不清楚、mapping held，或无法合法推出负结论。

这些状态是 **source-evidence status**，不是现实世界真值。模型置信度、anchor ambiguity 和 coverage uncertainty 不能混成一个标签。

### 2.2 当前没有训练

项目到目前只运行过：

- BM25、Jaccard、symbolic oracle、automatic-anchor、weakest-link、graph PPR 等非训练 baseline；
- all-mpnet、MiniLM、Qwen3 Embedding/Reranker、Promptriever、FollowIR 等冻结 revision 的 inference；
- 本地 ONNX MiniLM semantic probes；
- PCA/partial-dot adaptive-dimension audit；
- deterministic compiler、component、capacity、coverage、leakage 和 replay validators。

没有 fine-tuning，没有 learned HieraRepair model，没有 final train/dev/test collection，也没有可以报告为 proposed-method gain 的结果。

### 2.3 想得到的正结果

WSDM-supporting C2 结果至少需要同时满足：

1. 至少一种 common/published-style labeling 或 split policy 会改变一个预注册、可报告的结论；
2. effect 在 exact-edge 与 4/5 bucket sensitivities 下稳健；
3. effect 不能只由 MyFixit giant component、empty-list convention、X-WLP fallback/multi-match 或选择性 seed 解释；
4. 两来源方向一致，或差异可由冻结的 coverage/component/family statistics 解释；
5. 同一个 declarative compiler 能处理两个来源，而不是两个特制清洗脚本；
6. witness、counter-witness、min-cut/failure certificate 和 conclusion replay 可逐行重放；
7. 结果相对于 open-world/completeness/evaluation-leakage prior art 仍体现 procedural-IR operationalization gap。

### 2.4 同样有价值的负结果

如果 C2 表明 effect 小、不稳定、只在一个来源/一个 convention 成立，或不改变真实结论，则应停止 WSDM method-performance 叙事，考虑 data/resource、Findings、negative result 或内部技术报告。项目明确禁止用新增模型实验“救”一个失败的 measurement claim。

## 3. 方向演化：为什么不断改题不是漂移，而是 Gate 驱动的收缩

### 3.1 初始 HieraRepair：维修指南中的 scope / goal / state

最早设想是从 MyFixit 建立层级维修检索任务，审核 scope、compatibility、goal、state 和步骤依赖。最初 review package 曾计划让研究负责人审核约 70 个案例，但用户不是维修或语义专家，也没有合格专家资源。项目随后明确：不同型号不等于不兼容，同一 family 不等于兼容，步骤相邻不等于状态依赖，标题中的 remove/replace 不能决定 goal。

review package v0.3 因此取消研究负责人逐例标注，只保留 30 个自动 metadata checks、40 个需要两名独立语义标注者的案例和 8 个需要维修领域证据的案例。由于没有满足 qualification/independence 的标注者，这条人工 gold 路线没有被伪装为已完成；项目转向可由原始字段和机器规则审计的来源。

### 3.2 Dependency-Aware Retrieval：从维修扩展到一般程序文档

项目随后认识到层级/依赖结构不限于维修：实验流程、使用说明、business procedures、how-to graphs、state transitions 都可能需要 dependency-aware retrieval。工作标题一度收缩为 “Dependency-Aware Retrieval for Hierarchical Procedures”。

该标题帮助打开数据搜索，但 Deep Research 显示它太宽：procedural retrieval、graph retrieval、hierarchical retrieval 和 constraint following 已有大量直接工作，不能作为 novelty。

### 3.3 SGCR / RFCR / PIIR：方法化尝试及退休原因

历史 SGCR 设想包括 semantic backbone、latent anchor posterior、active relation mask、relation-specific applicability experts、soft-min conjunction 和 violation-localization head。RFCR 进一步尝试 relation-factorized counterfactual retrieval；PIIR 尝试 source-proof contrast 和 intervention-style identifiability。

这些方向被退休的原因不是代码失败，而是 prior-art collision 和识别假设不足：

- FollowIR、FollowTable、Promptriever 已覆盖 beyond-relevance instruction/constraint following；
- CausalNeg、Energy-Based Constraint Networks、OrLog、NS-IR 已覆盖 requirement-wise negatives、constraint branches、组合和定位；
- STaRK、AnchorRAG、ARK、GraphOracle、Relink、T-Retriever 已覆盖 textual-relational、latent-anchor、cross-domain 和 hierarchical graph retrieval；
- 没有 SCM、干预分布和 identifiability theorem 时，source-preserving edge contrast 不能叫 causal intervention。

因此 SGCR/RFCR/PIIR 只保留为历史 baseline/component library，不再控制论文创新点。

### 3.4 Deep Research 2.1：剩余安全假设

有界 Deep Research 编码了 63 条一手/官方证据，并把 24 个候选方向逐一映射到最近工作。没有发现一篇工作完整覆盖当前全契约，但“没有找到完整等价物”不等于 novelty 证明。

当前安全假设是：

> closed-world labeling 在异构程序来源中造成可测、source-asymmetric 的 coverage-induced label/policy distortion；把既有 scope-bounded local completeness 与 relation-specific sound negation 操作化为 candidate construction、evaluation 和 replay audit，可能改善评价有效性。

原 portfolio `1+3+5+11` 被保留为概念框架：

1. coverage-induced label-bias measurement/correction；
2. replayable witness/counter-witness；
3. equivalence-free composition/source-split evaluation；
4. proof-swap anti-shortcut。

方向 2（anchor ambiguity）只保留为已完成负审计；方向 4（proof marginalization）因 E2 证明前提不存在而删除。

### 3.5 E3c 与 E3r-1a 关闭方法路线，Route C 成为唯一活动路线

80-query controlled benchmark 被强 lexical/semantic shortcuts 部分解决；重新设计的 300-query confirmation 又在完整 universe 的 component-safe pool feasibility 阶段数学不可行。因此当前不再生成 replacement queries，不训练方法，不扩 final collection。Route C 不是包装失败，而是把 benchmark feasibility 和 evaluation validity 本身作为研究对象。

## 4. 数据集全景与实际使用边界

### 4.1 MyFixit：主来源，但 coverage 极不均匀

官方 GitHub archive 固定在 commit `c15356c15703880d608c9d49d65905f7055956d8`。下载 archive 为 44,386,147 bytes，SHA-256 `8139f05b...e186`；解压 41 files / 285,236,334 bytes，其中 15 个 JSONL 共 171,010,129 bytes。许可为 CC BY-NC-SA 3.0。

全量 schema audit：

- 18,995 guides；
- 235,549 steps；
- 468,384 line items；
- 15/15 JSONL 全部解析，0 parse errors；
- Guidid 18,995/18,995 唯一；
- StepId 只有 93,472 unique，34,991 duplicate values、142,077 extra occurrences，不能作为 row key；
- 35,235 normalized duplicate step-text groups；
- `Text_raw` 与 `Lines` 有 10,393 个实质 mismatch（4.41% comparable steps）；
- `Tools_annotated` 只出现于 38,032 steps，97.3% 来自 Mac；
- `Subject` 为空 965/18,995（5.08%）；
- README prose=31,601 manuals、类别表合计=30,694，而实验 JSONL=18,995，论文必须使用 measured corpus 数量。

E1 合法 coverage policy 只允许 Mac steps 且 `Tools_annotated` 是有效 list 时做 negative entailment。其他类别/缺失字段必须 `UNRESOLVED`。

### 4.2 X-WLP：第二个 refuted-capable core source

本地有 279 protocols、3,915 operations。严格 motif 是 `protocol → operation → physical input site/location family`。E1 中 1,630 operations coverage-complete、2,285 unresolved。X-WLP 是 MIT 许可、非 WikiHow 来源，是独立于 MyFixit 的第二来源。

关键语义边界：wet-lab site/location 和 repair tool 只共享抽象 execution-role interface，不是同一个 relation label。所有结果必须 source-first 报告。

### 4.3 WHPG 与 Human Know-How：正向结构丰富，但没有 refutation

WHPG 有 283 documents、6,642 nodes、7,341 edges；`supplement` 2,698 条与论文 Constraint 数一致，但混合 reason/condition/effect，不能整体升格 PRECONDITION。仓库缺少明确 dataset license，因此只做本地诊断。

Human Know-How 使用官方 9-of-11 高质量子集和 step links。strict motif audit 得到 66,629 个 same-procedure `DECOMPOSES + PRECONDITION` positive certificates 和 23,893 unresolved，但 0 explicit counter-witness。许可为 CC BY-NC 4.0。

WHPG + Human Know-How 合计：

- 92,272 ledger records；
- 68,360 strict supported motifs；
- 23,912 unresolved；
- 0 explicit counter-witness-capable motifs；
- positive replay=1.0。

它们可做 positive proof/certificate diagnostic，不能充当第三个 `REFUTED` 来源。

### 4.4 其他已下载/画像来源

- **COIN annotations**：180 tasks、11,827 videos、46,354 temporal step segments；只下载 annotation，不下载视频。task→step 是 hierarchy；时间相邻是 observed order，不是依赖。CC BY-NC 4.0。
- **OpenPI**：4,050 step records、29,928 accepted state-change answers；适合 state-transition diagnostic，不与当前 hierarchy/resource gold 直接合并。MIT。
- **WIQA**：39,705 questions，适合 causal diagnostic；当前 archive/license 不足以进入可发布 core。
- **Doc2Dial**：488 documents、4,796 dialogues、61,078 turns；30,653 grounded user turns，92.2% 不逐字包含 grounding span，Jaccard median=0.125。它是很好的 non-exact human-language bridge，但 fuzzy condition/solution labels 不能作为 typed refutation gold。CC BY 3.0 with attribution。
- **PKR-QA**：49,471 QA rows、5,285 KG nodes、12,484 relationships；COIN-derived、mixed provenance、模板和 split overlap 问题使其只适合 diagnostic。
- **GFPDR Procedural Questions**：官方代码已固定，1.69 GB 数据因未声明 dataset license 而未下载；其论文直接构成 procedural-retrieval prior-art collision。
- **Materials Science Procedural Text Corpus**：许可可用 fallback，未下载。
- **Kyoto Recipe Flow Graph**：corpus license/original-text dependency 未解决，未下载。
- **TARA/OHO**：论文声称学术发布，但未找到官方下载入口，未下载。

### 4.5 外部依赖/规划数据审计

- **Action Conditions**：650 instructional samples，7,191 action phrases，人工 PRECONDITION/POSTCONDITION links；是自然 dependency diagnostic 的强候选，但 public release 不完整、data redistribution license 不清楚，`NULL` 也不等于 refutation。
- **Proc2PDDL**：27 domains、95 problems；可做小型 executable kill test，但 PDDL failure/success 不等于 textual refutation/support。
- **PAGED**：3,394 doc-graph pairs、37,226 sentences、36,537 actions、36,438 sequence flows、10,598 condition flows、5,807 constraint flows；适合 typed control-flow scale stress，但文本部分经过模板/生成/改写，没有 source-relative coverage/refutation labels。
- **GOLD**：103 domains、1,100 tasks、1,086 actions，混合 WikiHow、ALFRED-L、OpenPI+、Proc2PDDL；许可和 canonical packaging 未关闭，只 hold 作 diagnostic。
- **DIGGER**：方法，不是数据集。

没有一个外部来源可以直接替换 MyFixit/X-WLP 并提供 native `SUPPORTED/REFUTED/UNRESOLVED` retrieval gold。

### 4.6 统一 canonical corpus 的意义和限制

八来源 canonical corpus：

- 812,693 nodes；
- 1,070,061 edges；
- 0 integrity errors；
- 50,022 eligibility warnings；
- crosswalk v0.3 的 31 rows 中 19 rows 可直接观测。

通过只说明结构转换一致，不说明 task、label 或 WSDM novelty 已成立。document order 没有被提升为 NEXT/PRECONDITION；missing resource fields 没有被变成 negative。

## 5. 实验与决策时间线

| 阶段 | 数据/规模 | 做了什么 | 真实结论 | 后续影响 |
|---|---:|---|---|---|
| Step 0.1–0.2 | MyFixit 15 JSONL | 下载、hash、schema/ID/text audit | parser 可用但有 documented issues | 禁止用 README 数量和 StepId 单键 |
| Gate D0 | 13 source candidates | license/schema/query/proof/leakage readiness | NOT_READY；typed scale/Q1-Q3 provenance fail | pilot 未批准 |
| 44Q fixture | 44 queries / 2,200 pairs | MyFixit + X-WLP raw proof replay | 0 proof errors；全部 controlled Q2 | 只作 kill test |
| Structure kill test | 44Q | automatic anchor、weakest-link、PPR | weakest-link R@1=.5227；PPR=0 | conjunction 有信号但未解决 |
| Stage A | 44Q / 9 methods | BM25、MPNet、Qwen、MiniLM、oracle | typed Qwen R@1=.6136 | 强 7B confirmation 必需 |
| Stage B | 44Q / 5 methods | Promptriever/FollowIR | strongest pooled=.6364，MyFixit=.50，X-WLP=.80 | 旧任务仍有 headroom；无 proposed gain |
| E1 | 239,464 units | source×relation coverage compiler | 262,903 assertions，replay=1，missing-as-refuted=0 | 两来源三状态 capacity pass |
| E2 | 44Q / 2,088 classes | full-observable ambiguity census | 106 non-singletons 全 duplicate-only；metric gap=0 | 删除 ambiguity/M1/marginalization |
| E3a/b | 80Q / 4,000 pairs | point-anchor protocol与 deterministic construction | replay=1；lexical R@1=.8625；3 proof swaps | 只允许一次 strong shortcut check |
| E3c | 80Q / 3 frozen models | semantic shortcut inference | HKK source R@1=.90 触发 STOP | 禁止 E3d、扩量和训练 |
| Local semantic probe | 80Q | hierarchical MiniLM/state resolver | semantic signal，但 lexical 更强、n=8 | 不命名方法，不宣称 gain |
| E3y | 80Q×50×2 views | PCA/adaptive exact scoring | fixed-128 fidelity fail；total compute > baseline | 低维方向 local stop |
| E3r-0/1a | full universe | blind-query/source-fit/component-safe pool feasibility | MyFixit development 数学不可行 | Route B 取消，Route C 激活 |
| C0/C1 | full universe | coverage/policy/concentration census | source asymmetry 与 exposure 被独立复现 | C2 warranted，WSDM 仍未 GO |
| C2 protocol | 8 policies / full census design | exact compiler/capacity/hardness/Gate contract | scientific core frozen；无 empirical result | 等 immutable stage/preflight/formal |

## 6. 44-query 早期 benchmark：什么成功，什么没有成功

固定 fixture 包含 MyFixit 24 queries、X-WLP 20 queries，每 query 50 candidates，共 2,200 pairs。全部 candidate labels 可回到原始字段，0 proof/label errors。优点是可重放；缺点是 query 全为 controlled Q2，不是 source-authored/user-authored。

### 6.1 CPU structure baselines

- typed BM25：R@1=.2727，MRR=.4196；
- automatic-anchor additive：R@1=.5000；
- automatic-anchor weakest-link：R@1=.5227，MRR=.5909；
- hard intersection：R@1=.3409；
- typed graph PPR：R@1=0。

weakest-link 相对 typed BM25 的 paired ΔR@1=.2500，95% bootstrap `[.1136,.3864]`。PPR 的 additive diffusion 无法表达“同时满足两个 anchor/relations”，但这只否定该 PPR 构造。

### 6.2 Stage A small-model kill test

R@1：

- BM25 raw .0909；
- BM25 typed .2727；
- all-mpnet raw .1818；
- Qwen3 embedding raw .1364；
- Qwen3 embedding instruction .2045；
- MiniLM cross-encoder .1364；
- Qwen3 reranker generic .1818；
- Qwen3 reranker typed instruction .6136；
- symbolic oracle 1.0。

typed Qwen 是 strongest non-oracle，但相对 weakest-link 的 ΔR@1=.0909、interval `[-.0227,.2051]`，不能声称结构已被稳定超越。MyFixit/X-WLP R@1=.4583/.8000，来源难度差异很大。

### 6.3 Stage B strong 7B confirmation

五方法 complete manifest 已回收并独立复算：

- Promptriever raw pooled R@1=.2273；
- Promptriever typed pooled=.6364，MyFixit=.5000，X-WLP=.8000，MRR=.7260；
- FollowIR raw=.1818；
- FollowIR typed=.2500；
- FollowIR typed relation-probe=.3409，violation-only Macro-F1=.2256。

结论是 old task retains headroom，但没有 proposed-method gain。Stage B 也没有 coverage/three-state gold，不能验证 Route C。

## 7. 强基线运行中的基础设施失败与修复

### 7.1 GPU 请求和 Slurm 操作

Hellbender 不接受含糊的 `gres:gpu:1`，必须请求具体 GPU 类型。`Requested node configuration is not available` 通常是资源组合不可用，不应误判为 job name 问题。`sbatch` socket timeout 也可能发生在 scheduler 已接受作业之后；项目后来规定先查 `squeue/sacct`，不得盲目重复提交。

### 7.2 Stage A Qwen3 reranker 失败

首次 Stage A 把 `Qwen/Qwen3-Reranker-0.6B` 当 generic sequence-classification CrossEncoder，生成未训练 `score.weight`，随后因无 padding token 在 batch>1 时报错。仅加 padding 会得到“能跑但科学无效”的随机 head，因此被拒绝。

修复为 model-author `AutoModelForCausalLM` yes/no next-token scoring、left padding、单 token label 校验和完整 metadata。修复后 A100 job `15194574` completed 0:0，九方法与 29 outputs 全部验证。

### 7.3 Stage B cache-path 失败

prefetch 使用显式 cache root 存储为 `models--...`，GPU job 只设置 `HF_HOME`，Transformers 离线查找却落到 `$HF_HOME/hub`，于是误报缺 `adapter_config.json`。修复是统一 `HF_HUB_CACHE` 并向每个 loader 传 `cache_dir`。该失败没有产生 Stage B 结果。

### 7.4 Stage B tokenizer 失败

cache 修复后 Promptriever 两方法跑完，但 FollowIR tokenizer 因 `sentencepiece`、`protobuf`、`tiktoken` 未显式安装而失败。部分 Promptriever 数值被标为 `LOG_ONLY_DIAGNOSTIC`，没有 complete manifest 时不进入 Gate。scheduled CPU smoke 后确认 exact cached revision、真实文本 tokenization 和 distinct true/false token IDs，最终 Stage B 才完整成功。

### 7.5 E3c launcher 环境失败

作业 `15262201` 因 batch shell 中不可用的 `module load` / `conda run` 依赖退出 `127:0`，无科学结果。修复为直接调用项目 Conda Python，37 checks 通过；唯一 environment-only retry 后 job `15266715` completed，并触发科学 STOP。

## 8. E1/E2：两个重要的“保留一个、删除一个”

### 8.1 E1 证明 coverage policy 可执行

MyFixit：

- 235,549 units；
- 37,005 complete；
- 198,544 unresolved；
- 257,358 compiled assertions。

X-WLP：

- 3,915 units；
- 1,630 complete；
- 2,285 unresolved；
- 5,545 compiled assertions。

合计 262,903 assertions，100% replay，0 missing-as-refuted。E1 证明 policy/label capacity，不证明 retrieval gain。

### 8.2 E2 证明 ambiguity component 没有价值

对 44 queries / 2,200 candidates，冻结所有 model-visible fields 后构造 2,088 classes：

- 1,982 singleton；
- 106 non-singleton；
- 106/106 duplicate-only；
- 0 status conflicts；
- 0 retained non-degenerate classes；
- 五个 Stage B methods 的 point/class R@1、MRR gap 全为 0。

按照预注册规则删除 ambiguity marginalization、M1 和 class-aware metrics。这是成功的组件淘汰，不是“实验没做出来”。

## 9. 80-query E3：构造成功，但 shortcut Gate 失败

E3a/b 冻结：

- 80 queries；
- MyFixit/X-WLP/Human Know-How=30/30/20；
- SUPPORTED/REFUTED/UNRESOLVED=20/20/40；
- construction/challenge/heldout=40/20/20；
- 4,000 candidate pairs；
- replay=1；
- missing-as-refuted=0；
- exact observation/source/parent leakage=0；
- readable fraction=1；
- lexical anchor R@1=.8625；
- template-only state accuracy=.5125；
- 3 个 natural legal proof-swap pairs。

E3c frozen inference：

- all-mpnet pooled R@1=.5375；
- Qwen3 embedding=.6875；
- Qwen3 typed reranker=.7125；
- Qwen3 reranker 在 Human Know-How source R@1=.9000，精确触发 `>=.90` stop。

postmortem 显示 HKK 的 20 queries 全部来自一个 `UNRESOLVED_REQUIRES` slice；lexical baseline 20/20，reranker 18/20。因此旧 80Q 是 shortcut diagnostic，不是困难 benchmark。阈值没有事后改成 `>.90`。

## 10. 语义计算探索：有信号，但没有独特方法或性能增益

### 10.1 Local semantic mechanism probe

使用 frozen all-MiniLM-L6-v2 ONNX，嵌入 10,848 unique views；40 construction、20 challenge、20 heldout；不训练。

- hierarchical MiniLM heldout anchor R@1=.80；
- flat MiniLM=.70；
- lexical Jaccard=.90；
- complete-scope semantic state accuracy=.75 vs coverage-only=.50；
- 但 heldout complete-scope 只有 n=8，difference bootstrap CI `[-.25,.625]`，McNemar p=.625；
- anchor-residual geometry 未被 preregistered challenge 选择；
- coverage gate 改变 3/3 proof-swap predictions，但只有 1/3 两端都正确。

结论：semantic endpoint understanding 可能有信号，但没有胜过 strongest lexical control，也没有 unique-method claim。

### 10.2 Adaptive low-dimensional “semantic impression” audit

用户提出用低维语义“印象”指明方向，需要时再恢复精确细节。相关 Deep Research 发现 MRL/Funnel Retrieval、AdANNS、2DMSE、FEXIPRO、ReadAgent、Adaptive-RAG 等已覆盖 generic coarse-to-fine dimensions、gist-to-detail 和 uncertainty-triggered retrieval。

本地 v0.2 使用 frozen hierarchical MiniLM scorer 和 source-balanced、future-group-exclusive PCA：

- full-384 R@1/R@5/MRR=.7750/.9500/.8589；
- PCA-128 full-top1 agreement=.8750，top-5 overlap=.7925，不能替代 full；
- adaptive algorithm 80/80 最终同 full top1，但只有 28/80 在 384D 前形成 bound singleton；
- 42/80 到 384D 才 singleton，10/80 依赖 full-score ID tie-break；
- candidate partial-dot MAC reduction=.282125，低于 .30 feasibility line；
- 加入理想 progressive dense query projection 后，50-candidate online MAC proxy=7.741875× baseline。

post-hoc 1,249-view PCA sensitivities把 partial-dot reduction 提高到 .4208–.4332，但 fixed-128 fidelity 仍失败，total proxy 仍 6.7188–6.8192×。因此该方向 local stop，仅保留为未来大 shortlist/corpus-scale baseline 假设。

## 11. E3r：为什么没有继续“再做更大一个 benchmark”

### 11.1 E3r-0 发现 query provenance 和 split 都不够

MyFixit/X-WLP 是唯一合法三状态 pair，但没有 native target-independent query layer。旧 80Q 全是 target-derived controlled paraphrases。

更严格检查还发现 candidate groups 跨 split：

- MyFixit 175 groups；
- X-WLP 216 groups；
- Human Know-How 118 groups。

这不表示旧 E3b 违反其原合同，但表示不能把它重新命名为 group-disjoint confirmation benchmark。

### 11.2 E3r-1a 在完整 universe 上证明 frozen design 不可行

完整 universe：

- MyFixit：235,549 units、18,995 groups、5,193 components；
- X-WLP：3,915 units、279 groups、179 components；
- 五类跨 split overlap 全为 0。

MyFixit giant component：

- 102,051 units；
- 4,462 groups；
- 占来源 43.3247%；
- 包含 36,764/37,005 complete units；
- 包含 20,585 supported-target units；
- 整体进入 confirmation。

因此 development 虽有 25,175 units，却只有 28 complete units、3 complete source groups；任意 requested tool 最多只有 2 个 supported groups，低于每 pool 冻结要求 5。MyFixit development 的 SUPPORTED/REFUTED/UNRESOLVED 三格全部 0/10；其他 9 cells 和 270/300 provisional pools 通过。

项目没有换 seed、拆 giant component、降 quota 或挑容易来源，而是冻结 `E3R1A_MODEL_FREE_FEASIBILITY_FAIL`，取消 Route B query benchmark，转 Route C。

## 12. Route C C0/C1：已得到什么，尚未得到什么

### 12.1 C0 冻结合法 claim

C0 46/46 checks 通过，只允许：

1. coverage census；
2. naive missing-as-negative exposure；
3. named split policy 下 duplicate leakage；
4. component-safe cell feasibility。

禁止把 exposure 称 false-negative rate，禁止 method gain、compatibility、natural-query quality 或 first claim。

### 12.2 C1 完整人口 census

MyFixit：

- units=235,549；
- complete=37,005；
- incomplete=198,544；
- licensed REFUTED pairs=2,272,501；
- UNRESOLVED pairs=12,309,728；
- naive-negative pairs=14,582,229；
- exposure=.844160。

X-WLP：

- units=3,915；
- complete=1,630；
- incomplete=2,285；
- licensed REFUTED pairs=17,930；
- UNRESOLVED pairs=27,420；
- naive-negative pairs=45,350；
- exposure=.604631。

source macro=.724395；pooled-last=.843417。MyFixit Mac-only policy slice exposure=.310125，所以 `.844160` 绝不能写成“84% 数据缺失”。

component concentration：

- MyFixit observed-value support top-1 share=.996103，effective components≈1.008；
- X-WLP=.127607，effective components≈39.43。

official tests、identity、input integrity 全通过；implementation-independent replay 138/138；artifact QA 219/219。C1 是可信描述性现象，不是 WSDM sufficiency。

## 13. C2：科学设计、实现审查与尚未运行的 formal census

C2 计划完整比较 naive、source/group-safe、component-safe policies，并加入：

- MyFixit empty-list policy；
- X-WLP fallback/multi-match；
- component edge-family variants；
- five fixed hash buckets；
- structural L1/L2/full-hardness capacity；
- exact min-cut failure certificates；
- source-first conclusion changes；
- 8-policy compiler replay ledger；
- unpaired component-variant robustness semantics。

scientific core 24 pointers、57,504 canonical bytes，SHA-256 `a5778ce4...e173`，在 v0.2–v0.4 之间保持不变。

### 13.1 实现 reviewer 抓到的真实问题

在任何 formal result 前，result-blind reviewers 先后阻止了：

- runner authorization bypass；
- falsely claimed near-`O(V*G²)` cache；
- count-only set completeness；
- incomplete 17-clause Gate replay；
- 约 170,257,300 repeated option-to-function memberships；
- understated counters；
- transient query 为每条创建 49-row witness；
- independent validator 把 6,909,733-row replay ledger 误当 8 summary rows；
- blob/sub-string matching 代替逐行 exact replay；
- capacity witness 最坏可达 87,000 witnesses / 4.35M nested rows却整体 materialize；
- conclusion layer 错把不同 component variants 的同编号 buckets 当 paired observations。

修复包括 policy-level option cache、真实 work counters、retained-edge-only witness、structural FAIL 后跳过 full hardness、streaming/disk-index replay、shared truth table、NO_ESTIMAND、mutation tests，以及 unpaired marginal-count formula。compiler tests 23/23、component tests 20/20、independent self-tests 45/45、scheduled evidence 56、recovery 37、synthetic E2E 均通过。

### 13.2 C2 四次 stage setup 失败

这些都发生在 formal scientific C2 前：

1. **job 15290127 / v0.2**：`/home/...` 与 canonical `/mnt/pixstor/...` 被 raw-string 比较；1 秒 exit 70。
2. **job 15290647 / v0.3**：提交时漏了 signed stage resource overrides，沿用 formal header 32 GiB/16h，被 stage guard 拒绝；1 秒 exit 70。
3. **job 15300685 / v0.3**：launcher 假设 Hellbender 一定定义 `SLURM_TMPDIR`，实际没有；1 秒 exit 70。
4. **job 15301401 / v0.4**：job-private scratch 修复成功，但 protocol validator 的 local-only launcher self-tests 继承外层真实 `SLURM_*` identity，正确被 launcher 拒绝，导致 in-job audit 110/111 与 immutable 111/111 audit 不同；3 秒 exit 1。

四次共同边界：

- frozen root 未创建；
- stage manifest 未创建；
- preflight 未运行；
- scientific/formal C2 未开始；
- formal claim 未创建；
- formal attempt 0/1 consumed；
- GPU/model/query/training 均为 0。

当前最小下一修复是让 validator 的 local-only self-test subprocess 清除继承的外层 `SLURM_*`，同时保留专门注入 Slurm identity 的 negative test。由于 v0.4 attempt 已消费，必须新版本、fresh reviewers 和新 owner approval，不能自动 retry。

## 14. 当前可能的论文贡献、impact 与最大风险

### 14.1 可辩护贡献候选

1. **现象贡献：** 首先在 heterogeneous procedural IR 中 source-first 测量 coverage-induced policy distortion、duplicate-component concentration 与 benchmark capacity collapse。
2. **操作化贡献：** 把已有 local-completeness/partial-closed-world semantics 编译成 relation-specific、scope-bounded、machine-readable candidate/evaluation contract。
3. **审计贡献：** 输出可重放 witness/counter-witness、component assignments、failure min-cuts 和 conclusion-change ledger。
4. **评价贡献：** 证明 unit/group split 与 component-safe split、naive negative 与 unresolved-aware policy 会否改变结论。
5. **负结果贡献：** 说明为什么结构容量、漂亮的 80Q benchmark、低维精确检索或第三个正向 graph source都不足以支撑可信主张。

### 14.2 潜在 impact

如果 C2 成立，影响不限于维修：任何 heterogeneous procedural corpus、instruction repository、workflow graph 或 manual collection 都可能有“未标不等于否定”和重复组件泄漏问题。价值在于训练前识别 benchmark 不可执行或评价结论不可信，避免昂贵模型训练建立在错误 labels/splits 上。

### 14.3 最大风险

- C1 effect 很大但只是 descriptive exposure，C2 可能不改变任何真正结论；
- 只有两来源，且 MyFixit 极端 giant-component skew 可能使结果看起来像单一数据异常；
- relation semantics source-specific，统一叙事可能过度抽象；
- completeness/open-world/evaluation leakage prior art 很强，procedural operationalization gap 可能不足以支撑 WSDM Main；
- 当前没有 model gain，WSDM reviewer 可能把工作视为 data cleaning；
- governance/validation 工程量很大，可能遮蔽简洁科学问题；
- C2 尚未运行，论文核心证据仍缺失。

## 15. 明确禁止的过度主张

不得声称：

- first procedural retrieval / graph retrieval / hierarchical retrieval；
- first dependency-aware retrieval；
- first support/refute/unknown evidence retrieval；
- first local completeness / three-valued / open-world retrieval；
- first proof/certificate / abstention / conformal retrieval；
- first anchor set / ambiguity marginalization；
- first adaptive-dimensional or gist-to-detail retrieval；
- MyFixit `.844160` 是 84% factual missingness 或 false-negative rate；
- tool 和 lab site 是同一语义；
- adjacency 是 prerequisite；
- giant components 是 semantic equivalence classes；
- Stage A/B/E3c 是 proposed-method gain；
- C2 已产生 empirical result；
- 当前项目正在训练模型；
- WSDM Main Track 已 GO。

## 16. 下一步严格顺序

1. 取得 owner 对“versioned C2 validator-harness isolation repair + one replacement immutable stage”的明确批准。
2. 只修复 self-test subprocess 环境隔离；科学 core、policies、thresholds、folds、Gate 和 outputs 不变。
3. 重新 protocol validation、mutation tests、两位 fresh result-blind reviewers。
4. 提交一次 CPU-only immutable stage；失败则停止，不自动 retry。
5. stage 成功后回收并独立验证 335-file manifest。
6. 另行批准并运行 CPU preflight smoke。
7. fresh 14-file implementation preflight + 两位 implementation reviewer GO。
8. 才能使用 formal 0/1 attempt 运行 complete C2 census。
9. 回收 untouched outputs，在 Mac 运行 official + implementation-independent validators，再经两位 result reviewers。
10. 只有 common C2 GO 后，才讨论一次 separately reviewed frozen-embedding semantic cross-split leakage GPU audit；它仍不训练。
11. 第一次需要人工 gold、研究 trade-off、第二次 GPU、training 或 final collection 时停止等待用户。

## 17. 建议 Claude 重点审查的问题

1. 当前 Route C 问题是否足够像 WSDM information retrieval/evaluation research，而不是 data cleaning？
2. 与 RDF completeness、partial closed-world、open-world KG evaluation、fact verification、BRINK 和 evaluation-leakage work 相比，procedural operationalization 是否形成独立贡献？
3. C2 的“conclusion change”是否是正确主 estimand？还需要哪种更有说服力的 downstream decision？
4. MyFixit/X-WLP 的 relation heterogeneity 是否仍允许一个统一 paper claim，还是应该写成两个 case studies？
5. 两来源是否足够？哪个第三来源最可能提供合法 refutation，而不是又一个 positive-only graph？
6. MyFixit giant component 是研究现象、数据异常还是方法 artifact？需要哪些 alternate component definitions 才能说服 reviewer？
7. 当前 policy compiler 是否过度复杂？哪些组件可以删除而不伤害科学主张？
8. 没有 proposed-model training/gain 的情况下，WSDM Main、Datasets & Benchmarks、Findings 或 data/resource venue 哪个更合理？
9. 如果 C2 得到强 policy distortion，最小方法贡献是否仍有必要？如果需要，应优先做 PU/selective risk、semantic resolver，还是只做 evaluation toolkit？
10. 现有 negative results 中哪些值得进入正文，哪些应放 appendix，哪些应完全删除？
11. C2 四次 setup failure 是否暴露 protocol engineering 过重，应该简化执行 DAG 吗？
12. 以当前时间和证据，最值得做的三件事和最应该停止的三件事是什么？

## 18. 关键术语

- **coverage policy**：冻结 source、relation domain/range、entity/domain/time/version/field universe、cardinality/exclusivity、negative-entailment rule、complete/partial/held state 和 provenance 的声明。
- **naive-negative exposure**：若把所有未观察 pair 都当 negative，其中按合法 policy 实际应为 `UNRESOLVED` 的比例；不是事实错误率。
- **duplicate component**：由 exact/near/source grouping 形成的保守 leakage quarantine transitive closure；不是语义等价类。
- **source-first**：先分别报告 MyFixit、X-WLP，再报 unweighted source macro，最后才 pooled。
- **witness/counter-witness**：可回到原始 edge/field 和 policy 的支持/排除证据。
- **formal C2**：一次性 complete-population deterministic CPU census；目前未运行。
- **GPU semantic leakage audit**：C2 GO 后才可能批准的冻结 embedding cross-split neighbor stress test；不是训练。

## 19. 关键证据文件索引

- 权威计划：`WSDM2027_HIERAREPAIR_MAIN_TRACK_MASTER_PLAN.md`
- Hellbender 稳定记忆：`.hellbender-project-memory.md`
- MyFixit manifest：`data/manifests/myfixit_download_manifest.yaml`
- MyFixit schema：`reports/data_audit/schema_report.md`
- Gate D0：`reports/data_audit/v15/gate_d0_readiness_audit_v0_1.md`
- 数据许可：`reports/data_audit/v15/access_license_audit.md`
- Stage A/B：`reports/data_audit/v15/collision_aware_stage_a_gpu_repaired_summary_v0_2.md`、`collision_aware_stage_b_summary_v0_1.md`
- E1/E2：`reports/data_audit/v15/e1_evidence_closure_audit_v0_1.md`、`e2_full_observable_ambiguity_audit_v0_1.md`
- E3b/E3c：`e3b_query_pool_shortcut_audit_v0_1.md`、`e3c_strong_semantic_shortcut_summary_v0_1.md`
- Semantic probes：`local_semantic_mechanism_probe_independent_audit_v0_1.md`、`adaptive_dimension_semantic_probe_v0_2.md`
- E3r：`e3r0_local_source_fit_audit_v0_1.md`、`e3r1a_full_universe_split_pool_feasibility_audit_v0_1.md`
- Route C C1：`route_c_c1_coverage_data_policy_census_v0_1.md` 与 independent validation
- C2 handoff/failures：`WSDM2027_HIERAREPAIR_C2_TASK_HANDOFF_20260724.md`、`hellbender_route_c_c2_stage_failure_chain_v0_2.json`、`WSDM2027_HIERAREPAIR_C2_V04_STAGE_SUBMISSION_20260724.md`
- Deep Research：`reports/literature/v15/deep_research_novelty_direction_portfolio_v0_2.md`
- WSDM package contraction：`reports/literature/v15/wsdm_core_1_3_5_11_contraction_v0_1.md`
- ICLR/RFCR/PIIR 历史：`iclr2027_reassessment_v0_1.md`、`rfcr_deep_research_collision_audit_v0_2.md`

## 20. 最终状态一句话

HieraRepair 已通过多轮强基线、数据完整性、coverage、ambiguity、shortcut、低维语义和 benchmark-feasibility Gate，主动淘汰了多个不成立或撞车的漂亮方向；现在唯一仍可能支撑 WSDM 的问题，是 **coverage-aware、component-safe evaluation 是否会稳定改变异构程序检索结论**。这个问题已有可信 C1 描述证据和严密 C2 协议，但还没有 C2 empirical answer。
