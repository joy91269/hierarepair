# P3 mapping declaration

Frozen before any P3 component, lattice, audit-criterion, or predictor computation. Empty text objects are not retrieval/evaluation units. The mapping below is immutable after the SHA-256 is recorded.

| source | unit | container | content_field | provenance_family | both_families_definable | exclusion_reason |
| --- | --- | --- | --- | --- | --- | --- |
| whpg | sentence occurrence | procedure graph `(split, file line)`; `(topic, method)` is the natural article-method identity and annotation boundary | `data[].sentence` | WIKIHOW | true | — |
| human_knowhow | `has_step` target occurrence with nonempty `rdfs:label` | direct `has_step` source procedure/method; the immediate structured parent gives one procedure boundary per occurrence | target `rdfs:label` | WIKIHOW | true | — |
| coin | annotated video-segment occurrence | `video_id`; the video is the natural procedure observation | `annotation[].label` | COIN | true | — |
| myfixit | guide-step occurrence | `(category file, Guidid)` repair guide; unchanged from P2 | `Steps[].Text_raw` | IFIXIT | true | — |
| openpi | process-step record | `question_metadata.url`; URL groups all steps from one WikiHow procedure | `question_metadata.query`, then `question` only if empty | WIKIHOW | true | — |
| wiqa | unique paragraph-step occurrence | `metadata.para_id`; paragraph groups repeated QA rows for one ProPara procedure | `question.para_steps[]` item | PROPARA | true | — |
| doc2dial | non-heading document span (`tag=u`) | `doc_id`; titles remain hierarchy metadata, not candidate units | `spans[span_id].text_sp` | DOC2DIAL_GOV | true | — |
| xwlp | operation node (`event`, `parent_type=op`) | `graph.proto_idx` protocol; unchanged from P2 | aligned `graph.sentences[...]`, then `display_name` only without a valid span | WET_LAB_PROTOCOLS | true | — |

All eight sources have both content-similarity and natural-container edge families definable. Provenance families, rather than dataset labels, determine independence.
