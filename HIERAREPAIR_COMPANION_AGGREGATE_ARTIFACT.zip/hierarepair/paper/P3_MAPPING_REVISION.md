# P3 mapping revision v0.2
- Change 1: WikiHow containers are article-level; Human Know-How resolves 80,286/80,286 units, OpenPI resolves all 4,050 after two schema-ID recoveries, while WHPG is excluded because one blank `topic`/`method` record leaves 93 units without an article ID.
- Change 2: COIN is `NOT GATE-ELIGIBLE` because `annotation[].label` is a closed taxonomy label rather than authored natural-language content.
- Change 3: WHPG now names only `topic` as the intended article boundary; the conflicting v0.1 `(split,file line)`/`(topic,method)` boundary claim is removed.
- v0.1 SHA-256: `eff66d155b14955c92996c4f705a45ff12f3b4fd4a460a35b3d7a857616267ea`
- v0.2 SHA-256: `c241b5527b05331ca3f5cc8a4a2aaecd8dde7f468d13c660edc6ecd55f209f74`
| source | containers_v0_1/article mean/median/max | units/article mean/median/max |
| --- | --- | --- |
| whpg | 2.635514/3/12 (107 resolvable articles) | 61.205607/60/192; 1 record/93 units unresolved |
| human_knowhow | 1.378349/1/34 | 8.055182/6/206 |
| openpi | 1/1/1 | 5/5/6 |
> All revisions were made before any component, lattice, audit-criterion, or predictor computation was executed.
