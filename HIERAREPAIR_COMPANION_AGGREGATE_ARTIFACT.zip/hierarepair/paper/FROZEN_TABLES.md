# Frozen Phase-A tables

## Table 1 — Edge-family lattice

source | config | edges | mode | n_components | top1_share_units | top1_share_support_mass | effective_components | size_max
--- | --- | --- | --- | ---: | ---: | ---: | ---: | ---:
myfixit | C1 | T_exact | closure | 85423 | 0.001736 | 0.006484 | 13292.754 | 409
myfixit | C2 | T_near | closure | 84777 | 0.001736 | 0.006484 | 12870.890 | 409
myfixit | C3 | G_source | closure | 18995 | 0.000582 | 0.002613 | 10209.086 | 137
myfixit | C4 | T_exact ∪ G_source | closure | 5443 | 0.413965 | 0.987661 | 5.828 | 97509
myfixit | C5 | T_near ∪ G_source | closure | 5375 | 0.416427 | 0.987661 | 5.760 | 98089
myfixit | C6 | T_exact ∪ G_source | edge-quarantine | NA | 0.090062 | 0.175119 | NA | 21214
myfixit | C7 | T_near ∪ G_source | edge-quarantine | NA | 0.090062 | 0.175119 | NA | 21214
xwlp | C1 | T_exact | closure | 2222 | 0.005364 | 0.005521 | 1448.561 | 21
xwlp | C2 | T_near | closure | 2213 | 0.005364 | 0.005521 | 1422.480 | 21
xwlp | C3 | G_source | closure | 279 | 0.009195 | 0.013497 | 226.169 | 36
xwlp | C4 | T_exact ∪ G_source | closure | 180 | 0.104470 | 0.107975 | 49.318 | 409
xwlp | C5 | T_near ∪ G_source | closure | 180 | 0.104470 | 0.107975 | 49.318 | 409
xwlp | C6 | T_exact ∪ G_source | edge-quarantine | NA | 0.050064 | 0.055215 | NA | 196
xwlp | C7 | T_near ∪ G_source | edge-quarantine | NA | 0.050064 | 0.055215 | NA | 196

## Table 2 — Closure quota-capacity proxy

source | config | tau | max_N | feasible | binding_constraint
--- | --- | --- | ---: | --- | ---
myfixit | C1 | exact | 120 | false | COMPONENT_STRUCTURE
myfixit | C2 | exact–0.50 | 120 | false | COMPONENT_STRUCTURE
myfixit | C3 | exact | 150 | true | NONE
myfixit | C4 | exact | 150 | true | NONE
myfixit | C5 | exact | 150 | true | NONE
myfixit | C5 | 0.95–0.50 | 120 | false | COMPONENT_STRUCTURE
myfixit | C6 | N/A | NA | NA | N/A
myfixit | C7 | N/A | NA | NA | N/A
xwlp | C1 | exact | 109 | false | COMPONENT_STRUCTURE
xwlp | C2 | exact–0.95 | 109 | false | COMPONENT_STRUCTURE
xwlp | C2 | 0.90–0.80 | 115 | false | COMPONENT_STRUCTURE
xwlp | C2 | 0.70 | 106 | false | COMPONENT_STRUCTURE
xwlp | C2 | 0.60–0.50 | 105 | false | COMPONENT_STRUCTURE
xwlp | C3 | exact | 150 | true | NONE
xwlp | C4 | exact | 150 | true | NONE
xwlp | C5 | exact–0.50 | 150 | true | NONE
xwlp | C6 | N/A | NA | NA | N/A
xwlp | C7 | N/A | NA | NA | N/A

## Table 3 — Lexical solvability

fixture | source | n_queries | lexical_best | neural_best | delta | CI95 | direction | independent
--- | --- | ---: | ---: | ---: | ---: | --- | --- | ---
44Q | myfixit | 24 | 0.0833 | 0.5000 | -0.4167 | [-0.6250, -0.2500] | NEURAL | yes
44Q | xwlp | 20 | 0.5000 | 0.8000 | -0.3000 | [-0.6000, -0.1000] | NEURAL | yes
80Q | humanknowhow | 20 | 1.0000 | 0.9000 | 0.1000 | [0.0000, 0.2000] | TIE | yes
80Q | myfixit | 30 | 0.8667 | 0.6333 | 0.2333 | [0.1000, 0.3667] | LEXICAL | yes
80Q | xwlp | 30 | 0.8667 | 0.8667 | 0.0000 | [0.0000, 0.0667] | TIE | yes
semantic-probe-80Q | humanknowhow | 20 | 1.0000 | 0.8500 | 0.1500 | [0.0000, 0.3000] | TIE | no—same 80Q
semantic-probe-80Q | myfixit | 30 | 0.8667 | 0.6333 | 0.2333 | [0.1000, 0.3675] | LEXICAL | no—same 80Q
semantic-probe-80Q | xwlp | 30 | 0.8667 | 0.8667 | 0.0000 | [0.0000, 0.0000] | TIE | no—same 80Q

B1 ratio (MyFixit C5/C2) = 239.826406 → PASS
