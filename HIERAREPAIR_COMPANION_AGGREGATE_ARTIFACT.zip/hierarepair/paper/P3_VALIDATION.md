# P-3 execution and validation record

Date: 2026-07-30  
Decision: `GATE1_PASS__GATE2_FAIL__P3_FINAL_FAIL`

## Frozen scope

- Mapping: `raw/phaseB/p3_mapping_v0_2.json`
- Mapping SHA-256: `c241b5527b05331ca3f5cc8a4a2aaecd8dde7f468d13c660edc6ecd55f209f74`
- Gate-eligible datasets: `human_knowhow`, `myfixit`, `openpi`, `wiqa`, `doc2dial`, `xwlp`
- Gate-eligible provenance families: `WIKIHOW`, `IFIXIT`, `PROPARA`, `DOC2DIAL_GOV`, `WET_LAB_PROTOCOLS`
- Candidate sources screened: 5; MyFixit is the previously known qualifying source and is not counted as newly screened.
- WHPG remains excluded under mapping v0.2. COIN is computed as an appendix-only closed-taxonomy diagnostic and does not enter any Gate or predictor fit.
- CPU only; no network, GPU, model inference, training, query authoring, or mapping revision.

## Candidate-generation fidelity

The requested `datasketch` package is absent from both the default and bundled offline Python environments, and network acquisition is prohibited. The run therefore uses the already registered Gate-C v0.2 fallback: global document-frequency prefix filtering that is threshold-complete at exact word-3-gram Jaccard 0.50, followed by exact rescoring. This is a conservative implementation deviation from MinHash-LSH: it omits no true edge at or above 0.50 and removes LSH sampling variability. The executed method and reason are recorded in `p3_edge_family_lattice.json`.

## Source counts

| source | units | containers | provenance | Gate |
|---|---:|---:|---|---|
| Human Know-How | 80,286 | 9,967 articles | WIKIHOW | eligible |
| MyFixit | 235,549 | 18,995 guides | IFIXIT | eligible |
| OpenPI | 4,050 | 810 articles | WIKIHOW | eligible |
| WIQA | 2,557 | 379 paragraphs | PROPARA | eligible |
| Doc2Dial | 31,602 | 488 documents | DOC2DIAL_GOV | eligible |
| X-WLP | 3,915 | 279 protocols | WET_LAB_PROTOCOLS | eligible |
| COIN | 46,354 | 11,827 videos | COIN | appendix only |

Two source-valid punctuation-only boundaries were retained rather than silently dropped: one Human Know-How label and two OpenPI `query="."` records normalize to the empty string but are nonempty released fields. They obey the frozen short-text/exact-equality rule.

## Results

Gate 1 passes. MyFixit and Doc2Dial qualify, yielding two qualifying datasets and two independent provenance families (`IFIXIT`, `DOC2DIAL_GOV`). The other four eligible datasets do not qualify.

Gate 2 fails. `bridge_edge_density` perfectly separates the two qualifying sources from the four nonqualifying sources:

- threshold: `63.769779841785336`
- slack: `42.8783380839846`
- Spearman rho with C5 largest-component share: `0.942857142857143`
- leave-one-source-out stable: `true`

However, the registered naive predictor `mean_union_degree` also perfectly separates the classes. Therefore the observed bridge signal is not shown to be uniquely explanatory beyond simple union-graph density, and the frozen final result is `FAIL`.

## Validation

- MyFixit and X-WLP C2/C3/C5 rows reproduce the prior P2 artifact field-for-field, including edges, component counts, largest component, shares, and effective components.
- The standalone artifact validator independently reconstructs all A1–A4 decisions, qualifying datasets and provenance families, predictor separation, threshold, slack, Spearman correlations, leave-one-out status, naive-control failure, and the 85-line report cap.
- Validator result: `P3_VALIDATION_OK`.
- Two complete deterministic reruns independently regenerated all four deliverables. Every rerun file is byte-identical to the canonical file.

## Canonical artifact hashes

| artifact | SHA-256 |
|---|---|
| `scripts/p3_multisource.py` | `fcd86cadbd517b388ca2bd63ed2c6fd78b64f189d6b41d54cc51b681534fac70` |
| `scripts/validate_p3_multisource.py` | `fd875bc3aef7e73776b99ad4019728b3d1f334a2ffea38d21d015c69ad243ac2` |
| `raw/phaseB/p3_edge_family_lattice.json` | `009e54e3cc5b41289fb140a28e05aaaabb86d72292ffb824523a4298ba3c3e7e` |
| `raw/phaseB/p3_audit_criteria.json` | `8ddbb5a8701ec538394cfcc65984213215c0540f9520c7792c2259e1663d2a4e` |
| `raw/phaseB/p3_predictors.json` | `fe82f9689595ed293da67513f7fb1cced52fe3ef4e8d14da20c806a59ff995af` |
| `paper/P3_RESULT.md` | `116104f6c3d2814872c7e81c85cebc8ef3a83a0d287424ea0fc354828ff29e97` |

## Interpretation boundary

P-3 supplies a cross-domain replication of the layer-interaction pattern at the dataset Gate level, but it does not validate the preregistered claim that bridge structure is a distinctive predictor. No threshold, mapping, source membership, predictor, or Gate was changed after seeing results. Further work must start from the frozen failure rather than weakening the negative-control condition.
