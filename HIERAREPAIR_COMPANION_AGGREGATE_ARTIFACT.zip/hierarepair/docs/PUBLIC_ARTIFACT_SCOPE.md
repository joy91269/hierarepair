# Public artifact scope

Status: **AGGREGATE-LEVEL PUBLIC CANDIDATE**

## Included

- manuscript source, bibliography, and generated tables/figures;
- frozen aggregate JSON used by the current measurement;
- aggregate builders and validators that do not require raw corpora;
- aggregate dependency records and section-level validation outputs;
- rebuild instructions for the public repository layout.

## Excluded

- all third-party raw corpora;
- private literature PDFs and extracted full text;
- historical and superseded review records;
- the complete historical recovery archive;
- the recovered P-3 raw runner as a trusted public execution entry point.

The recovered runner remains audit evidence only: its Human Know-How decoding risk is open, no corrected-parser raw rerun exists, and it does not establish a raw-data-to-paper path. Public aggregate artifacts preserve their source mapping and hash provenance but do not transfer or certify third-party corpus redistribution rights. Data acquisition remains subject to the original sources and their licenses; this release contains no complete acquisition recipe for those corpora.

This artifact supports offline aggregate-level verification. It does not support raw-corpus end-to-end reproduction, recovery of the original locked environment, or a claim that every historical project artifact is present.

## Licensing boundary

- Project-authored software code is licensed under MIT (`LICENSE-CODE`).
- To the extent the authors hold the relevant rights, author-created aggregate
  records, aggregate-derived tables and figures, and documentation are licensed
  under CC BY 4.0 (`LICENSE-DATA-DOCS`).
- The manuscript PDF, article text and TeX source, and bibliography remain
  copyright the authors; this repository grants no additional reuse license for
  them.
- No project license grants rights to third-party raw corpora, papers, or other
  third-party materials.

The repository-level `LICENSE` file is the controlling scope notice.
