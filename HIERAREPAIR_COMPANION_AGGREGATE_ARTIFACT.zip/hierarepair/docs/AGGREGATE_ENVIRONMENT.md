# Aggregate verification environment

Status: **SNAPSHOT OF THE CURRENT AGGREGATE CHECK ONLY**

- OS / architecture: Darwin 26.5.2 / arm64.
- Python: 3.12.13.
- NumPy: 2.3.5.
- ReportLab (Section 3 review-PDF builder dependency): 4.4.9.
- Plotting implementation: NONE_NATIVE_LATEX_VECTOR_FIGURE.
- Figure/PDF generator: Tectonic 0.16.9.
- BibTeX engine: This is BibTeX, Version 0.99d.
- Standard TeX Live XeLaTeX: NOT_VERIFIABLE.
- Poppler/pdffonts: pdffonts version 26.05.0.
- Locale/encoding: C/C.UTF-8/C/C/C/C / UTF-8.
- SOURCE_DATE_EPOCH: 0 for the native-LaTeX figure build.
- Verification entry points: the Section 3--8 builders and validators listed
  in the repository `README.md`.

This is not a complete raw-pipeline lock, not the original P-3 environment, and not a guarantee of cross-platform byte identity.
