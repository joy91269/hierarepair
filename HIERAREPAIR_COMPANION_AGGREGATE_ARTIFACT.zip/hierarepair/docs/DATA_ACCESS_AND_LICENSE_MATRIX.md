# Data access and license matrix

Status: **CURRENT CONSERVATIVE SCOPE**

Only license/access statements already recorded in current project evidence are used. No network lookup or license inference was performed.

| Source | Public artifact | Recorded license status | Redistribution | Action | Acquisition instructions | Hash-only provenance |
|---|---:|---|---|---|---:|---:|
| Human Know-How | no | CC BY-NC 4.0 (reported in current project evidence) | NOT_ALLOWED_IN_CURRENT_PUBLIC_ARTIFACT | EXCLUDE_RAW_CORPUS | no | no |
| MyFixit | no | CC BY-NC-SA 3.0 (reported in current project evidence) | NOT_ALLOWED_IN_CURRENT_PUBLIC_ARTIFACT | EXCLUDE_RAW_CORPUS | no | no |
| OpenPI | no | MIT (reported in current project evidence) | NOT_ALLOWED_IN_CURRENT_PUBLIC_ARTIFACT | EXCLUDE_RAW_CORPUS | no | no |
| WIQA | no | NOT_VERIFIABLE | NOT_VERIFIABLE | EXCLUDE_RAW_CORPUS | no | no |
| Doc2Dial | no | CC BY 3.0 with attribution (reported in current project evidence) | NOT_ALLOWED_IN_CURRENT_PUBLIC_ARTIFACT | EXCLUDE_RAW_CORPUS | no | no |
| X-WLP | no | MIT (reported in current project evidence) | NOT_ALLOWED_IN_CURRENT_PUBLIC_ARTIFACT | EXCLUDE_RAW_CORPUS | no | no |
| COIN annotations | no | CC BY-NC 4.0 (reported in current project evidence) | NOT_ALLOWED_IN_CURRENT_PUBLIC_ARTIFACT | EXCLUDE_RAW_CORPUS | no | no |
| WHPG | no | NOT_VERIFIABLE | NOT_VERIFIABLE | EXCLUDE_RAW_CORPUS | no | no |
| Section 9 retrieved papers | no | MIXED; PER-RECORD STATUS RETAINED IN PRIVATE INVENTORY | NOT_ALLOWED_IN_CURRENT_PUBLIC_ARTIFACT | EXCLUDE_PRIVATE_EVIDENCE | no | yes |
| Frozen Phase-B aggregate JSON | yes | NO STANDALONE LICENSE FILE RECORDED; RELEASE AUTHORIZED WITH SCOPE NOTICE | ALLOWED_WITH_SCOPE_NOTICE | INCLUDE_AGGREGATES | no | yes |
| Manuscript source and generated tables/figures | yes | NO STANDALONE LICENSE FILE RECORDED; RELEASE AUTHORIZED WITH SCOPE NOTICE | ALLOWED_WITH_SCOPE_NOTICE | INCLUDE_PUBLICATION_SOURCE | no | yes |
| Recovered historical P-3 runner | no | NOT_VERIFIABLE | NOT_VERIFIABLE | EXCLUDE_FROM_PUBLIC_EXECUTION_ENTRYPOINT | no | yes |

Raw third-party corpora and private literature PDFs are excluded. Repository availability is not treated as redistribution permission. NOT_VERIFIABLE is preserved wherever the current evidence does not establish a license or acquisition path.
