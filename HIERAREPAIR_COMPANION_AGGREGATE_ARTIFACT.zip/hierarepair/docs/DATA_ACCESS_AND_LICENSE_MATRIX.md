# Data access and license matrix

Status: **CURRENT SCOPED-LICENSE RELEASE**

Repository-authored output licenses reflect the authors' explicit 2026-08-09
decision. The third-party source rows retain the conservative statuses already
recorded in project evidence; no additional redistribution right is inferred.

| Source | Public artifact | Recorded license status | Redistribution | Action | Acquisition instructions | Hash-only provenance |
|---|---:|---|---|---|---:|---:|
| Human Know-How | no | CC BY-NC 4.0 (reported in current project evidence) | NOT_ALLOWED_IN_CURRENT_PUBLIC_ARTIFACT | EXCLUDE_RAW_CORPUS | no | no |
| MyFixit | no | CC BY-NC-SA 3.0 (reported in current project evidence) | NOT_ALLOWED_IN_CURRENT_PUBLIC_ARTIFACT | EXCLUDE_RAW_CORPUS | no | no |
| OpenPI | no | MIT (reported in current project evidence) | NOT_ALLOWED_IN_CURRENT_PUBLIC_ARTIFACT | EXCLUDE_RAW_CORPUS | no | no |
| WIQA | no | NOT_VERIFIABLE | NOT_VERIFIABLE | EXCLUDE_RAW_CORPUS | no | no |
| Doc2Dial | no | CC BY 3.0 with attribution (reported in current project evidence) | NOT_ALLOWED_IN_CURRENT_PUBLIC_ARTIFACT | EXCLUDE_RAW_CORPUS | no | no |
| X-WLP | no | MIT (reported in current project evidence) | NOT_ALLOWED_IN_CURRENT_PUBLIC_ARTIFACT | EXCLUDE_RAW_CORPUS | no | no |
| COIN annotations | no | CC BY-NC 4.0 (reported in current project evidence) | NOT_ALLOWED_IN_CURRENT_PUBLIC_ARTIFACT | EXCLUDE_RAW_CORPUS | no | no |
| WHPG | no | NOT_VERIFIABLE | NOT_VERIFIABLE | EXCLUDE_RAW_CORPUS | no | no |
| Section 9 retrieved papers | no | MIXED; PER-RECORD STATUS RETAINED IN PRIVATE INVENTORY | NOT_ALLOWED_IN_CURRENT_PUBLIC_ARTIFACT | EXCLUDE_PRIVATE_EVIDENCE | no | yes |
| Aggregate builders and validators authored for this project | yes | MIT; see `LICENSE-CODE` | ALLOWED_UNDER_MIT | INCLUDE_CODE | no | yes |
| Frozen Phase-B aggregate JSON | yes | CC BY 4.0 to the extent the authors hold rights; see `LICENSE-DATA-DOCS` | ALLOWED_UNDER_CC_BY_4_0_WITH_SCOPE_NOTICE | INCLUDE_AGGREGATES | no | yes |
| Author-created aggregate-derived tables and figures | yes | CC BY 4.0 to the extent the authors hold rights; see `LICENSE-DATA-DOCS` | ALLOWED_UNDER_CC_BY_4_0_WITH_SCOPE_NOTICE | INCLUDE_AGGREGATE_DERIVATIVES | no | yes |
| Manuscript PDF, article text and TeX source, and bibliography | yes | Copyright the authors; no additional reuse license granted by this repository | PUBLIC_INSPECTION_ONLY_EXCEPT_AS_ALLOWED_BY_LAW_OR_LATER_VERSION_SPECIFIC_TERMS | INCLUDE_PUBLICATION_SOURCE | no | yes |
| Recovered historical P-3 runner | no | NOT_VERIFIABLE | NOT_VERIFIABLE | EXCLUDE_FROM_PUBLIC_EXECUTION_ENTRYPOINT | no | yes |

Raw third-party corpora and private literature PDFs are excluded. Repository
availability is not treated as redistribution permission. The project licenses
apply only to material in which the authors hold the relevant rights and do not
override any original provider's terms. NOT_VERIFIABLE is preserved wherever
the current evidence does not establish a third-party license or acquisition
path.
