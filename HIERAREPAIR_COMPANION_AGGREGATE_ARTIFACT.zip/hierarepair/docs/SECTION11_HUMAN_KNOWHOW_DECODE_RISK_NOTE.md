# Section 11 Human Know-How decode-risk insertion note

Status: validated writing constraint only; Section 11 has not been drafted.

Required impact path:

`UTF-8 Turtle label bytes -> unicode_escape mojibake -> normalized step text -> content near-duplicate edges -> C2 and C5 connected-component structure`.

Frozen aggregate position:

- Human Know-How C5 top1 share: `0.13755823` (0.1376 when rounded to four decimals).
- Human Know-How C5 effective components: `52.214953` (52.215 when rounded to three decimals).
- Human Know-How C5 currently fails A1 only.
- Human Know-How C2 frozen top1 share: `0.007896769`; margin below A1 = 0.01: `0.002103231`.

Complete Gate logic:

### Route (a), conjunctive

- `top1_share > 0.20`
- **AND** `effective_components < 30`

Both changes must occur simultaneously:

- top1 share must increase by `0.0624` (`+45%` relative to frozen share 0.1376).
- effective components must decrease by `22.21` (`-43%` relative to frozen value 52.215).

### Route (b)

- `top1_share > 1/3`

This requires:

- top1 share must increase by `0.1958` (`+142%` relative to frozen share 0.1376).

Route (a) is binding. Its two conjunctive changes must occur together; neither change alone reaches the frozen requirement of three union failures. The relevant share margin is 0.0624, not the larger Route (b) margin.

For C2, the frozen top1 share is 0.007897, only 0.002103 below A1 = 0.01. An A1-only reversal would still leave C2 passing A2--A4 and therefore at least 3/4 criteria, so its single-layer status would be unchanged.

Interpretation boundary:

These margins are descriptive and do not establish invariance under a corrected parser. No corrected-parser rerun exists. The current evidence is insufficient to require revising the frozen qualifier set; this is not a claim that the qualifier set cannot change. The aggregate result remains frozen while raw-data reproduction remains open.

Runner SHA-256: `fcd86cadbd517b388ca2bd63ed2c6fd78b64f189d6b41d54cc51b681534fac70`
Lattice SHA-256: `009e54e3cc5b41289fb140a28e05aaaabb86d72292ffb824523a4298ba3c3e7e`
Audit SHA-256: `8ddbb5a8701ec538394cfcc65984213215c0540f9520c7792c2259e1663d2a4e`
