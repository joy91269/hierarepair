# Gate A — P1 literature-collision and construct-validity audit

**Cutoff:** 2026-07-24 EDT  
**Candidate:** *Silent Sources, Confident Judges: Coverage Hallucination in LLM-Generated Relevance Labels*  
**Decision:** `STOP_P1_AS_WRITTEN__NO_DIRECT_I_S_R_PAPER_FOUND_YET__SEVERE_PARTIAL_COLLISION__SOURCE_SILENCE_REFERENCE_INVALID`

## Technical summary

The exact three-way conjunction proposed in the pivot plan was not found in the primary works reviewed so far:

1. an LLM produces IR relevance judgments;
2. a source-derived reference establishes that the source is silent or insufficient for the requested relation; and
3. the resulting labels are tested for downstream retrieval-system ranking changes.

That narrow result is **not enough for a WSDM Main Track GO**. The candidate is squeezed between two mature research lines:

- IR work already measures LLM-generated qrels, missing-judgment filling, judge bias, high-confidence overrating, and induced system-ranking changes.
- NLP/fact-verification work already measures failure to abstain under absent, deleted, irrelevant, or insufficient evidence, including controlled counterfactual deletion.

The proposed experiment therefore looks like a conjunction/application of established instruments unless it contributes a new estimand, identification argument, or method. More seriously, the current E1 `UNRESOLVED` label is **not a semantic “source is silent” reference**. It means only that a structured field is outside the frozen completeness policy or unavailable for sound negative entailment. The natural-language text can still state the requested information.

The present implementation adds a second confound: all 198,544 MyFixit `UNRESOLVED` replay assertions use the same lexicographically first tool (`1 5mm hex screwdriver`), and all 2,285 X-WLP `UNRESOLVED` replay assertions use the same first location family (`assay matrix`). Sampling Gate B from those compiled assertions would not estimate general abstention under source silence; it would largely estimate behavior for two fixed requested values.

**Bottom line:** do not execute Gate B or the P1 main experiment as specified. The literature gate is at least `SEVERE_PARTIAL`, and the measurement contract fails construct validity before any model call.

## 1. Frozen claim and collision rule

The pre-search protocol is preserved in
`reports/pivot/gate_a_literature_collision_protocol_v0_1.md`.

- **I — IR judge:** an LLM or automatic assessor produces relevance labels used for IR evaluation.
- **S — source-derived silence:** insufficient/not-stated status is established from inspectable evidence availability or a controlled evidence-removal construction, not merely from an unjudged pooled document.
- **R — ranking consequence:** the work measures system ordering, winner identity, Kendall/Spearman correlation, or an equivalent downstream IR-evaluation consequence.

Frozen decision labels:

- `DIRECT`: one prior work covers I+S+R.
- `SEVERE PARTIAL`: a close I+R work and the directly connected S literature leave only a domain-level conjunction.
- `PARTIAL`: one work covers two dimensions.
- `ADJACENT`: one dimension or a materially different task.

No individual component—LLM relevance judging, abstention, insufficient-evidence detection, source grounding, qrels completion, judge overrating, or system-ranking correlation—may be claimed as new.

## 2. Answer to the literal collision question

### 2.1 Direct collision

No reviewed work currently meets strict I+S+R simultaneously.

This is a bounded negative finding under the recorded protocol, not proof that no such paper exists. OpenAlex, Semantic Scholar, and DBLP coverage and completion counts are recorded in Section 6.

### 2.2 Severe partial collisions that matter for WSDM novelty

| Collision front | What prior work already establishes | What would remain for P1 |
| --- | --- | --- |
| LLM qrels + ranking impact | One-Shot Labeling, UMBRELA/TREC RAG, missing-qrels patching, LLMJudge benchmarking, LARA, and Otero et al. already compare induced system rankings, top-run fairness, significance decisions, or evaluation reliability. | Replace human/missing-qrels reference with a valid source-silence reference. |
| Confident false positives in IR judging | *When LLM Judges Inflate Scores* studies high-confidence overrating; Alaofi et al. obtain false-positive relevance labels through controlled keyword and instruction injection. | Show that a valid evidence-silence intervention—not just nonrelevance, lexical cues, or injected instructions—causes overcommitment and changes system selection. |
| Evidence removal + abstention | *Fact Checking with Insufficient Evidence* and Wen et al. construct missing/incorrect context and measure failure to detect insufficiency or abstain. | Move the same causal instrument into IR evaluation and establish downstream system-selection consequences. |
| Attenuated document + IR rankings | *The Effect of Document Summarization on LLM-Based Relevance Judgments* varies how much document evidence the judge sees and measures system-ranking stability. | Establish certified relation-specific evidence absence rather than generic summarization. |
| Construction-aware insufficiency | NEI-CAP argues that evidence absence and evidence insufficiency are observationally different and audits construction artifacts. | Provide a construction-aware IR protocol; a single `UNRESOLVED` bucket is specifically inadequate. |

This is why “no single I+S+R paper” does not make the paper novelty-safe. A WSDM reviewer can reasonably describe P1 as:

> Apply established insufficient-context/abstention diagnostics to an already crowded LLM relevance-judgment setting, then reuse standard system-ranking correlation analysis.

P1 needs more than that sentence to justify a Main Track contribution.

## 3. Primary-work collision ledger

The table records the closest primary works and the method signal used for classification. `S*` means evidence attenuation or incompleteness is relevant but does not provide the strict relation-specific source-silence reference required by P1.

| # | Primary work | Year | I | S | R | Classification and method signal |
| ---: | --- | ---: | :---: | :---: | :---: | --- |
| 1 | [Perspectives on Large Language Models for Relevance Judgment](https://doi.org/10.1145/3578337.3605136) | 2023 | ✓ |  |  | `ADJACENT-I`; establishes the LLM relevance-judgment research agenda. |
| 2 | [One-Shot Labeling for Automatic Relevance Estimation](https://arxiv.org/abs/2302.11266) | 2023 | ✓ |  | ✓ | `PARTIAL-I+R`; fills unjudged-document holes and reports system-ranking correlations above 0.86. |
| 3 | [UMBRELA](https://arxiv.org/abs/2406.06519) | 2024 | ✓ |  | ✓ | `PARTIAL-I+R`; open LLM relevance assessor used to create evaluation labels and reproduce rankings. |
| 4 | [Large Language Models can Accurately Predict Searcher Preferences](https://doi.org/10.1145/3626772.3657707) | 2024 | ✓ |  | ✓ | `PARTIAL-I+R`; validates LLM relevance/preferences against evaluation outcomes. |
| 5 | [LLMJudge: LLMs for Relevance Judgments](https://arxiv.org/abs/2408.08896) | 2024 | ✓ |  | ✓ | `PARTIAL-I+R`; shared-task setting for generated relevance judgments and retrieval evaluation. |
| 6 | [A Large-Scale Study of Relevance Assessments with Large Language Models](https://arxiv.org/abs/2411.08275) | 2024 | ✓ |  | ✓ | `PARTIAL-I+R`; 77 runs, manual/LLM/hybrid judgments, induced rankings for nDCG and recall. |
| 7 | [Can We Use Large Language Models to Fill Relevance Judgment Holes?](https://ceur-ws.org/Vol-3854/emtcir-2.pdf) | 2024 | ✓ |  | ✓ | `PARTIAL-I+R`; fills pooling holes and shows new runs can be favored or penalized as hole size grows. |
| 8 | [LLMs Can Patch Up Missing Relevance Judgments in Evaluation](https://arxiv.org/abs/2405.04727) | 2024 | ✓ |  | ✓ | `PARTIAL-I+R`; randomly drops qrels, fills them with LLM labels, and reports Kendall correlations. |
| 9 | [LLM-Assisted Relevance Assessments (LARA)](https://arxiv.org/abs/2411.06877) | 2024 | ✓ |  | ✓ | `PARTIAL-I+R`; actively selects human labels and calibrates/debiases remaining LLM qrels for reliable test collections. |
| 10 | [Judging the Judges: A Systematic Study of Position Bias in LLM-as-a-Judge](https://arxiv.org/abs/2406.07791) | 2024 |  |  |  | `ADJACENT`; general LLM-judge reliability, not the strict IR/source-silence/ranking conjunction. |
| 11 | [Benchmarking LLM-based Relevance Judgment Methods](https://arxiv.org/abs/2504.12558) | 2025 | ✓ |  | ✓ | `PARTIAL-I+R`; compares binary, graded, pairwise, and nugget methods using human alignment and system-ranking Kendall correlation. |
| 12 | [Large Language Model Relevance Assessors Agree With One Another More Than With Human Assessors](https://doi.org/10.1145/3726302.3730218) | 2025 | ✓ |  | ✓ | `PARTIAL-I+R`; eight assessors, 30–50 systems, LLM rankers move upward by 9–17 positions under LLM assessors. |
| 13 | [Rankers, Judges, and Assistants](https://arxiv.org/abs/2503.19092) | 2025 | ✓ |  | ✓ | `PARTIAL-I+R`; demonstrates judge bias toward LLM rankers and inversion of system preferences. |
| 14 | [Criteria-Based LLM Relevance Judgments](https://arxiv.org/abs/2507.09488) | 2025 | ✓ |  | ✓ | `PARTIAL-I+R`; decomposes relevance into exactness, coverage, topicality, and contextual fit, then evaluates leaderboard agreement. |
| 15 | [Principles and Guidelines for the Use of LLM Judges](https://doi.org/10.1145/3731120.3744588) | 2025 | ✓ |  | ✓ | `PARTIAL-I+R`; analyzes IR evaluation validity, circularity, unjudged documents, and system-ranking sensitivity. |
| 16 | [Don’t Use LLMs to Make Relevance Judgments](https://doi.org/10.54195/irrj.19625) | 2025 | ✓ |  |  | `ADJACENT-I`; direct methodological critique of replacing human qrels. |
| 17 | [LLM-based relevance assessment still can’t replace human relevance assessment](https://arxiv.org/abs/2412.17156) | 2025 | ✓ |  | ✓ | `PARTIAL-I+R`; evaluates LLM/human disagreement and retrieval-evaluation consequences. |
| 18 | [When LLM Judges Inflate Scores](https://arxiv.org/abs/2602.17170) | 2026 | ✓ |  |  | `ADJACENT-I`, but title/phenomenon collision is strong: high-confidence overrating under pointwise/pairwise assessment and controlled lexical/length cues. |
| 19 | [The Effect of Document Summarization on LLM-Based Relevance Judgments](https://arxiv.org/abs/2512.05334) | 2026 | ✓ | S* | ✓ | `SEVERE PARTIAL`; varies full documents versus summaries, measures label shifts and system-ranking stability. |
| 20 | [Formalized Information Needs Improve Large-Language-Model Relevance Judgments](https://arxiv.org/abs/2604.04140) | 2026 | ✓ |  | ✓ | `PARTIAL-I+R`; changes topic evidence/representation and measures label agreement and evaluation reliability. |
| 21 | [Hybrid Pooling with LLMs via Relevance Context Learning](https://arxiv.org/abs/2602.08457) | 2026 | ✓ |  | ✓ | `PARTIAL-I+R`; constructs hybrid human/LLM qrels for retrieval-system evaluation. |
| 22 | [Evaluation Validity in Information Retrieval](https://www.microsoft.com/en-us/research/publication/evaluation-validity-in-information-retrieval/) | 2026 | ✓ |  | ✓ | `ADJACENT/PERSPECTIVE`; explicitly frames validity risks when retrieval and LLM-as-judge evaluation collapse together. |
| 23 | [FEVER](https://aclanthology.org/N18-1074/) | 2018 |  | ✓ |  | `ADJACENT-S`; establishes SUPPORTS/REFUTES/NOT-ENOUGH-INFO fact verification with evidence. |
| 24 | [Fact Checking with Insufficient Evidence](https://aclanthology.org/2022.tacl-1.43/) | 2022 |  | ✓ |  | `ADJACENT-S`; fluency-preserving constituent/sentence omission, human sufficiency judgments, and missing-evidence prediction. |
| 25 | [Context-faithful Prompting for Large Language Models](https://arxiv.org/abs/2303.11315) | 2023 |  | ✓ |  | `ADJACENT-S`; tests parametric/context conflict and prediction with abstention when context lacks the answer. |
| 26 | [Characterizing LLM Abstention Behavior in Science QA with Context Perturbations](https://aclanthology.org/2024.findings-emnlp.197/) | 2024 |  | ✓ |  | `ADJACENT-S`; removes, replaces, and augments gold context; six LLMs often fail to abstain, especially on Boolean questions. |
| 27 | [Know Your Limits: A Survey of Abstention in Large Language Models](https://aclanthology.org/2025.tacl-1.26/) | 2025 |  | ✓ |  | `ADJACENT-S`; maps abstention by query, model, and human-value causes, including insufficient/irrelevant context. |
| 28 | [When to Speak, When to Abstain](https://aclanthology.org/2025.acl-long.479/) | 2025 |  | ✓ |  | `ADJACENT-S`; controlled contextual/parametric knowledge access and training-free contrastive decoding with abstention. |
| 29 | [Knowing What’s Missing: Assessing Information Sufficiency in QA](https://arxiv.org/abs/2512.06476) | 2026 |  | ✓ |  | `ADJACENT-S`; identify-then-verify hypotheses of missing information against source text. |
| 30 | [Evidence Absence Is Not Evidence Insufficiency (NEI-CAP)](https://arxiv.org/abs/2605.26663) | 2026 |  | ✓ |  | `ADJACENT-S`, conceptually critical: shows NEI construction families are not interchangeable and aggregate NEI recall hides different competencies. |
| 31 | [RefusalBench](https://aclanthology.org/2026.eacl-long.321/) | 2026 |  | ✓ |  | `ADJACENT-S`; 176 controlled perturbations for selective refusal in grounded multi-document settings. |
| 32 | [ClinDet-Bench](https://aclanthology.org/2026.acl-industry.47/) | 2026 |  | ✓ |  | `ADJACENT-S`; constructs determinable/undeterminable cases under missing clinical information. |
| 33 | [Retrieval Evaluation with Incomplete Information (bpref)](https://doi.org/10.1145/1008992.1009000) | 2004 |  |  | ✓ | `ADJACENT-R`; foundational evaluation under incomplete relevance judgments. |
| 34 | [Shallow Pooling for Sparse Labels](https://arxiv.org/abs/2109.00062) | 2022 |  |  | ✓ | `ADJACENT-R`; shows sparse labels can distort neural-ranker conclusions and leaderboard validity. |
| 35 | [Question and Answer Test-Train Overlap in Open-Domain QA Datasets](https://aclanthology.org/2021.eacl-main.86/) | 2021 |  |  |  | `ADJACENT`; contamination/overlap seed, not the P1 conjunction. |
| 36 | [GroundEval](https://arxiv.org/abs/2606.22737) | 2026 |  | ✓ |  | `ADJACENT-S/JUDGE`; deterministic evidence-path checks include a Silence track and show plausible unsupported answers can receive high LLM-judge scores. |
| 37 | [LLM Judges Can Be Too Generous When There Is No Reference Answer](https://arxiv.org/abs/2607.12885) | 2026 |  | S* |  | `ADJACENT`; absence of a reference answer produces over-crediting and large verdict flips in general LLM judging. |
| 38 | [Synthetic Test Collections for Retrieval Evaluation](https://doi.org/10.1145/3626772.3657942) | 2024 | ✓ |  | ✓ | `PARTIAL-I+R`; generates both queries and LLM qrels, evaluates retrieval systems, and explicitly tests bias toward LLM-based systems. |
| 39 | [LLMs can be Fooled into Labelling a Document as Relevant](https://doi.org/10.1145/3673791.3698431) | 2024 | ✓ |  |  | `ADJACENT-I`, but a close mechanism collision: controlled keyword and instruction injection induces false-positive relevance labels, and positive LLM labels are less reliable than negative ones. |
| 40 | [Attribute or Abstain: Large Language Models as Long Document Assistants](https://aclanthology.org/2024.emnlp-main.463/) | 2024 |  | ✓ |  | `ADJACENT-S`; evaluates answer/attribution versus abstention in six long-document tasks and uses evidence quality for selective prediction. |
| 41 | [Limitations of Automatic Relevance Assessments with Large Language Models for Fair and Reliable Retrieval Evaluation](https://doi.org/10.1145/3726302.3730221) | 2025 | ✓ |  | ✓ | `PARTIAL-I+R`; measures top-heavy system-order changes, per-run fairness, and false-positive significance decisions under LLM qrels. |
| 42 | [LLMs (Almost) Never Abstain Under Medical Uncertainty](https://aclanthology.org/2026.acl-long.1365/) | 2026 |  | ✓ |  | `ADJACENT-S`; controlled removal of the gold answer and even the question produces systematic high-confidence overcommitment. |
| 43 | [TRUE: A Reproducible Framework for LLM-Driven Relevance Judgment in Information Retrieval](https://arxiv.org/abs/2509.25602) | 2026 | ✓ |  | ✓ | `PARTIAL-I+R`; a WSDM 2026 paper standardizes multi-factor LLM relevance judging and evaluates Spearman/Kendall system-ranking agreement. |
| 44 | [Mitigating the Threshold Priming Effect in LLM-Based Relevance Judgments via Personality Simulation](https://doi.org/10.1145/3773966.3779384) | 2026 | ✓ |  |  | `ADJACENT-I`; a WSDM 2026 paper treats context-induced cognitive bias in batched LLM relevance assessment and proposes mitigation. |
| 45 | [Topic-Specific Classifiers are Better Relevance Judges than Prompted LLMs](https://doi.org/10.1145/3805712.3809713) | 2026 | ✓ |  | ✓ | `PARTIAL-I+R`; a SIGIR 2026 paper treats unjudged documents explicitly, compares against treating them as nonrelevant and LLM judges, and reports system-ranking correlation above 0.95 from shallow human pools. |
| 46 | [System Comparison Using Automated Generation of Relevance Judgements in Multiple Languages](https://doi.org/10.1145/3726302.3730252) | 2025 | ✓ |  | ✓ | `PARTIAL-I+R`; a SIGIR short paper generates multilingual qrels and directly compares the induced preference ordering among retrieval systems with human-qrel ordering. |
| 47 | [A Cost-Effective Framework to Evaluate LLM-Generated Relevance Judgements](https://doi.org/10.1145/3746252.3761200) | 2025 | ✓ |  |  | `ADJACENT-I`; supplies a statistically bounded human-validation protocol and reports that 16% of labels suffice for a 95% confidence estimate on its collections. |
| 48 | [JuStRank: Benchmarking LLM Judges for System Ranking](https://aclanthology.org/2025.acl-long.34/) | 2025 |  |  | ✓ | `ADJACENT-R/JUDGE`; not an IR-qrels paper, but directly studies aggregation of LLM judgments into system rankings, including system-specific bias and decisiveness. |
| 49 | [Auto-Judge: A Cross-Task Benchmark for Comparing LLM Judges for Citation-Grounded RAG Systems](https://doi.org/10.1145/3805712.3808601) | 2026 |  | S* |  | `ADJACENT-S/JUDGE`; evaluates citation-grounded RAG judges rather than IR relevance qrels, so it is not a direct collision but further crowds the source-grounded judge-evaluation mechanism. |
| 50 | [Learning to Rank with Multi-Criteria LLM-Judge Annotations](https://doi.org/10.1145/3805712.3809580) | 2026 | ✓ |  | ✓ | `PARTIAL-I+R`; uses multi-criteria LLM relevance grades as learning-to-rank features, showing that judge-generated annotations are already studied not only for evaluation but as downstream ranking signals. |

## 4. Construct-validity failure in the proposed P1 instrument

### 4.1 What E1 `UNRESOLVED` actually means

The frozen E1 contract states:

> The field is outside the local-completeness scope, absent, ill-typed, or otherwise not licensed for negative entailment. Missing never means refuted.

That is a sound open-world rule for avoiding false negatives. It is **not** a certificate that:

- the natural-language document does not mention the requested value;
- the relation cannot be inferred from the document;
- the source is semantically silent;
- a YES/NO model answer is fabricated; or
- `UNKNOWN` is the only correct response to the prompt’s `document_text`.

The pivot plan silently changes the meaning from “we may not infer false from this structured field” to “the document contains insufficient information.” That change is not licensed by E1 replay.

### 4.2 Deterministic lexical lower-bound audit

`scripts/audit_gate_a_source_silence_validity.py` scans the original files without an LLM. It asks only whether natural-language text attached to E1-unresolved units contains exact normalized cues from the frozen relation vocabularies.

Machine-readable output:
`reports/pivot/raw/gate_a_source_silence_validity_v0_1.json`
(`sha256:a7f11115b01b85d13ae64dd3e6881a470ab7e7cea549b6a2e62493a7e2d9a3a8`).

| Source | E1-unresolved units | Lexical warning | Result |
| --- | ---: | --- | ---: |
| MyFixit | 198,544 | exact frozen-tool mention in step text | 75,247 (37.90%) |
| MyFixit | 198,544 | exact frozen-tool mention in guide title/subject/toolbox context | 195,027 (98.23%) |
| MyFixit | 198,544 | `Tools_extracted` intersects frozen 62-tool universe | 88,757 (44.70%) |
| X-WLP | 2,285 | operation sentence contains a frozen location-family lexical cue | 1,137 (49.76%) |

These are deliberately conservative diagnostic counts, not semantic labels. A cue may not support the exact requested relation, and absence of a cue would not prove silence. But any positive count disproves the blanket implication:

`E1 UNRESOLVED  =>  natural-language source silence`.

Therefore a valid P1 would need a new, per-item silence construction with semantic or deterministic relation-specific guarantees.

### 4.3 Requested-value degeneracy

The E1 runner creates only one replay assertion for each unresolved unit:

- MyFixit uses `universe[0]`, the same tool for every unresolved unit.
- X-WLP uses `universe[0]`, the same location family for every unresolved operation.

The Gate B plan says to draw 300 examples from the 262,903 E1 compiled assertions. Under that instruction, the 50 MyFixit-unresolved and 50 X-WLP-unresolved rows would not cover a representative requested-value distribution. This creates a source×status×requested-value confound and makes the proposed estimate

`P(UNKNOWN | source_status=UNRESOLVED)`

non-generalizable even before model behavior is measured.

## 5. Adversarial vocabulary channel

The context-isolated query generator did not receive the HieraRepair, Route C, P1, seed-paper, or candidate-title vocabulary. Its 20 query families are frozen in:

`reports/pivot/gate_a_blind_adversarial_queries_v0_1.md`.

The blind formulations exposed the following non-project vocabulary:

- evidence sufficiency / unsupported premise acceptance;
- context-grounded verifier bias;
- citation entailment and textual warrant;
- parametric-knowledge leakage;
- unanswerability and selective prediction;
- synthetic qrels noise and automated-assessor bias;
- ranking reversal and judge-mediated evaluation;
- open-world verification ambiguity;
- incomplete-evidence overcrediting.

This channel was productive: it surfaced the evidence-sufficiency, context-faithfulness, construction-aware NEI, and judge-overcrediting lines that make P1 a severe partial collision even though most papers do not use the words “source silence” or “coverage hallucination.”

## 6. Exhaustive-channel audit trail

### 6.1 OpenAlex two-hop graph

- Seeds: UMBRELA; Faggioli et al. 2023; Thomas et al. 2024; LLMJudge; FEVER; *Fact Checking with Insufficient Evidence*; bpref; Lewis et al. 2021.
- Traversal: both references and citations at hop 1; both directions expanded again at hop 2.
- Raw outputs: `reports/pivot/raw/gate_a_openalex/`.
- Completion summary: **incomplete because the provider returned HTTP 429**. The first attempt resolved all 8 seeds, enumerated 1,263 unique hop-1 work IDs, recovered metadata for 1,243 works, and completed 17 of 51 hop-2 citation batches before rate limiting. Its non-checkpointed implementation wrote no final corpus, so these counts are partial execution provenance, not a search result. A checkpointed v0.2 launcher was then created, but the provider returned 429 before its first seed resolution. Exact status and recovery instructions are in `reports/pivot/raw/gate_a_openalex/progress_v0_2.json`.

### 6.2 Semantic Scholar two-hop graph

- Same eight seeds and same bidirectional two-hop definition.
- The keyless Graph API returned HTTP 429 during the exhaustive seed-resolution run. One separate single-paper citation probe succeeded, but it is excluded from completion counts.
- Checkpointed raw outputs: `reports/pivot/raw/gate_a_semantic_scholar/`.
- Completion summary: **incomplete; 0/8 seeds resolved inside the exhaustive run and no two-hop corpus was produced**. Exact provider status is in `reports/pivot/raw/gate_a_semantic_scholar/provider_status_v0_1.json`. Completion requires an API key or quota reset.

### 6.3 DBLP 2024–2026 venue title sweep

- Streams: SIGIR, CIKM, WSDM, ECIR, TREC, ACL, EMNLP, NAACL.
- Years: 2024, 2025, 2026.
- Retrieval design: complete `stream × year` queries via DBLP `search/publ/api`, with every returned title saved before local vocabulary-grid matching.
- Raw outputs and per-query checkpoints: `reports/pivot/raw/gate_a_dblp/`.
- Frozen completion summary: **provider-limited, not exhaustive**. DBLP completed 19 of 24 stream-year queries, partially completed 1, and did not start 4 after persistent HTTP 429/network failures.
- Complete streams include all requested SIGIR, CIKM, WSDM, ECIR, TREC, and ACL years, plus EMNLP 2024. EMNLP 2025 stopped at 2,650 of 3,499 records. EMNLP 2026 and NAACL 2024–2026 were not retrieved.
- Saved corpus: 19,267 raw and unique title records. Local vocabulary-grid matching retained 149 title-screen leads.
- All 149 retained titles were manually read. Obviously out-of-scope general hallucination, generation, safety, and non-IR judge papers were removed at title screen; the surviving substantive collision candidates were checked at abstract/method level and are represented in Section 3. The machine shortlist is retained so this triage can be challenged or repeated.
- Corpus: `reports/pivot/raw/gate_a_dblp/partial_all_titles.jsonl`  
  `sha256:debf57e298c1a07744941f1a4c1a632cf6248d4325a89414e1605df1f7ad8367`
- Machine shortlist: `reports/pivot/raw/gate_a_dblp/partial_candidates.jsonl`  
  `sha256:0b381f4046565521da267ad098d69a5bfd6358d65cc0ed97e91acbcd34c92993`
- Query-by-query coverage and the exact recovery offset are in `reports/pivot/raw/gate_a_dblp/partial_summary.json`.
- No title or subsequently reviewed candidate in this partial venue corpus yielded a strict I+S+R collision. Because 5 query cells are incomplete, this remains a bounded negative result and cannot support a collision-free claim.

The exhaustive audit has asymmetric stopping logic. Complete coverage is required to support a novelty **GO**. It is not required to support the present **STOP**, because the STOP is already independently entailed by (a) verified severe partial collisions and (b) failure of the proposed source-silence construct. Provider failure is therefore recorded as a coverage limitation; it is never converted into an empty result.

## 7. Gate decision

### Literal Claude Gate A

- Strict single-paper I+S+R collision found: **no, under the completed primary-work review so far**.
- Mechanical binary result under the pivot plan's exact-conjunction rule: **not yet certifiable as GO**, because the two citation-graph providers did not complete. The completed evidence supports “not found under reviewed coverage,” not “collision-free.”
- I+R partial collisions: **many and central**.
- S partial collisions: **many and methodologically direct**.
- Result under the frozen collision protocol: `SEVERE_PARTIAL`.

### Scientific decision for WSDM Main Track

`STOP_P1_AS_WRITTEN`.

Reasons:

1. The candidate’s only apparent novelty is a three-literature conjunction, while all component measurements are established.
2. The title/phenomenon space is already crowded by high-confidence overrating, context insufficiency, missing qrels, and ranking-instability work.
3. The current source-status variable does not identify semantic silence.
4. The unresolved requested-value distribution is degenerate.
5. Running Gate B now could produce a clean-looking number that does not estimate the paper’s claimed phenomenon.

This is not a rejection of the broader research problem. It is a rejection of the present operationalization and novelty claim.

## 8. Minimum repair before reconsidering this direction

P1 should return to novelty review only after all four items below exist:

1. **Per-item source-silence certificate.** The exact `document_text` shown to the judge must have a relation-specific, replayable absence/insufficiency construction. Structured-field incompleteness alone is insufficient.
2. **Nondegenerate requested-value design.** Every source×status cell must span a pre-registered requested-value distribution; a single `universe[0]` value is forbidden.
3. **A contribution beyond recombination.** Examples include a formally identified estimand, a construction-aware diagnostic protocol with transfer tests, or an uncertainty-propagation method that changes how IR evaluation should be done.
4. **A second collision audit on the repaired contribution.** It must specifically compare against NEI-CAP, SufficientFacts, Wen et al., *Attribute or Abstain*, missing-qrels filling, LARA, Alaofi et al.'s false-positive interventions, Otero et al.'s top-run/significance analysis, TRUE, topic-specific judge adapters, summarization-based relevance judgment, high-confidence overrating, and incomplete-qrels evaluation.

Until then:

- do not run Gate B;
- do not submit a GPU job;
- do not call non-UNKNOWN answers “fabrication”;
- do not claim “first study of confident judges under source silence”;
- do not update the master plan to make P1 the selected WSDM direction.

## 9. Additional provenance warning from the external review

The Claude review asserts that the owner has a NeurIPS Datasets & Benchmarks work titled *When Grouping Changes Benchmark Winners in Ring-Structure Counting*. No matching file was found in the project workspace, and an exact-title search of public NeurIPS/OpenReview/web records returned no matching paper. This may be a private draft, a differently titled work, or an unsupported assertion.

It must not be cited or used as a self-overlap premise until the owner supplies the actual paper, draft, DOI, or canonical title.
