# Gate C τ-sweep v0.1
## Table 1 · Component structure
source | tau | n_components | top1_share | effective_components | giant_share_of_complete_units | size_max
--- | --- | ---: | ---: | ---: | ---: | ---:
myfixit | exact | 85423 | 0.0017 | 13292.7542 | 0.0002 | 409
myfixit | 0.95 | 85381 | 0.0017 | 13283.4169 | 0.0002 | 409
myfixit | 0.90 | 85155 | 0.0017 | 13152.8796 | 0.0002 | 409
myfixit | 0.85 | 84777 | 0.0017 | 12870.8902 | 0.0002 | 409
myfixit | 0.80 | 84245 | 0.0017 | 12642.9064 | 0.0002 | 409
myfixit | 0.70 | 82987 | 0.0017 | 11873.2606 | 0.0002 | 409
myfixit | 0.60 | 81178 | 0.0025 | 9912.7986 | 0.0147 | 578
myfixit | 0.50 | 78563 | 0.0070 | 6279.5639 | 0.0303 | 1649
xwlp | exact | 2222 | 0.0054 | 1448.5611 | 0.0025 | 21
xwlp | 0.95 | 2222 | 0.0054 | 1448.5611 | 0.0025 | 21
xwlp | 0.90 | 2221 | 0.0054 | 1447.4667 | 0.0025 | 21
xwlp | 0.85 | 2213 | 0.0054 | 1422.4803 | 0.0025 | 21
xwlp | 0.80 | 2206 | 0.0054 | 1410.6972 | 0.0025 | 21
xwlp | 0.70 | 2182 | 0.0054 | 1341.3166 | 0.0025 | 21
xwlp | 0.60 | 2135 | 0.0054 | 1278.0143 | 0.0025 | 21
xwlp | 0.50 | 2083 | 0.0059 | 1204.8758 | 0.0067 | 23
## Table 2 · Closure vs edge-quarantine
source | tau | top1_share_closure | top1_share_edgeq | n_components_closure | n_quarantine_sets_edgeq
--- | --- | ---: | ---: | ---: | ---:
myfixit | exact | 0.0017 | 0.0017 | 85423 | 85423
myfixit | 0.95 | 0.0017 | 0.0017 | 85381 | 85423
myfixit | 0.90 | 0.0017 | 0.0017 | 85155 | 85423
myfixit | 0.85 | 0.0017 | 0.0017 | 84777 | 85423
myfixit | 0.80 | 0.0017 | 0.0017 | 84245 | 85423
myfixit | 0.70 | 0.0017 | 0.0017 | 82987 | 85423
myfixit | 0.60 | 0.0025 | 0.0017 | 81178 | 85423
myfixit | 0.50 | 0.0070 | 0.0019 | 78563 | 85423
xwlp | exact | 0.0054 | 0.0054 | 2222 | 2222
xwlp | 0.95 | 0.0054 | 0.0054 | 2222 | 2222
xwlp | 0.90 | 0.0054 | 0.0054 | 2221 | 2222
xwlp | 0.85 | 0.0054 | 0.0054 | 2213 | 2222
xwlp | 0.80 | 0.0054 | 0.0054 | 2206 | 2222
xwlp | 0.70 | 0.0054 | 0.0054 | 2182 | 2222
xwlp | 0.60 | 0.0054 | 0.0054 | 2135 | 2222
xwlp | 0.50 | 0.0059 | 0.0054 | 2083 | 2222
## Table 3 · Capacity
source | tau | feasible | max_N | failing_cells_count
--- | --- | :---: | ---: | ---:
myfixit | exact | FAIL | 120 | 4
myfixit | 0.95 | FAIL | 120 | 4
myfixit | 0.90 | FAIL | 120 | 4
myfixit | 0.85 | FAIL | 120 | 4
myfixit | 0.80 | FAIL | 120 | 4
myfixit | 0.70 | FAIL | 120 | 4
myfixit | 0.60 | FAIL | 120 | 4
myfixit | 0.50 | FAIL | 120 | 4
xwlp | exact | FAIL | 109 | 7
xwlp | 0.95 | FAIL | 109 | 7
xwlp | 0.90 | FAIL | 115 | 5
xwlp | 0.85 | FAIL | 115 | 5
xwlp | 0.80 | FAIL | 115 | 5
xwlp | 0.70 | FAIL | 106 | 7
xwlp | 0.60 | FAIL | 105 | 7
xwlp | 0.50 | FAIL | 105 | 7
## Table 4 · Winner identity
fixture | source | tau | n_retained | argmax_method | kendall_vs_exact | n_flips_raw | n_flips_holm
--- | --- | --- | ---: | --- | ---: | ---: | ---:
44Q | myfixit | exact | 24 | promptriever_mistral_7b_typed_instruction | 1.0000 | 0 | 0
80Q | myfixit | exact | 2 | lexical_anchor|minilm_anchor_only_flat|minilm_field_late_interaction|minilm_full_query_flat|minilm_hierarchical_late_fusion | 1.0000 | 0 | 0
44Q | myfixit | 0.95 | 24 | promptriever_mistral_7b_typed_instruction | 1.0000 | 0 | 0
80Q | myfixit | 0.95 | 2 | lexical_anchor|minilm_anchor_only_flat|minilm_field_late_interaction|minilm_full_query_flat|minilm_hierarchical_late_fusion | 1.0000 | 0 | 0
44Q | myfixit | 0.90 | 24 | promptriever_mistral_7b_typed_instruction | 1.0000 | 0 | 0
80Q | myfixit | 0.90 | 2 | lexical_anchor|minilm_anchor_only_flat|minilm_field_late_interaction|minilm_full_query_flat|minilm_hierarchical_late_fusion | 1.0000 | 0 | 0
44Q | myfixit | 0.85 | 24 | promptriever_mistral_7b_typed_instruction | 1.0000 | 0 | 0
80Q | myfixit | 0.85 | 2 | lexical_anchor|minilm_anchor_only_flat|minilm_field_late_interaction|minilm_full_query_flat|minilm_hierarchical_late_fusion | 1.0000 | 0 | 0
44Q | myfixit | 0.80 | 24 | promptriever_mistral_7b_typed_instruction | 1.0000 | 0 | 0
80Q | myfixit | 0.80 | 2 | lexical_anchor|minilm_anchor_only_flat|minilm_field_late_interaction|minilm_full_query_flat|minilm_hierarchical_late_fusion | 1.0000 | 0 | 0
44Q | myfixit | 0.70 | 24 | promptriever_mistral_7b_typed_instruction | 1.0000 | 0 | 0
80Q | myfixit | 0.70 | 2 | lexical_anchor|minilm_anchor_only_flat|minilm_field_late_interaction|minilm_full_query_flat|minilm_hierarchical_late_fusion | 1.0000 | 0 | 0
44Q | myfixit | 0.60 | 24 | promptriever_mistral_7b_typed_instruction | 1.0000 | 0 | 0
80Q | myfixit | 0.60 | 2 | lexical_anchor|minilm_anchor_only_flat|minilm_field_late_interaction|minilm_full_query_flat|minilm_hierarchical_late_fusion | 1.0000 | 0 | 0
44Q | myfixit | 0.50 | 24 | promptriever_mistral_7b_typed_instruction | 1.0000 | 0 | 0
80Q | myfixit | 0.50 | 2 | lexical_anchor|minilm_anchor_only_flat|minilm_field_late_interaction|minilm_full_query_flat|minilm_hierarchical_late_fusion | 1.0000 | 0 | 0
44Q | xwlp | exact | 16 | qwen3_reranker_0_6b_typed_instruction | 1.0000 | 0 | 0
80Q | xwlp | exact | 18 | minilm_field_late_interaction|minilm_hierarchical_late_fusion | 1.0000 | 0 | 0
44Q | xwlp | 0.95 | 16 | qwen3_reranker_0_6b_typed_instruction | 1.0000 | 0 | 0
80Q | xwlp | 0.95 | 18 | minilm_field_late_interaction|minilm_hierarchical_late_fusion | 1.0000 | 0 | 0
44Q | xwlp | 0.90 | 16 | qwen3_reranker_0_6b_typed_instruction | 1.0000 | 0 | 0
80Q | xwlp | 0.90 | 18 | minilm_field_late_interaction|minilm_hierarchical_late_fusion | 1.0000 | 0 | 0
44Q | xwlp | 0.85 | 16 | qwen3_reranker_0_6b_typed_instruction | 1.0000 | 0 | 0
80Q | xwlp | 0.85 | 18 | minilm_field_late_interaction|minilm_hierarchical_late_fusion | 1.0000 | 0 | 0
44Q | xwlp | 0.80 | 16 | qwen3_reranker_0_6b_typed_instruction | 1.0000 | 0 | 0
80Q | xwlp | 0.80 | 17 | lexical_anchor|minilm_anchor_only_flat|minilm_field_late_interaction|minilm_full_query_flat|minilm_hierarchical_late_fusion|qwen3_embedding_0_6b_instruction | 0.7868 | 0 | 0
44Q | xwlp | 0.70 | 16 | qwen3_reranker_0_6b_typed_instruction | 1.0000 | 0 | 0
80Q | xwlp | 0.70 | 16 | lexical_anchor|minilm_anchor_only_flat|minilm_field_late_interaction|minilm_full_query_flat|minilm_hierarchical_late_fusion|qwen3_embedding_0_6b_instruction | 0.7868 | 0 | 0
44Q | xwlp | 0.60 | 15 | qwen3_reranker_0_6b_typed_instruction | 0.9231 | 0 | 0
80Q | xwlp | 0.60 | 16 | lexical_anchor|minilm_anchor_only_flat|minilm_field_late_interaction|minilm_full_query_flat|minilm_hierarchical_late_fusion|qwen3_embedding_0_6b_instruction | 0.7868 | 0 | 0
44Q | xwlp | 0.50 | 14 | qwen3_reranker_0_6b_typed_instruction | 0.8462 | 2 | 0
80Q | xwlp | 0.50 | 16 | lexical_anchor|minilm_anchor_only_flat|minilm_field_late_interaction|minilm_full_query_flat|minilm_hierarchical_late_fusion|qwen3_embedding_0_6b_instruction | 0.7868 | 0 | 0
## Table 5 · Surviving flips only
NO SURVIVING FLIPS
## Percolation readout
myfixit: top1_share crosses 0.50 at tau=none ; crosses 0.90 at tau=none
xwlp:    top1_share crosses 0.50 at tau=none ; crosses 0.90 at tau=none
myfixit exact-only top1_share = 0.0017
verdict: GRADUAL
