#!/usr/bin/env python3
"""Independently validate Section 7 against its sole frozen evidence source."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from pathlib import Path
from typing import Any


SOURCE_SHA256 = "7c5c5d28d6731e0ec89e7e4cf76780cfc97d7bf357a2f50d43ac2dad8808f728"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_source(text: str) -> dict[str, dict[str, int | float]]:
    pieces = text.split("### 12.2 C1 完整人口 census", 1)
    if len(pieces) != 2:
        raise ValueError("sole source has no C1 census")
    if "UNRESOLVED` 的比例" not in text:
        raise ValueError("sole source has no exposure definition")
    result: dict[str, dict[str, int | float]] = {}
    for source, label in (("myfixit", "MyFixit"), ("xwlp", "X-WLP")):
        match = re.search(
            rf"{re.escape(label)}：\s*"
            r"- units=([\d,]+)；\s*"
            r"- complete=([\d,]+)；\s*"
            r"- incomplete=([\d,]+)；\s*"
            r"- licensed REFUTED pairs=([\d,]+)；\s*"
            r"- UNRESOLVED pairs=([\d,]+)；\s*"
            r"- naive-negative pairs=([\d,]+)；\s*"
            r"- exposure=\.([0-9]+)。",
            pieces[1],
        )
        if match is None:
            raise ValueError(f"cannot independently parse {label}")
        nums = [int(value.replace(",", "")) for value in match.groups()[:6]]
        units, complete, incomplete, refuted, unresolved, naive = nums
        reported = float("0." + match.group(7))
        if units != complete + incomplete or naive != refuted + unresolved:
            raise ValueError(f"source partitions do not close for {label}")
        exposure = unresolved / naive
        incomplete_fraction = incomplete / units
        if f"{exposure:.6f}" != f"{reported:.6f}":
            raise ValueError(f"reported exposure differs for {label}")
        result[source] = {
            "units": units,
            "complete_units": complete,
            "incomplete_units": incomplete,
            "licensed_refuted_pairs": refuted,
            "unresolved_pairs": unresolved,
            "naive_negative_pairs": naive,
            "reported_exposure": reported,
            "recomputed_exposure": exposure,
            "incomplete_fraction": incomplete_fraction,
            "absolute_fraction_gap": abs(exposure - incomplete_fraction),
            "absolute_percentage_point_gap": 100 * abs(exposure - incomplete_fraction),
            "pairs_per_complete_unit": refuted / complete,
            "pairs_per_incomplete_unit": unresolved / incomplete,
        }
    return result


def close(left: float, right: float) -> bool:
    return math.isclose(left, right, rel_tol=0.0, abs_tol=1e-12)


def compare(expected: Any, actual: Any, path: str = "root") -> None:
    if isinstance(expected, dict):
        if set(expected) != set(actual):
            raise ValueError(f"field mismatch at {path}")
        for key, value in expected.items():
            compare(value, actual[key], f"{path}.{key}")
    elif isinstance(expected, float):
        if not close(expected, float(actual)):
            raise ValueError(f"numeric mismatch at {path}")
    elif expected != actual:
        raise ValueError(f"value mismatch at {path}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--preprint-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--pdf", type=Path)
    args = parser.parse_args()
    source = args.source.resolve()
    preprint = args.preprint_root.resolve()
    if sha256(source) != SOURCE_SHA256:
        raise ValueError("sole evidence-source hash mismatch")
    expected_rows = parse_source(source.read_text(encoding="utf-8"))
    derived = json.loads(
        (preprint / "data/section7_recomputed.json").read_text(encoding="utf-8")
    )
    if derived["sole_evidence_source_sha256"] != SOURCE_SHA256:
        raise ValueError("derived source hash differs")
    compare(expected_rows, derived["corpora"], "corpora")
    expected_scope = {
        "n_corpora": 2,
        "one_exposure_definition_only": True,
        "other_corpora_supported": False,
        "other_exposure_definitions_supported": False,
        "general_uninformativeness_supported": False,
        "published_work_critique": False,
    }
    if derived["scope"] != expected_scope:
        raise ValueError("Section 7 scope metadata differs")

    section = (preprint / "sections/07-coverage-exposure-near-identity.tex").read_text(
        encoding="utf-8"
    )
    if not section.startswith(r"\section{A coverage-exposure near-identity}"):
        raise ValueError("Section 7 current title differs")
    normalized = " ".join(section.split())
    for fragment in (
        "fraction of all pairs that a naive policy would call negative but that the source policy leaves unresolved",
        "The two quantities compared here are therefore $U/(R+U)$ and $I/N$",
        "The near identity follows from the pair weighting in these two records",
        "candidate-universe mass",
        "arithmetic near-identity observed on \\CoverageExposureCorpora{} corpora under one exposure definition",
        "does not establish the same relationship for another exposure definition or another corpus",
        "does not establish that coverage-exposure statistics are uninformative beyond these two cases",
        "carries approximately the same information as the annotated-field completeness rate",
        "not a critique of any published work",
    ):
        if fragment not in normalized:
            raise ValueError(f"required Section 7 scope statement missing: {fragment}")
    if re.search(r"(?<![A-Za-z])0\.\d+", section):
        raise ValueError("Section 7 contains a hand-entered bare decimal")
    if re.search(
        r"\b(?:first|novel(?:ty)?|we\s+prove|in\s+general|all\s+procedural\s+corpora)\b",
        normalized,
        flags=re.I,
    ):
        raise ValueError("Section 7 contains a forbidden claim")
    for unsupported in (
        "other exposure definitions",
        "other corpora",
        "uninformative in general",
        "critique of published work",
    ):
        if unsupported in normalized:
            raise ValueError(f"unsupported positive scope appears: {unsupported}")

    main_tex = (preprint / "main.tex").read_text(encoding="utf-8")
    if "tables/section7_values" not in main_tex:
        raise ValueError("Section 7 values are not included in main.tex")
    if "sections/07-coverage-exposure-near-identity" not in main_tex:
        raise ValueError("Section 7 is not included in main.tex")
    if "tautolog" in main_tex.lower() or "tautolog" in section.lower():
        raise ValueError("superseded Section 7 terminology remains current")
    section_8_started = bool(re.search(r"sections/08", main_tex))
    section_9_started = "sections/09-related-work" in main_tex
    if not section_9_started:
        raise ValueError("approved Section 9 is not included in current main.tex")
    section_10_started = bool(re.search(r"sections/10", main_tex))
    if not section_10_started or main_tex.count(r"\input{sections/10-limitations}") != 1:
        raise ValueError("approved Section 10 is not included exactly once")
    if not (preprint / "sections/10-limitations.tex").is_file():
        raise ValueError("approved Section 10 manuscript is missing")
    section_11_started = main_tex.count(r"\input{sections/11-reproducibility-and-artifact-scope}") == 1
    if not section_11_started or not (preprint / "sections/11-reproducibility-and-artifact-scope.tex").is_file():
        raise ValueError("approved Section 11 is not included exactly once")
    if re.search(r"sections/12", main_tex) or list((preprint / "sections").glob("12-*.tex")):
        raise ValueError("Section 12 was started")

    table = (preprint / "tables/section7_coverage_exposure.tex").read_text(
        encoding="utf-8"
    )
    if re.search(r"(?<![A-Za-z])0\.\d+", table):
        raise ValueError("Section 7 table contains a hand-entered decimal")
    if table.count("CoverageExposure{}") != 2:
        raise ValueError("Section 7 table does not use both exposure macros")

    payload = {
        "status": "PASS",
        "sole_evidence_source_sha256": SOURCE_SHA256,
        "corpora": expected_rows,
        "scope": expected_scope,
        "section_8_started": section_8_started,
        "section_9_started": section_9_started,
        "section_10_started": section_10_started,
        "section_11_started": section_11_started,
        "pdf_sha256": sha256(args.pdf.resolve()) if args.pdf else None,
    }
    args.output.resolve().parent.mkdir(parents=True, exist_ok=True)
    args.output.resolve().write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        "SECTION7_VALIDATION_OK",
        "corpora=2",
        f"myfixit_gap={expected_rows['myfixit']['absolute_fraction_gap']:.6f}",
        f"xwlp_gap={expected_rows['xwlp']['absolute_fraction_gap']:.6f}",
        f"section8={'STARTED' if section_8_started else 'NOT_STARTED'}",
        "section9=STARTED_AND_AUTHORIZED",
        "section10=STARTED_AND_AUTHORIZED",
        "section11=STARTED_AND_AUTHORIZED",
        sep=" | ",
    )


if __name__ == "__main__":
    main()
