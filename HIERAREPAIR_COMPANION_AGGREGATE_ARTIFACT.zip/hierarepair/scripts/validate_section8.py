#!/usr/bin/env python3
"""Independently validate Section 8 against the frozen aggregate Gate A report."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
from pathlib import Path
from typing import Any


SOURCE_SHA256 = "b6c09b6b01e63d9cdd6e13e988a522d2534859eee68a9a6dff49e075a43de285"
EVIDENCE_LEVEL = "HASH_VERIFIED_AGGREGATE_REPORT_RECOMPUTATION"
EXPECTED_COUNTS = {
    "myfixit_step": (198544, 75247),
    "myfixit_context": (198544, 195027),
    "myfixit_tools_extracted": (198544, 88757),
    "xwlp_sentence": (2285, 1137),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_independently(text: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    pieces = text.split("### 4.2 Deterministic lexical lower-bound audit", 1)
    if len(pieces) != 2:
        raise ValueError("construct-validity lexical audit is absent")
    audit, remainder = pieces[1].split("### 4.3 Requested-value degeneracy", 1)
    patterns = [
        (
            "myfixit_step",
            "myfixit",
            "exact frozen-tool mention in step text",
        ),
        (
            "myfixit_context",
            "myfixit",
            "exact frozen-tool mention in guide title/subject/toolbox context",
        ),
        (
            "myfixit_tools_extracted",
            "myfixit",
            "`Tools_extracted` intersects frozen 62-tool universe",
        ),
        (
            "xwlp_sentence",
            "xwlp",
            "operation sentence contains a frozen location-family lexical cue",
        ),
    ]
    rows: list[dict[str, Any]] = []
    for key, source, wording in patterns:
        source_label = "MyFixit" if source == "myfixit" else "X-WLP"
        match = re.search(
            rf"^\| {re.escape(source_label)} \| ([\d,]+) \| "
            rf"{re.escape(wording)} \| ([\d,]+) \(([0-9]+(?:\.[0-9]+)?)%\) \|$",
            audit,
            flags=re.M,
        )
        if match is None:
            raise ValueError(f"cannot independently parse source row: {key}")
        unresolved = int(match.group(1).replace(",", ""))
        positive = int(match.group(2).replace(",", ""))
        reported = float(match.group(3))
        rate = positive / unresolved
        if f"{100 * rate:.2f}" != f"{reported:.2f}":
            raise ValueError(f"reported rate does not reconcile for {key}")
        if (unresolved, positive) != EXPECTED_COUNTS[key]:
            raise ValueError(f"independent counts differ for {key}")
        rows.append(
            {
                "key": key,
                "source": source,
                "unresolved_count": unresolved,
                "positive_count": positive,
                "rate": rate,
                "reported_percent": reported,
                "frozen_diagnostic_wording": wording,
            }
        )
    if (
        "MyFixit uses `universe[0]`, the same tool for every unresolved unit."
        not in remainder
        or "X-WLP uses `universe[0]`, the same location family for every unresolved operation."
        not in remainder
    ):
        raise ValueError("independent requested-value-degeneracy evidence is absent")
    degeneracy = {
        "universe_index": "universe[0]",
        "myfixit": "SAME_TOOL_FOR_EVERY_UNRESOLVED_UNIT",
        "xwlp": "SAME_LOCATION_FAMILY_FOR_EVERY_UNRESOLVED_OPERATION",
        "requested_value_specific_rate": False,
    }
    return rows, degeneracy


def close(left: float, right: float) -> bool:
    return math.isclose(left, right, rel_tol=0.0, abs_tol=1e-12)


def compare(expected: Any, actual: Any, path: str = "root") -> None:
    if isinstance(expected, dict):
        if set(expected) != set(actual):
            raise ValueError(f"field mismatch at {path}")
        for key, value in expected.items():
            compare(value, actual[key], f"{path}.{key}")
    elif isinstance(expected, list):
        if len(expected) != len(actual):
            raise ValueError(f"length mismatch at {path}")
        for index, value in enumerate(expected):
            compare(value, actual[index], f"{path}[{index}]")
    elif isinstance(expected, float):
        if not close(expected, float(actual)):
            raise ValueError(f"numeric mismatch at {path}")
    elif expected != actual:
        raise ValueError(f"value mismatch at {path}")


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--preprint-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--pdf", type=Path)
    args = parser.parse_args()
    source = args.source.resolve()
    preprint = args.preprint_root.resolve()
    if sha256(source) != SOURCE_SHA256:
        raise ValueError("construct-validity source hash mismatch")
    expected_rows, expected_degeneracy = parse_independently(
        source.read_text(encoding="utf-8")
    )
    derived = json.loads(
        (preprint / "data/section8_recomputed.json").read_text(encoding="utf-8")
    )
    if derived["sole_evidence_source_sha256"] != SOURCE_SHA256:
        raise ValueError("generated source hash differs")
    compare(expected_rows, derived["diagnostics"], "diagnostics")
    compare(expected_degeneracy, derived["requested_value_degeneracy"], "degeneracy")
    required_flags = {
        "evidence_level": EVIDENCE_LEVEL,
        "raw_recount_available": False,
        "semantic_labels": False,
        "requested_value_specific_rate": False,
        "out_of_scope_generalization": False,
    }
    for field, expected in required_flags.items():
        if derived[field] != expected:
            raise ValueError(f"Section 8 evidence flag differs: {field}")
    if derived["interpretation"] != {
        "structured_unresolved_certifies_lexical_silence": False,
        "positive_cue_certifies_requested_relation": False,
        "cue_absence_certifies_semantic_silence": False,
        "published_work_critique": False,
    }:
        raise ValueError("Section 8 interpretation boundary differs")

    csv_rows = read_csv(preprint / "tables/section8_lexical_diagnostics.csv")
    if len(csv_rows) != len(expected_rows):
        raise ValueError("Section 8 CSV row count differs")
    for expected, actual in zip(expected_rows, csv_rows):
        for field in ("key", "source", "frozen_diagnostic_wording"):
            if actual[field] != expected[field]:
                raise ValueError(f"Section 8 CSV differs: {field}")
        if int(actual["unresolved_count"]) != expected["unresolved_count"]:
            raise ValueError("Section 8 CSV unresolved count differs")
        if int(actual["positive_count"]) != expected["positive_count"]:
            raise ValueError("Section 8 CSV positive count differs")
        if not close(float(actual["rate"]), expected["rate"]):
            raise ValueError("Section 8 CSV rate differs")

    section = (
        preprint / "sections/08-structured-vs-lexical-silence.tex"
    ).read_text(encoding="utf-8")
    if not section.startswith(r"\section{Structured-field unresolved status does not certify lexical silence}"):
        raise ValueError("Section 8 current title differs")
    normalized = " ".join(section.split())
    for fragment in (
        "structured-field unresolved status does not certify lexical silence",
        "deterministic lexical lower-bound diagnostic",
        "contains at least one exact normalized cue from the frozen tool vocabulary",
        "contains a frozen location-family lexical cue",
        "These matches are not semantic labels",
        "cannot be interpreted as requested-value-specific mention rates",
        "aggregate-report arithmetic reproduction from one hash-verified source document",
        "not a raw-corpus independent recount or an end-to-end reproduction",
        "does not extend to other corpora, relations, fields, or unresolved definitions",
        "not a critique of published work",
    ):
        if fragment not in normalized:
            raise ValueError(f"required Section 8 boundary missing: {fragment}")
    if re.search(r"(?<![A-Za-z])0\.\d+", section):
        raise ValueError("Section 8 contains a hand-entered bare decimal")
    for pattern in (
        r"mentions?\s+the\s+queried\s+tool",
        r"mentions?\s+the\s+requested\s+tool",
        r"the\s+requested\s+location\s+appears",
        r"supports\s+the\s+requested\s+relation",
        r"proves\s+semantic\s+silence",
        r"all\s+unresolved\s+(?:units|operations|items)",
    ):
        if re.search(pattern, normalized, flags=re.I):
            raise ValueError(f"forbidden Section 8 claim: {pattern}")

    table = (preprint / "tables/section8_lexical_diagnostics.tex").read_text(
        encoding="utf-8"
    )
    for macro in (
        "MyFixitStepCueCount",
        "MyFixitContextCueCount",
        "MyFixitToolsFieldCueCount",
        "XWLPSentenceCueCount",
    ):
        if f"\\{macro}{{}}" not in table:
            raise ValueError(f"Section 8 table does not use generated macro: {macro}")

    main_tex = (preprint / "main.tex").read_text(encoding="utf-8")
    if "tables/section8_values" not in main_tex:
        raise ValueError("Section 8 values are not included in main.tex")
    if "sections/08-structured-vs-lexical-silence" not in main_tex:
        raise ValueError("Section 8 is not included in main.tex")
    section_9_started = "sections/09-related-work" in main_tex
    if not section_9_started:
        raise ValueError("approved Section 9 is not included in current main.tex")
    section_10_started = bool(re.search(r"sections/10", main_tex))
    if not section_10_started or main_tex.count(r"\input{sections/10-limitations}") != 1:
        raise ValueError("approved Section 10 is not included exactly once")
    if not (preprint / "sections/10-limitations.tex").is_file():
        raise ValueError("approved Section 10 manuscript is missing")
    section_11_started = main_tex.count(r"\input{sections/11-reproducibility-and-artifact-scope}") == 1
    if not section_11_started or not (preprint / "sections/11-reproducibility-and-artifact-scope.tex").is_file():
        raise ValueError("approved Section 11 is not included exactly once")
    if re.search(r"sections/12", main_tex) or list((preprint / "sections").glob("12-*.tex")):
        raise ValueError("Section 12 was started")

    payload = {
        "status": "PASS",
        "sole_evidence_source_sha256": SOURCE_SHA256,
        "evidence_level": EVIDENCE_LEVEL,
        "raw_recount_available": False,
        "semantic_labels": False,
        "requested_value_specific_rate": False,
        "out_of_scope_generalization": False,
        "diagnostics": expected_rows,
        "requested_value_degeneracy": expected_degeneracy,
        "section_9_started": section_9_started,
        "section_10_started": section_10_started,
        "section_11_started": section_11_started,
        "pdf_sha256": sha256(args.pdf.resolve()) if args.pdf else None,
    }
    args.output.resolve().parent.mkdir(parents=True, exist_ok=True)
    args.output.resolve().write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        "SECTION8_VALIDATION_OK",
        f"rows={len(expected_rows)}",
        f"evidence_level={EVIDENCE_LEVEL}",
        "section9=STARTED_AND_AUTHORIZED",
        "section10=STARTED_AND_AUTHORIZED",
        "section11=STARTED_AND_AUTHORIZED",
        sep=" | ",
    )


if __name__ == "__main__":
    main()
