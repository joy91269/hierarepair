#!/usr/bin/env python3
"""Recompute and render Section 5 from the frozen P3 artifacts."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
from pathlib import Path
from typing import Any, Iterable


HASHES = {
    "p3_audit": "8ddbb5a8701ec538394cfcc65984213215c0540f9520c7792c2259e1663d2a4e",
    "p3_lattice": "009e54e3cc5b41289fb140a28e05aaaabb86d72292ffb824523a4298ba3c3e7e",
    "p3_predictors": "fe82f9689595ed293da67513f7fb1cced52fe3ef4e8d14da20c806a59ff995af",
    "p3_runner": "fcd86cadbd517b388ca2bd63ed2c6fd78b64f189d6b41d54cc51b681534fac70",
}
BRIDGE = "bridge_edge_density"
NAIVE = "mean_union_degree"
SOURCE_LABELS = {
    "human_knowhow": "Human Know-How",
    "myfixit": "MyFixit",
    "openpi": "OpenPI",
    "wiqa": "WIQA",
    "doc2dial": "Doc2Dial",
    "xwlp": "X-WLP",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_verified(path: Path, expected: str) -> dict[str, Any]:
    actual = sha256(path)
    if actual != expected:
        raise ValueError(
            f"canonical hash mismatch for {path}: expected {expected}, found {actual}"
        )
    return json.loads(path.read_text(encoding="utf-8"))


def close(left: float, right: float) -> bool:
    return math.isclose(left, right, rel_tol=0.0, abs_tol=1e-12)


def average_ranks(values: dict[str, float]) -> dict[str, float]:
    """Return ascending average ranks, with 1 assigned to the smallest value."""
    ordered = sorted(values.items(), key=lambda item: (item[1], item[0]))
    ranks: dict[str, float] = {}
    start = 0
    while start < len(ordered):
        stop = start + 1
        while stop < len(ordered) and close(ordered[stop][1], ordered[start][1]):
            stop += 1
        average = ((start + 1) + stop) / 2
        for index in range(start, stop):
            ranks[ordered[index][0]] = average
        start = stop
    return ranks


def pearson(left: Iterable[float], right: Iterable[float]) -> float:
    xs = list(left)
    ys = list(right)
    if len(xs) != len(ys) or len(xs) < 2:
        raise ValueError("correlation requires equal vectors with at least two rows")
    xbar = sum(xs) / len(xs)
    ybar = sum(ys) / len(ys)
    numerator = sum((x - xbar) * (y - ybar) for x, y in zip(xs, ys))
    xnorm = math.sqrt(sum((x - xbar) ** 2 for x in xs))
    ynorm = math.sqrt(sum((y - ybar) ** 2 for y in ys))
    if xnorm == 0 or ynorm == 0:
        raise ValueError("correlation is undefined for a constant vector")
    return numerator / (xnorm * ynorm)


def spearman(left: dict[str, float], right: dict[str, float]) -> float:
    if set(left) != set(right):
        raise ValueError("Spearman vectors have different source sets")
    keys = sorted(left)
    left_ranks = average_ranks(left)
    right_ranks = average_ranks(right)
    return pearson(
        (left_ranks[key] for key in keys),
        (right_ranks[key] for key in keys),
    )


def descending_ranks(values: dict[str, float]) -> dict[str, int]:
    ordered = sorted(values, key=lambda source: (-values[source], source))
    if len(set(values.values())) != len(values):
        raise ValueError("Section 5 rank display assumes no ties")
    return {source: index for index, source in enumerate(ordered, 1)}


def separation(
    values: dict[str, float], qualifiers: set[str]
) -> dict[str, Any]:
    positive = [values[source] for source in values if source in qualifiers]
    negative = [values[source] for source in values if source not in qualifiers]
    if not positive or not negative:
        raise ValueError("separation needs both qualifier classes")
    qualifying_min = min(positive)
    qualifying_max = max(positive)
    nonqualifying_min = min(negative)
    nonqualifying_max = max(negative)
    separates = qualifying_min > nonqualifying_max
    return {
        "separates": separates,
        "orientation": "higher_predicts_qualifying",
        "qualifying_min": qualifying_min,
        "qualifying_max": qualifying_max,
        "nonqualifying_min": nonqualifying_min,
        "nonqualifying_max": nonqualifying_max,
        "threshold": (qualifying_min + nonqualifying_max) / 2 if separates else None,
        "slack": (qualifying_min - nonqualifying_max) / 2 if separates else None,
    }


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows({field: row[field] for field in fields} for row in rows)


def write_values(path: Path, derived: dict[str, Any]) -> None:
    comparison = derived["predictor_comparison"]
    bridge = comparison[BRIDGE]
    naive = comparison[NAIVE]
    deletion = derived["one_source_deletion_separability_audit"]
    values = {
        "MechanismPanelSources": str(derived["n_sources"]),
        "MechanismQualifiers": str(derived["n_qualifiers"]),
        "PredictorCrossRho": f"{derived['cross_predictor_spearman_rho']:.3f}",
        "BridgeOutcomeRho": f"{bridge['spearman_rho_with_C5_top1_share']:.3f}",
        "NaiveOutcomeRho": f"{naive['spearman_rho_with_C5_top1_share']:.3f}",
        "RegisteredOutcomeRhoThreshold": f"{derived['registered_outcome_rho_threshold']:.1f}",
        "PredictorRankDisagreementSources": str(
            len(derived["rank_disagreement_sources"])
        ),
        "PredictorDiscordantPairs": str(derived["discordant_pair_count"]),
        "BridgeSeparationThreshold": f"{bridge['threshold']:.4f}",
        "BridgeSeparationSlack": f"{bridge['slack']:.4f}",
        "BridgeQualifierMinimum": f"{bridge['qualifying_min']:.3f}",
        "BridgeNonqualifierMaximum": f"{bridge['nonqualifying_max']:.3f}",
        "NaiveSeparationThreshold": f"{naive['threshold']:.4f}",
        "NaiveSeparationSlack": f"{naive['slack']:.4f}",
        "DeletionAuditRows": str(deletion["n_deletions"]),
        "DeletionAuditBothClassesRows": str(deletion["both_classes_count"]),
        "DeletionAuditSeparatedRows": str(deletion["separated_count"]),
        "GateTwoVerdict": derived["gate_2"],
        "PThreeFinalVerdict": derived["p3_final"],
    }
    lines = [
        "% Generated by build_section5.py from verified frozen JSON; do not edit."
    ]
    lines.extend(
        rf"\newcommand{{\{name}}}{{{value}}}" for name, value in values.items()
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_source_rank_table(path: Path, rows: list[dict[str, Any]]) -> None:
    lines = [
        "% Generated by build_section5.py; do not edit.",
        r"\begin{center}",
        r"\begin{minipage}{0.86\linewidth}",
        r"\centering",
        r"\captionsetup{hypcap=false}",
        r"\captionof{table}{Frozen predictor values and within-panel descending ranks. The two predictors differ only in the OpenPI/WIQA ordering.}",
        r"\label{tab:section5-source-ranks}",
        r"\small",
        r"\setlength{\tabcolsep}{4pt}",
        r"\begin{tabular}{lcrr}",
        r"\toprule",
        r"Source & Qualifies & Bridge density (rank) & Mean union degree (rank) \\",
        r"\midrule",
    ]
    for row in rows:
        lines.append(
            f"{SOURCE_LABELS[row['source']]} & "
            f"{'yes' if row['qualifies'] else 'no'} & "
            f"{row['bridge_edge_density']:.3f} ({row['bridge_rank']}) & "
            f"{row['mean_union_degree']:.3f} ({row['degree_rank']}) \\\\" 
        )
    lines.extend(
        [
            r"\bottomrule",
            r"\end{tabular}",
            r"\end{minipage}",
            r"\end{center}",
        ]
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_summary_table(path: Path, rows: list[dict[str, Any]]) -> None:
    lines = [
        "% Generated by build_section5.py; do not edit.",
        r"\begin{center}",
        r"\centering",
        r"\captionsetup{hypcap=false}",
        r"\captionof{table}{Frozen separation records for the selected bridge predictor and the registered naive control. Threshold, slack, and outcome correlation are reported for audit completeness; under the preregistered negative-control rule, their numerical differences do not support the bridge predictor.}",
        r"\label{tab:section5-predictor-summary}",
        r"\small",
        r"\setlength{\tabcolsep}{4pt}",
        r"\begin{tabular}{lcccc}",
        r"\toprule",
        r"Predictor & Separates & Threshold & Slack & $\rho_s$ with C5 share \\",
        r"\midrule",
    ]
    labels = {
        BRIDGE: r"\texttt{bridge\_edge\_density}",
        NAIVE: r"\texttt{mean\_union\_degree}",
    }
    for row in rows:
        lines.append(
            f"{labels[row['predictor']]} & "
            f"{'yes' if row['separates'] else 'no'} & "
            f"{row['threshold']:.4f} & {row['slack']:.4f} & "
            f"{row['spearman_rho_with_C5_top1_share']:.3f} \\\\" 
        )
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{center}"])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_deletion_audit_table(path: Path, rows: list[dict[str, Any]]) -> None:
    lines = [
        "% Generated by build_section5.py; do not edit.",
        r"\begin{center}",
        r"\begin{minipage}{0.86\linewidth}",
        r"\centering",
        r"\captionsetup{hypcap=false}",
        r"\captionof{table}{One-source-deletion separability audit for the registered bridge predictor. For each row, the threshold is recomputed on the retained sources and the omitted source is not classified. This is not predictive cross-validation. Because the full panel is strictly separated and both classes remain after every deletion, persistence is mechanically implied and supplies no independent robustness evidence.}",
        r"\label{tab:section5-deletion-audit}",
        r"\small",
        r"\setlength{\tabcolsep}{5pt}",
        r"\begin{tabular}{lccc}",
        r"\toprule",
        r"Omitted source & Separates & Threshold & Slack \\",
        r"\midrule",
    ]
    for row in rows:
        lines.append(
            f"{SOURCE_LABELS[row['omitted_source']]} & "
            f"{'yes' if row['separates'] else 'no'} & "
            f"{row['threshold']:.4f} & {row['slack']:.4f} \\\\" 
        )
    lines.extend(
        [
            r"\bottomrule",
            r"\end{tabular}",
            r"\end{minipage}",
            r"\end{center}",
        ]
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_section11_note(path: Path, derived: dict[str, Any]) -> None:
    risk = derived["section11_decode_risk"]
    lines = [
        "# Section 11 Human Know-How decode-risk insertion note",
        "",
        "Status: validated writing constraint only; Section 11 has not been drafted.",
        "",
        "Required impact path:",
        "",
        "`UTF-8 Turtle label bytes -> unicode_escape mojibake -> normalized step text -> content near-duplicate edges -> C2 and C5 connected-component structure`.",
        "",
        "Frozen aggregate position:",
        "",
        f"- Human Know-How C5 top1 share: `{risk['human_knowhow_union_top1_share']:.8f}` (0.1376 when rounded to four decimals).",
        f"- Human Know-How C5 effective components: `{risk['human_knowhow_union_effective_components']:.6f}` (52.215 when rounded to three decimals).",
        "- Human Know-How C5 currently fails A1 only.",
        f"- Human Know-How C2 frozen top1 share: `{risk['human_knowhow_c2_top1_share']:.9f}`; margin below A1 = 0.01: `{risk['c2_a1_margin']:.9f}`.",
        "",
        "Complete Gate logic:",
        "",
        "### Route (a), conjunctive",
        "",
        "- `top1_share > 0.20`",
        "- **AND** `effective_components < 30`",
        "",
        "Both changes must occur simultaneously:",
        "",
        f"- top1 share must increase by `{risk['a2_margin']:.4f}` (`+{risk['a2_relative_increase_percent']:.0f}%` relative to frozen share 0.1376).",
        f"- effective components must decrease by `{risk['a3_margin']:.2f}` (`-{risk['a3_relative_decrease_percent']:.0f}%` relative to frozen value 52.215).",
        "",
        "### Route (b)",
        "",
        "- `top1_share > 1/3`",
        "",
        "This requires:",
        "",
        f"- top1 share must increase by `{risk['a4_margin']:.4f}` (`+{risk['a4_relative_increase_percent']:.0f}%` relative to frozen share 0.1376).",
        "",
        "Route (a) is binding. Its two conjunctive changes must occur together; neither change alone reaches the frozen requirement of three union failures. The relevant share margin is 0.0624, not the larger Route (b) margin.",
        "",
        "For C2, the frozen top1 share is 0.007897, only 0.002103 below A1 = 0.01. An A1-only reversal would still leave C2 passing A2--A4 and therefore at least 3/4 criteria, so its single-layer status would be unchanged.",
        "",
        "Interpretation boundary:",
        "",
        "These margins are descriptive and do not establish invariance under a corrected parser. No corrected-parser rerun exists. The current evidence is insufficient to require revising the frozen qualifier set; this is not a claim that the qualifier set cannot change. The aggregate result remains frozen while raw-data reproduction remains open.",
        "",
        f"Runner SHA-256: `{HASHES['p3_runner']}`",
        f"Lattice SHA-256: `{HASHES['p3_lattice']}`",
        f"Audit SHA-256: `{HASHES['p3_audit']}`",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    project = args.project_root.resolve()
    output = args.output_root.resolve()

    audit = load_verified(
        project / "raw/phaseB/p3_audit_criteria.json", HASHES["p3_audit"]
    )
    lattice = load_verified(
        project / "raw/phaseB/p3_edge_family_lattice.json", HASHES["p3_lattice"]
    )
    predictors = load_verified(
        project / "raw/phaseB/p3_predictors.json", HASHES["p3_predictors"]
    )
    # The recovered raw runner is intentionally excluded from the aggregate
    # public candidate. Its exact historical hash and decode-risk finding are
    # retained as frozen metadata; this builder does not re-certify raw code.

    eligible = list(audit["gate_eligible_sources"])
    if eligible != list(predictors["gate_eligible_sources"]):
        raise ValueError("predictor and audit source panels differ")
    qualifiers = set(audit["gate"]["qualifying_sources"])
    source_values = predictors["source_values"]
    if set(source_values) != set(eligible):
        raise ValueError("predictor source-value coverage differs from eligible panel")

    bridge_values = {source: float(source_values[source][BRIDGE]) for source in eligible}
    naive_values = {source: float(source_values[source][NAIVE]) for source in eligible}
    c5_share = {
        row["source"]: float(row["top1_share_units"])
        for row in lattice["records"]
        if row["source"] in eligible and row["config"] == "C5"
    }
    if set(c5_share) != set(eligible):
        raise ValueError("missing eligible C5 lattice record")

    bridge_rank = descending_ranks(bridge_values)
    naive_rank = descending_ranks(naive_values)
    disagreement_sources = [
        source for source in eligible if bridge_rank[source] != naive_rank[source]
    ]
    discordant_pairs = 0
    for index, left in enumerate(eligible):
        for right in eligible[index + 1 :]:
            bridge_order = bridge_rank[left] - bridge_rank[right]
            naive_order = naive_rank[left] - naive_rank[right]
            if bridge_order * naive_order < 0:
                discordant_pairs += 1
    cross_rho = spearman(bridge_values, naive_values)
    bridge_sep = separation(bridge_values, qualifiers)
    naive_sep = separation(naive_values, qualifiers)
    bridge_outcome_rho = spearman(bridge_values, c5_share)
    naive_outcome_rho = spearman(naive_values, c5_share)

    canonical_tests = predictors["predictor_tests"]
    for name, recomputed, outcome_rho in (
        (BRIDGE, bridge_sep, bridge_outcome_rho),
        (NAIVE, naive_sep, naive_outcome_rho),
    ):
        canonical = canonical_tests[name]
        for field in (
            "qualifying_min",
            "qualifying_max",
            "nonqualifying_min",
            "nonqualifying_max",
            "threshold",
            "slack",
        ):
            if not close(float(recomputed[field]), float(canonical[field])):
                raise ValueError(f"{name} {field} differs from frozen predictor test")
        if recomputed["separates"] != canonical["separates"]:
            raise ValueError(f"{name} separation decision differs")
        if not close(
            outcome_rho, float(canonical["spearman_rho_with_C5_top1_share"])
        ):
            raise ValueError(f"{name} C5 Spearman correlation differs")

    deletion_rows: list[dict[str, Any]] = []
    canonical_loo = {row["omitted_source"]: row for row in predictors["leave_one_out"]}
    for omitted in eligible:
        subset = {source: value for source, value in bridge_values.items() if source != omitted}
        subset_qualifiers = qualifiers - {omitted}
        both_classes = bool(subset_qualifiers) and len(subset_qualifiers) < len(subset)
        if not both_classes:
            raise ValueError("unexpected leave-one-out class loss")
        row = {"omitted_source": omitted, "both_classes_present": True}
        row.update(separation(subset, subset_qualifiers))
        frozen = canonical_loo[omitted]
        for field in (
            "qualifying_min",
            "qualifying_max",
            "nonqualifying_min",
            "nonqualifying_max",
            "threshold",
            "slack",
        ):
            if not close(float(row[field]), float(frozen[field])):
                raise ValueError(f"leave-one-out mismatch for {omitted}: {field}")
        if row["separates"] != frozen["separates"]:
            raise ValueError(f"leave-one-out decision mismatch for {omitted}")
        row["threshold_recomputed_on_retained_sources"] = True
        row["omitted_source_classified"] = False
        row["persistence_mechanically_implied"] = True
        deletion_rows.append(row)

    if predictors["gate"]["verdict"] != "FAIL":
        raise ValueError("frozen Gate 2 is not FAIL")
    if NAIVE not in predictors["naive_separators"]:
        raise ValueError("registered naive control did not fire in frozen artifact")
    if not bridge_sep["separates"] or not naive_sep["separates"]:
        raise ValueError("expected complete class separation is absent")
    if set(disagreement_sources) != {"openpi", "wiqa"} or discordant_pairs != 1:
        raise ValueError("predictor rank disagreement is not the expected one-pair swap")

    rho_rule = re.search(
        r"Spearman rho>=([0-9]+(?:\.[0-9]+)?)", predictors["gate"]["rule"]
    )
    if not rho_rule:
        raise ValueError("cannot parse registered outcome-correlation threshold")
    registered_outcome_rho_threshold = float(rho_rule.group(1))
    negative_control_complete = {
        "predictor": NAIVE,
        "n_qualifiers_separated": len(qualifiers),
        "n_nonqualifiers_separated": len(eligible) - len(qualifiers),
        "complete_separation": naive_sep["separates"],
        "spearman_rho_with_C5_top1_share": naive_outcome_rho,
        "registered_outcome_rho_threshold": registered_outcome_rho_threshold,
        "meets_registered_outcome_correlation": naive_outcome_rho
        >= registered_outcome_rho_threshold,
        "negative_control_condition_fired": True,
    }
    if not negative_control_complete["meets_registered_outcome_correlation"]:
        raise ValueError("registered naive control misses outcome-correlation condition")

    panel_size_target = {
        "status": "NOT_IDENTIFIED",
        "numerical_target": None,
        "rank_evidence": "Spearman rho=33/35 establishes near-equivalence of predictor rankings",
        "future_design_requirement": "larger result-blind source panel containing sources where bridge_edge_density and mean_union_degree make discordant predictions",
        "reason": "no source sampling design, fitted outcome model, coefficient, effect size, noise model, or target precision criterion is defined",
    }

    comparison = {
        BRIDGE: {**bridge_sep, "spearman_rho_with_C5_top1_share": bridge_outcome_rho},
        NAIVE: {**naive_sep, "spearman_rho_with_C5_top1_share": naive_outcome_rho},
    }
    source_rows = [
        {
            "source": source,
            "qualifies": source in qualifiers,
            BRIDGE: bridge_values[source],
            "bridge_rank": bridge_rank[source],
            NAIVE: naive_values[source],
            "degree_rank": naive_rank[source],
        }
        for source in eligible
    ]
    summary_rows = [
        {
            "predictor": name,
            "separates": comparison[name]["separates"],
            "threshold": comparison[name]["threshold"],
            "slack": comparison[name]["slack"],
            "spearman_rho_with_C5_top1_share": comparison[name][
                "spearman_rho_with_C5_top1_share"
            ],
        }
        for name in (BRIDGE, NAIVE)
    ]

    human_c5 = next(
        row
        for row in lattice["records"]
        if row["source"] == "human_knowhow" and row["config"] == "C5"
    )
    human_c2 = next(
        row
        for row in lattice["records"]
        if row["source"] == "human_knowhow" and row["config"] == "C2"
    )
    a1 = float(audit["criteria"]["A1"]["threshold"])
    a2 = float(audit["criteria"]["A2"]["threshold"])
    a3 = float(audit["criteria"]["A3"]["threshold"])
    a4 = float(audit["criteria"]["A4"]["threshold"])
    human_share = float(human_c5["top1_share_units"])
    human_effective = float(human_c5["effective_components"])
    human_c2_share = float(human_c2["top1_share_units"])
    section11_risk = {
        "risk_path": [
            "UTF-8 Turtle label bytes",
            "unicode_escape mojibake",
            "normalized step text",
            "content near-duplicate edges",
            "C2 and C5 connected-component structure",
        ],
        "human_knowhow_union_top1_share": human_share,
        "human_knowhow_union_effective_components": human_effective,
        "a1_threshold": a1,
        "a2_threshold": a2,
        "a2_margin": a2 - human_share,
        "a2_relative_increase_percent": 100 * (a2 - human_share) / human_share,
        "a3_threshold": a3,
        "a3_margin": human_effective - a3,
        "a3_relative_decrease_percent": 100 * (human_effective - a3) / human_effective,
        "a4_threshold": a4,
        "a4_margin": a4 - human_share,
        "a4_relative_increase_percent": 100 * (a4 - human_share) / human_share,
        "a4_threshold_multiple_of_current_share": a4 / human_share,
        "binding_route": "A2_AND_A3_REVERSE",
        "human_knowhow_c2_top1_share": human_c2_share,
        "c2_a1_margin": a1 - human_c2_share,
        "c2_status_if_a1_reverses_only": "PASS_3_OF_4__SINGLE_LAYER_STATUS_UNCHANGED",
        "corrected_parser_rerun_available": False,
        "frozen_metric_drift_verified": False,
        "interpretation": "release blocker, not evidence to revise frozen qualifier set",
    }

    derived = {
        "version": "section5-recomputed-v0.3-negative-control-complete",
        "input_sha256": HASHES,
        "n_sources": len(eligible),
        "n_qualifiers": len(qualifiers),
        "eligible_sources": eligible,
        "qualifying_sources": sorted(qualifiers),
        "source_rows": source_rows,
        "predictor_comparison": comparison,
        "cross_predictor_spearman_rho": cross_rho,
        "registered_outcome_rho_threshold": registered_outcome_rho_threshold,
        "negative_control_completeness": negative_control_complete,
        "rank_disagreement_sources": disagreement_sources,
        "discordant_pair_count": discordant_pairs,
        "one_source_deletion_separability_audit": {
            "rows": deletion_rows,
            "n_deletions": len(deletion_rows),
            "both_classes_count": sum(row["both_classes_present"] for row in deletion_rows),
            "separated_count": sum(row["separates"] for row in deletion_rows),
            "full_panel_strict_separation": True,
            "persistence_mechanically_implied": True,
            "independent_robustness_evidence": False,
            "predictive_cross_validation": False,
        },
        "panel_size_target": panel_size_target,
        "gate_2": predictors["gate"]["verdict"],
        "p3_final": "FAIL",
        "negative_control_fired": True,
        "design_limitation": "predictor collinearity was not checked before preregistering Gate 2",
        "section11_decode_risk": section11_risk,
    }

    write_json(output / "data/section5_recomputed.json", derived)
    write_csv(
        output / "tables/section5_source_ranks.csv",
        source_rows,
        ["source", "qualifies", BRIDGE, "bridge_rank", NAIVE, "degree_rank"],
    )
    write_csv(
        output / "tables/section5_predictor_summary.csv",
        summary_rows,
        [
            "predictor",
            "separates",
            "threshold",
            "slack",
            "spearman_rho_with_C5_top1_share",
        ],
    )
    write_csv(
        output / "tables/section5_leave_one_out.csv",
        deletion_rows,
        [
            "omitted_source",
            "both_classes_present",
            "separates",
            "threshold",
            "slack",
            "qualifying_min",
            "qualifying_max",
            "nonqualifying_min",
            "nonqualifying_max",
            "threshold_recomputed_on_retained_sources",
            "omitted_source_classified",
            "persistence_mechanically_implied",
        ],
    )
    write_values(output / "tables/section5_values.tex", derived)
    write_source_rank_table(output / "tables/section5_source_ranks.tex", source_rows)
    write_summary_table(output / "tables/section5_predictor_summary.tex", summary_rows)
    write_deletion_audit_table(
        output / "tables/section5_leave_one_out.tex", deletion_rows
    )
    write_section11_note(
        output / "SECTION11_HUMAN_KNOWHOW_DECODE_RISK_NOTE.md", derived
    )
    print(
        "SECTION5_BUILD_OK",
        f"cross_rho={cross_rho:.12f}",
        f"rank_swap={','.join(sorted(disagreement_sources))}",
        "panel_size=NOT_IDENTIFIED",
        f"gate2={predictors['gate']['verdict']}",
        sep=" | ",
    )


if __name__ == "__main__":
    main()
