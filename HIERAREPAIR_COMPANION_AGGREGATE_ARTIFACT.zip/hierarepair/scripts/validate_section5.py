#!/usr/bin/env python3
"""Independent validator for Section 5 generated evidence and claims."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
from pathlib import Path
from typing import Any


HASHES = {
    "p3_audit": "8ddbb5a8701ec538394cfcc65984213215c0540f9520c7792c2259e1663d2a4e",
    "p3_lattice": "009e54e3cc5b41289fb140a28e05aaaabb86d72292ffb824523a4298ba3c3e7e",
    "p3_predictors": "fe82f9689595ed293da67513f7fb1cced52fe3ef4e8d14da20c806a59ff995af",
    "p3_runner": "fcd86cadbd517b388ca2bd63ed2c6fd78b64f189d6b41d54cc51b681534fac70",
}
BRIDGE = "bridge_edge_density"
NAIVE = "mean_union_degree"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load(path: Path, expected: str | None = None) -> Any:
    if expected is not None and sha256(path) != expected:
        raise ValueError(f"hash mismatch: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def close(left: float, right: float) -> bool:
    return math.isclose(left, right, rel_tol=0.0, abs_tol=1e-12)


def ranks(values: dict[str, float]) -> dict[str, float]:
    ordered = sorted(values.items(), key=lambda item: (item[1], item[0]))
    result: dict[str, float] = {}
    index = 0
    while index < len(ordered):
        stop = index + 1
        while stop < len(ordered) and close(ordered[stop][1], ordered[index][1]):
            stop += 1
        average = ((index + 1) + stop) / 2
        for cursor in range(index, stop):
            result[ordered[cursor][0]] = average
        index = stop
    return result


def spearman(left: dict[str, float], right: dict[str, float]) -> float:
    keys = sorted(left)
    if set(keys) != set(right):
        raise ValueError("Spearman source sets differ")
    xs = ranks(left)
    ys = ranks(right)
    xbar = sum(xs.values()) / len(xs)
    ybar = sum(ys.values()) / len(ys)
    numerator = sum((xs[key] - xbar) * (ys[key] - ybar) for key in keys)
    denominator = math.sqrt(
        sum((xs[key] - xbar) ** 2 for key in keys)
        * sum((ys[key] - ybar) ** 2 for key in keys)
    )
    return numerator / denominator


def separation(values: dict[str, float], qualifiers: set[str]) -> dict[str, float | bool]:
    qmin = min(value for source, value in values.items() if source in qualifiers)
    qmax = max(value for source, value in values.items() if source in qualifiers)
    nmin = min(value for source, value in values.items() if source not in qualifiers)
    nmax = max(value for source, value in values.items() if source not in qualifiers)
    separates = qmin > nmax
    return {
        "separates": separates,
        "qualifying_min": qmin,
        "qualifying_max": qmax,
        "nonqualifying_min": nmin,
        "nonqualifying_max": nmax,
        "threshold": (qmin + nmax) / 2,
        "slack": (qmin - nmax) / 2,
    }


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--preprint-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--pdf", type=Path)
    args = parser.parse_args()
    project = args.project_root.resolve()
    preprint = args.preprint_root.resolve()

    audit = load(project / "raw/phaseB/p3_audit_criteria.json", HASHES["p3_audit"])
    lattice = load(
        project / "raw/phaseB/p3_edge_family_lattice.json", HASHES["p3_lattice"]
    )
    predictors = load(
        project / "raw/phaseB/p3_predictors.json", HASHES["p3_predictors"]
    )
    derived = load(preprint / "data/section5_recomputed.json")
    if derived["input_sha256"] != HASHES:
        raise ValueError("Section 5 derived input hashes differ")

    eligible = list(audit["gate_eligible_sources"])
    qualifiers = set(audit["gate"]["qualifying_sources"])
    if eligible != predictors["gate_eligible_sources"]:
        raise ValueError("eligible predictor panel differs")
    source_values = predictors["source_values"]
    bridge = {source: float(source_values[source][BRIDGE]) for source in eligible}
    naive = {source: float(source_values[source][NAIVE]) for source in eligible}
    c5 = {
        row["source"]: float(row["top1_share_units"])
        for row in lattice["records"]
        if row["source"] in eligible and row["config"] == "C5"
    }
    cross_rho = spearman(bridge, naive)
    bridge_rho = spearman(bridge, c5)
    naive_rho = spearman(naive, c5)
    if not close(cross_rho, 33 / 35):
        raise ValueError("cross-predictor Spearman is not 33/35")
    if not close(bridge_rho, float(predictors["predictor_tests"][BRIDGE]["spearman_rho_with_C5_top1_share"])):
        raise ValueError("bridge-to-outcome Spearman differs")
    if not close(naive_rho, float(predictors["predictor_tests"][NAIVE]["spearman_rho_with_C5_top1_share"])):
        raise ValueError("naive-to-outcome Spearman differs")
    rho_rule = re.search(
        r"Spearman rho>=([0-9]+(?:\.[0-9]+)?)", predictors["gate"]["rule"]
    )
    if not rho_rule:
        raise ValueError("cannot parse registered outcome-correlation threshold")
    registered_outcome_rho_threshold = float(rho_rule.group(1))
    if naive_rho < registered_outcome_rho_threshold:
        raise ValueError("registered negative control misses outcome-correlation condition")
    completeness = derived["negative_control_completeness"]
    expected_completeness = {
        "predictor": NAIVE,
        "n_qualifiers_separated": len(qualifiers),
        "n_nonqualifiers_separated": len(eligible) - len(qualifiers),
        "complete_separation": True,
        "spearman_rho_with_C5_top1_share": naive_rho,
        "registered_outcome_rho_threshold": registered_outcome_rho_threshold,
        "meets_registered_outcome_correlation": True,
        "negative_control_condition_fired": True,
    }
    if completeness != expected_completeness:
        raise ValueError("negative-control completeness record differs")
    if not close(
        float(derived["registered_outcome_rho_threshold"]),
        registered_outcome_rho_threshold,
    ):
        raise ValueError("registered outcome-correlation threshold differs")

    descending_bridge = sorted(eligible, key=lambda source: (-bridge[source], source))
    descending_naive = sorted(eligible, key=lambda source: (-naive[source], source))
    if descending_bridge[:4] != descending_naive[:4]:
        raise ValueError("predictor rankings disagree above the final pair")
    if set(descending_bridge[4:]) != {"openpi", "wiqa"}:
        raise ValueError("final rank swap is not OpenPI/WIQA")
    if descending_bridge[4:] == descending_naive[4:]:
        raise ValueError("OpenPI/WIQA did not exchange ranks")

    for name, values, outcome_rho in (
        (BRIDGE, bridge, bridge_rho),
        (NAIVE, naive, naive_rho),
    ):
        recomputed = separation(values, qualifiers)
        generated = derived["predictor_comparison"][name]
        frozen = predictors["predictor_tests"][name]
        if not recomputed["separates"]:
            raise ValueError(f"{name} does not separate")
        for field in (
            "qualifying_min",
            "qualifying_max",
            "nonqualifying_min",
            "nonqualifying_max",
            "threshold",
            "slack",
        ):
            if not close(float(recomputed[field]), float(generated[field])):
                raise ValueError(f"generated {name} {field} differs")
            if not close(float(recomputed[field]), float(frozen[field])):
                raise ValueError(f"frozen {name} {field} differs")
        if not close(outcome_rho, float(generated["spearman_rho_with_C5_top1_share"])):
            raise ValueError(f"generated {name} outcome rho differs")

    deletion_audit = derived["one_source_deletion_separability_audit"]
    generated_deletions = {
        row["omitted_source"]: row for row in deletion_audit["rows"]
    }
    frozen_deletions = {
        row["omitted_source"]: row for row in predictors["leave_one_out"]
    }
    full_bridge = separation(bridge, qualifiers)
    if not (
        full_bridge["separates"]
        and float(full_bridge["qualifying_min"])
        > float(full_bridge["nonqualifying_max"])
    ):
        raise ValueError("full bridge panel does not have strict separation")
    for omitted in eligible:
        subset = {source: value for source, value in bridge.items() if source != omitted}
        retained_qualifiers = qualifiers - {omitted}
        if not retained_qualifiers or len(retained_qualifiers) == len(subset):
            raise ValueError(f"both classes do not remain after deleting {omitted}")
        recomputed = separation(subset, retained_qualifiers)
        for field in ("threshold", "slack", "qualifying_min", "qualifying_max", "nonqualifying_min", "nonqualifying_max"):
            if not close(float(recomputed[field]), float(generated_deletions[omitted][field])):
                raise ValueError(f"generated deletion-audit mismatch: {omitted} {field}")
            if not close(float(recomputed[field]), float(frozen_deletions[omitted][field])):
                raise ValueError(f"frozen deletion-audit mismatch: {omitted} {field}")
        if not recomputed["separates"]:
            raise ValueError(f"deletion-audit separation fails for {omitted}")
        row = generated_deletions[omitted]
        if not row["threshold_recomputed_on_retained_sources"]:
            raise ValueError("deletion threshold was not marked as recomputed")
        if row["omitted_source_classified"]:
            raise ValueError("deletion audit incorrectly classifies omitted source")
        if not row["persistence_mechanically_implied"]:
            raise ValueError("mechanical implication disclosure is absent")

    if deletion_audit != {
        **deletion_audit,
        "n_deletions": len(eligible),
        "both_classes_count": len(eligible),
        "separated_count": len(eligible),
        "full_panel_strict_separation": True,
        "persistence_mechanically_implied": True,
        "independent_robustness_evidence": False,
        "predictive_cross_validation": False,
    }:
        raise ValueError("one-source-deletion audit metadata differs")

    if "panel_scale_sensitivity" in derived:
        raise ValueError("rejected panel-scale calculation remains in current JSON")
    panel_target = derived["panel_size_target"]
    if panel_target["status"] != "NOT_IDENTIFIED" or panel_target["numerical_target"] is not None:
        raise ValueError("current JSON endorses a numerical panel-size target")
    for legacy_key in (
        "residual_variance_fraction",
        "variance_inflation_factor",
        "six_source_precision_equivalent",
    ):
        if legacy_key in json.dumps(derived, sort_keys=True):
            raise ValueError(f"rejected current JSON field remains: {legacy_key}")

    source_csv = read_csv(preprint / "tables/section5_source_ranks.csv")
    summary_csv = read_csv(preprint / "tables/section5_predictor_summary.csv")
    deletion_csv = read_csv(preprint / "tables/section5_leave_one_out.csv")
    if len(source_csv) != 6 or len(summary_csv) != 2 or len(deletion_csv) != 6:
        raise ValueError("Section 5 CSV row count differs")
    if [row["source"] for row in source_csv] != eligible:
        raise ValueError("source-rank CSV order differs")
    if [row["predictor"] for row in summary_csv] != [BRIDGE, NAIVE]:
        raise ValueError("predictor-summary CSV order differs")
    if [row["omitted_source"] for row in deletion_csv] != eligible:
        raise ValueError("deletion-audit CSV order differs")
    if any(row["omitted_source_classified"].lower() != "false" for row in deletion_csv):
        raise ValueError("deletion-audit CSV classifies an omitted source")

    section = (preprint / "sections/05-mechanism-identifiability.tex").read_text(
        encoding="utf-8"
    )
    normalized_section = " ".join(section.split())
    required_fragments = [
        "Under the preregistered Gate~2 rule, the failure is attributable to lack of discriminant validity against the registered negative control, not to absence of an observed bridge association in this six-source panel",
        "did not first test whether the proposed mechanism predictor and its negative control were empirically distinguishable",
        "None of the differences between these outcome correlations, thresholds, or slacks is credited in favor of the bridge predictor",
        "completely separates the two frozen qualifiers from the four nonqualifiers",
        "meeting the registered $\\rho_s\\geq\\RegisteredOutcomeRhoThreshold{}$ condition",
        "satisfies both the separation condition and the outcome-correlation condition, so the negative-control condition fires",
        "Gate~2 remains \\GateTwoVerdict{}, and the frozen P-3 result remains \\PThreeFinalVerdict{}",
        "Three correlations must be kept distinct: bridge-to-C5 is",
        "negative-control-to-C5 is",
        "the cross-predictor correlation is",
        "the threshold is recomputed on the retained sources and the omitted source is not classified; this is not predictive cross-validation",
        "persistence under all \\DeletionAuditRows{} deletions is mechanically implied",
        "supplies no independent robustness evidence",
        "better accounts for the observed association",
        "no defensible numerical panel-size target can be derived",
        "the required number of sources remains unidentified",
    ]
    missing = [
        fragment for fragment in required_fragments if fragment not in normalized_section
    ]
    if missing:
        raise ValueError("required Section 5 disclosure missing: " + "; ".join(missing))
    banned_support_patterns = [
        r"larger\s+slack[^.]{0,100}(?:supports|favors|favours)",
        r"higher\s+(?:rho|correlation)[^.]{0,100}(?:supports|favors|favours)",
        r"bridge(?:_edge_density|\s+density)\s+explains\s+the\s+collapse",
    ]
    for pattern in banned_support_patterns:
        if re.search(pattern, section, flags=re.I):
            raise ValueError(f"forbidden Section 5 support pattern: {pattern}")
    current_section_without_required_disclaimer = re.sub(
        r"this is not predictive cross-validation", "", normalized_section, flags=re.I
    )
    for pattern in (
        r"variance[- ]inflation",
        r"order[- ]of[- ]magnitude",
        r"leave[- ]one[- ]source[- ]out",
        r"cross[- ]validation",
        r"tens rather than six",
        r"not a weak-effect result",
        r"generated the association",
        r"not caused by any single source",
    ):
        if re.search(pattern, current_section_without_required_disclaimer, flags=re.I):
            raise ValueError(f"rejected Section 5 wording remains: {pattern}")

    note = (preprint / "SECTION11_HUMAN_KNOWHOW_DECODE_RISK_NOTE.md").read_text(
        encoding="utf-8"
    )
    for fragment in (
        "unicode_escape mojibake",
        "normalized step text",
        "content near-duplicate edges",
        "C2 and C5 connected-component structure",
        "0.13755823",
        "0.0624",
        "0.1958",
        "### Route (a), conjunctive",
        "**AND** `effective_components < 30`",
        "Both changes must occur simultaneously",
        "relative to frozen share 0.1376",
        "relative to frozen value 52.215",
        "### Route (b)",
        "`top1_share > 1/3`",
        "Route (a) is binding",
        "0.007897",
        "0.002103",
        "single-layer status would be unchanged",
        "descriptive and do not establish invariance",
        "is insufficient to require revising the frozen qualifier set",
        "not a claim that the qualifier set cannot change",
    ):
        if fragment not in note:
            raise ValueError(f"Section 11 decode-risk note missing: {fragment}")
    if re.search(r"(?:incapable of|cannot) chang(?:e|ing) (?:the )?qualifier", note, re.I):
        raise ValueError("Section 11 note overclaims parser-risk invariance")
    human_c5 = next(
        row for row in lattice["records"]
        if row["source"] == "human_knowhow" and row["config"] == "C5"
    )
    human_c2 = next(
        row for row in lattice["records"]
        if row["source"] == "human_knowhow" and row["config"] == "C2"
    )
    risk = derived["section11_decode_risk"]
    criteria = audit["criteria"]
    expected_risk = {
        "a2_margin": float(criteria["A2"]["threshold"]) - float(human_c5["top1_share_units"]),
        "a3_margin": float(human_c5["effective_components"]) - float(criteria["A3"]["threshold"]),
        "a4_margin": float(criteria["A4"]["threshold"]) - float(human_c5["top1_share_units"]),
        "c2_a1_margin": float(criteria["A1"]["threshold"]) - float(human_c2["top1_share_units"]),
    }
    for field, value in expected_risk.items():
        if not close(float(risk[field]), value):
            raise ValueError(f"Section 11 risk field differs: {field}")
    if risk["binding_route"] != "A2_AND_A3_REVERSE":
        raise ValueError("Section 11 binding route differs")
    main_tex = (preprint / "main.tex").read_text(encoding="utf-8")
    if "sections/05-mechanism-identifiability" not in main_tex:
        raise ValueError("Section 5 is not included in main.tex")
    if main_tex.count(r"\input{sections/11-reproducibility-and-artifact-scope}") != 1:
        raise ValueError("authorized Section 11 is not included exactly once")
    if re.search(r"sections/12", main_tex) or list((preprint / "sections").glob("12-*.tex")):
        raise ValueError("Section 12 was started")

    if predictors["gate"]["verdict"] != "FAIL" or NAIVE not in predictors["naive_separators"]:
        raise ValueError("frozen negative-control Gate no longer fails")
    payload = {
        "status": "PASS",
        "canonical_input_sha256": HASHES,
        "n_sources": len(eligible),
        "n_qualifiers": len(qualifiers),
        "cross_predictor_spearman_rho": cross_rho,
        "rank_swap": ["openpi", "wiqa"],
        "bridge_separates": True,
        "naive_separates": True,
        "bridge_to_c5_spearman_rho": bridge_rho,
        "negative_control_to_c5_spearman_rho": naive_rho,
        "registered_outcome_rho_threshold": registered_outcome_rho_threshold,
        "negative_control_meets_outcome_correlation": True,
        "negative_control_condition_fired": True,
        "one_source_deletion_rows": len(eligible),
        "deletion_persistence_mechanically_implied": True,
        "deletion_audit_independent_robustness_evidence": False,
        "gate_2": predictors["gate"]["verdict"],
        "numerical_panel_size_target_identified": False,
        "panel_size_target": None,
        "section11_decode_risk_note": "PASS",
        "pdf_sha256": sha256(args.pdf.resolve()) if args.pdf else None,
    }
    args.output.resolve().parent.mkdir(parents=True, exist_ok=True)
    args.output.resolve().write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        "SECTION5_VALIDATION_OK",
        f"rho={cross_rho:.12f}",
        "rank_swap=openpi,wiqa",
        "panel_size=NOT_IDENTIFIED",
        f"gate2={payload['gate_2']}",
        sep=" | ",
    )


if __name__ == "__main__":
    main()
