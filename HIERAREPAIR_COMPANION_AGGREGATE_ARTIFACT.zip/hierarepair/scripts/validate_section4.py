#!/usr/bin/env python3
"""Independent validator for generated Section 4 evidence artifacts."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
from typing import Any


HASHES = {
    "p2_audit": "c92ec5eafeadb49990dab03f4d37c43c55df74e5a182da1bd6085fc7b6e79051",
    "p3_audit": "8ddbb5a8701ec538394cfcc65984213215c0540f9520c7792c2259e1663d2a4e",
    "p3_lattice": "009e54e3cc5b41289fb140a28e05aaaabb86d72292ffb824523a4298ba3c3e7e",
    "p3_predictors": "fe82f9689595ed293da67513f7fb1cced52fe3ef4e8d14da20c806a59ff995af",
}
LAYERS = {"content-only": "C2", "container-only": "C3", "union": "C5"}
CRITERIA = ("A1", "A2", "A3", "A4")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load(path: Path, expected: str | None = None) -> Any:
    if expected is not None and sha256(path) != expected:
        raise ValueError(f"hash mismatch: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def close(left: float, right: float) -> bool:
    return math.isclose(left, right, rel_tol=0.0, abs_tol=1e-12)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--preprint-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--pdf", type=Path)
    args = parser.parse_args()
    project = args.project_root.resolve()
    preprint = args.preprint_root.resolve()

    p2 = load(project / "raw/phaseB/p2_audit_criteria.json", HASHES["p2_audit"])
    p3 = load(project / "raw/phaseB/p3_audit_criteria.json", HASHES["p3_audit"])
    lattice = load(
        project / "raw/phaseB/p3_edge_family_lattice.json", HASHES["p3_lattice"]
    )
    predictors = load(
        project / "raw/phaseB/p3_predictors.json", HASHES["p3_predictors"]
    )
    derived = load(preprint / "data/section4_recomputed.json")
    if derived["input_sha256"]["p2_audit"] != HASHES["p2_audit"]:
        raise ValueError("derived P2 input hash differs")
    if derived["input_sha256"]["p3_audit"] != HASHES["p3_audit"]:
        raise ValueError("derived P3 audit input hash differs")
    if derived["input_sha256"]["p3_lattice"] != HASHES["p3_lattice"]:
        raise ValueError("derived lattice input hash differs")
    if p2["criteria"] != p3["criteria"]:
        raise ValueError("P2/P3 criteria differ")

    eligible = p3["gate_eligible_sources"]
    metrics = {
        (row["source"], row["config"]): row
        for row in lattice["records"]
        if row["source"] in eligible and row["config"] in LAYERS.values()
    }
    frozen = {
        (row["source"], row["layer"], row["criterion"]): row
        for row in p3["records"]
        if row["gate_eligible"]
    }
    generated = {
        (row["source"], row["layer"], row["criterion"]): row
        for row in derived["recomputed_records"]
    }
    if len(metrics) != 18 or len(frozen) != 72 or len(generated) != 72:
        raise ValueError("unexpected independent-validation record count")

    matrix: list[dict[str, Any]] = []
    qualifiers = set(p3["gate"]["qualifying_sources"])
    for source in eligible:
        union: dict[str, str] = {}
        for layer, config in LAYERS.items():
            metric = metrics[(source, config)]
            share = float(metric["top1_share_units"])
            effective = float(metric["effective_components"])
            for criterion in CRITERIA:
                threshold = float(p3["criteria"][criterion]["threshold"])
                observed = effective if criterion == "A3" else share
                passed = observed >= threshold if criterion == "A3" else observed <= threshold
                result = "PASS" if passed else "FAIL"
                key = (source, layer, criterion)
                if frozen[key]["outcome"] != result or generated[key]["outcome"] != result:
                    raise ValueError(f"outcome mismatch: {key}")
                if not close(float(generated[key]["observed"]), observed):
                    raise ValueError(f"generated observed mismatch: {key}")
                if layer == "union":
                    union[criterion] = result
        fail_count = sum(union[name] == "FAIL" for name in ("A2", "A3", "A4"))
        matrix.append(
            {
                "source": source,
                "union_A1": union["A1"],
                "union_A2": union["A2"],
                "union_A3": union["A3"],
                "union_A4": union["A4"],
                "A2_A4_fail_count": fail_count,
                "frozen_qualifying": source in qualifiers,
            }
        )
    if matrix != derived["source_matrix"]:
        raise ValueError("independent source matrix differs from generated JSON")
    if {row["A2_A4_fail_count"] for row in matrix} != {0, 3}:
        raise ValueError("A2--A4 complete separation missing")
    if not all(row["union_A1"] == "FAIL" for row in matrix):
        raise ValueError("not every union fails A1")
    if any((row["A2_A4_fail_count"] == 3) != row["frozen_qualifying"] for row in matrix):
        raise ValueError("matrix disagrees with frozen qualifier status")

    with (preprint / "tables/section4_union_criteria.csv").open(
        encoding="utf-8", newline=""
    ) as stream:
        csv_rows = list(csv.DictReader(stream))
    if len(csv_rows) != len(matrix):
        raise ValueError("Section 4 CSV row count differs")
    # Length equality is checked immediately above.  Avoid ``strict=True`` so
    # the validator also runs on the macOS system Python 3.9.
    for csv_row, row in zip(csv_rows, matrix):
        if csv_row["source"] != row["source"]:
            raise ValueError("Section 4 CSV source order differs")
        for criterion in CRITERIA:
            if csv_row[f"union_{criterion}"] != row[f"union_{criterion}"]:
                raise ValueError("Section 4 CSV outcome differs")
        if int(csv_row["A2_A4_fail_count"]) != row["A2_A4_fail_count"]:
            raise ValueError("Section 4 CSV failure count differs")

    frozen_set = set(p3["gate"]["qualifying_sources"])
    if p3["gate"]["verdict"] != "PASS":
        raise ValueError("Gate 1 is not frozen PASS")
    if predictors["gate"]["verdict"] != "FAIL":
        raise ValueError("Gate 2 is not frozen FAIL")
    for values in derived["robustness"]["cutoff_sets"].values():
        if set(values) != frozen_set:
            raise ValueError("cutoff robustness set differs")
    for values in derived["robustness"]["single_criterion_sets"].values():
        if set(values) != frozen_set:
            raise ValueError("single-criterion robustness set differs")

    payload = {
        "status": "PASS",
        "canonical_input_sha256": HASHES,
        "eligible_lattice_records": len(metrics),
        "eligible_criterion_records": len(generated),
        "csv_rows": len(csv_rows),
        "qualifying_sources": p3["gate"]["qualifying_sources"],
        "gate_1": p3["gate"]["verdict"],
        "gate_2": predictors["gate"]["verdict"],
        "a2_a4_complete_separation": True,
        "all_cutoff_and_single_criterion_sets_match_frozen": True,
        "pdf_sha256": sha256(args.pdf.resolve()) if args.pdf else None,
    }
    args.output.resolve().write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        "SECTION4_VALIDATION_OK",
        f"records={len(generated)}",
        f"csv={len(csv_rows)}",
        f"gate1={payload['gate_1']}",
        f"gate2={payload['gate_2']}",
        sep=" | ",
    )


if __name__ == "__main__":
    main()
