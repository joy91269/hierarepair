#!/usr/bin/env python3
"""Build Figure 1 as a native-LaTeX vector PDF from frozen aggregate data."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any


LATTICE_SHA256 = "009e54e3cc5b41289fb140a28e05aaaabb86d72292ffb824523a4298ba3c3e7e"
AUDIT_SHA256 = "8ddbb5a8701ec538394cfcc65984213215c0540f9520c7792c2259e1663d2a4e"
CSV_SHA256_PRE_FONT_PATCH = "96e2184633348c255413bd66b3e47ccdc0799553a93621ed766811febaa1d25d"
PREVIOUS_FIGURE_SHA256 = "329b18ba89cb16da12017372f3fb0de2ddf8255ef5586c256a21982ce087aff4"
PREVIOUS_BUILDER_SHA256 = "5288db67862ec05c7d9848c4b93f2df2b6d3bd6a3d21d8fcbd45caae0e100b8e"

SOURCE_ORDER = ["doc2dial", "myfixit", "human_knowhow", "openpi", "wiqa", "xwlp"]
SOURCE_LABELS = {
    "doc2dial": "Doc2Dial",
    "myfixit": "MyFixit",
    "human_knowhow": "Human Know-How",
    "openpi": "OpenPI",
    "wiqa": "WIQA",
    "xwlp": "X-WLP",
}
LABEL_TO_SOURCE = {value: key for key, value in SOURCE_LABELS.items()}
LAYER_ORDER = ["C2", "C3", "C5"]
LAYER_LABELS = {
    "C2": "Content-only (C2)",
    "C3": "Container-only (C3)",
    "C5": "Union (C5)",
}
EXPECTED_QUALIFIERS = {"doc2dial", "myfixit"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path, expected_hash: str) -> dict[str, Any]:
    actual = sha256(path)
    if actual != expected_hash:
        raise ValueError(f"frozen hash mismatch for {path}: {actual}")
    return json.loads(path.read_text(encoding="utf-8"))


def load_csv(path: Path) -> dict[tuple[str, str], dict[str, str]]:
    if sha256(path) != CSV_SHA256_PRE_FONT_PATCH:
        raise ValueError("canonical Section 3 CSV changed before the font-only patch")
    with path.open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != len(SOURCE_ORDER) * len(LAYER_ORDER):
        raise ValueError(f"expected 18 CSV rows, found {len(rows)}")
    result: dict[tuple[str, str], dict[str, str]] = {}
    for row in rows:
        source = LABEL_TO_SOURCE.get(row["source"])
        if source is None or row["config"] not in LAYER_ORDER:
            raise ValueError(f"unrecognized CSV identity: {row}")
        key = (source, row["config"])
        if key in result:
            raise ValueError(f"duplicate CSV identity: {key}")
        result[key] = row
    return result


def select_rows(lattice: dict[str, Any]) -> dict[tuple[str, str], dict[str, Any]]:
    eligible = lattice["sources"]["gate_eligible"]
    if set(eligible) != set(SOURCE_ORDER):
        raise ValueError(f"gate-eligible source set changed: {eligible}")
    rows = {
        (row["source"], row["config"]): row
        for row in lattice["records"]
        if row["source"] in SOURCE_ORDER and row["config"] in LAYER_ORDER
    }
    expected = {(source, layer) for source in SOURCE_ORDER for layer in LAYER_ORDER}
    if set(rows) != expected:
        raise ValueError("frozen lattice does not contain exactly the 18 plotted rows")
    return rows


def reconcile_csv(
    rows: dict[tuple[str, str], dict[str, Any]],
    csv_rows: dict[tuple[str, str], dict[str, str]],
) -> None:
    for key, row in rows.items():
        csv_row = csv_rows[key]
        if (
            csv_row["layer"] != LAYER_LABELS[key[1]]
            or csv_row["config"] != key[1]
            or str(csv_row["tau"]) != str(row["tau"])
            or int(csv_row["n_components"]) != int(row["n_components"])
            or float(csv_row["top1_share_units"]) != float(row["top1_share_units"])
            or float(csv_row["effective_components"]) != float(row["effective_components"])
        ):
            raise ValueError(f"CSV/JSON disagreement for {key}")


def tex_escape(value: str) -> str:
    return value.replace("&", r"\&").replace("%", r"\%").replace("_", r"\_")


def qline(x1: float, y1: float, x2: float, y2: float) -> str:
    xm = (x1 + x2) / 2
    ym = (y1 + y2) / 2
    return (
        rf"\qbezier({x1:.3f},{y1:.3f})"
        rf"({xm:.3f},{ym:.3f})({x2:.3f},{y2:.3f})"
    )


def scientific_payload(
    rows: dict[tuple[str, str], dict[str, Any]], qualifiers: set[str]
) -> dict[str, Any]:
    y_min, y_max = 1e-4, 1.1
    bottom, top = 55.0, 275.0
    x_positions = {"C2": 120.0, "C3": 290.0, "C5": 460.0}

    def y_position(value: float) -> float:
        low, high = math.log10(y_min), math.log10(y_max)
        return bottom + (math.log10(value) - low) / (high - low) * (top - bottom)

    plotted: list[dict[str, Any]] = []
    for source in SOURCE_ORDER:
        for layer in LAYER_ORDER:
            value = float(rows[(source, layer)]["top1_share_units"])
            plotted.append(
                {
                    "source": source,
                    "source_label": SOURCE_LABELS[source],
                    "layer": layer,
                    "layer_label": LAYER_LABELS[layer],
                    "value": value,
                    "x": x_positions[layer],
                    "y": y_position(value),
                    "qualifier": source in qualifiers,
                }
            )
    endpoints = []
    raw_positions = [
        [source, y_position(float(rows[(source, "C5")]["top1_share_units"]))]
        for source in SOURCE_ORDER
    ]
    arranged = [[source, raw_y, raw_y] for source, raw_y in raw_positions]
    arranged.sort(key=lambda item: item[1])
    for index in range(1, len(arranged)):
        arranged[index][2] = max(arranged[index][2], arranged[index - 1][2] + 13.0)
    overflow = arranged[-1][2] - top
    if overflow > 0:
        for item in arranged:
            item[2] -= overflow
    for source, raw_y, label_y in arranged:
        value = float(rows[(source, "C5")]["top1_share_units"])
        endpoints.append(
            {
                "source": source,
                "label": f"{SOURCE_LABELS[source]}  {value:.4f}",
                "value": value,
                "raw_y": raw_y,
                "label_y": label_y,
            }
        )
    return {
        "version": "section3-figure-input-v1.0",
        "canonical_inputs": {
            "lattice": "raw/phaseB/p3_edge_family_lattice.json",
            "lattice_sha256": LATTICE_SHA256,
            "audit": "raw/phaseB/p3_audit_criteria.json",
            "audit_sha256": AUDIT_SHA256,
            "csv": "preprint/tables/section3_lattice.csv",
            "csv_sha256": CSV_SHA256_PRE_FONT_PATCH,
        },
        "previous_figure": {
            "pdf_sha256": PREVIOUS_FIGURE_SHA256,
            "builder_sha256": PREVIOUS_BUILDER_SHA256,
            "scientific_contract": "same six sources, C2/C3/C5, log axis, frozen qualifier highlighting, and C5 endpoint labels",
        },
        "source_order": SOURCE_ORDER,
        "layer_order": LAYER_ORDER,
        "qualifying_sources": sorted(qualifiers),
        "axis": {"scale": "log10", "minimum": y_min, "maximum": y_max},
        "plotted_values": plotted,
        "union_endpoint_labels": endpoints,
        "encoding": {
            "qualifiers": "thick line plus filled source-specific marker plus bold direct label",
            "nonqualifiers": "thin gray line plus open-circle marker plus regular direct label",
            "color_only": False,
        },
        "caption_boundary": "audit outcome, not a causal explanation",
        "scientific_values_changed": False,
    }


def write_tex(path: Path, payload: dict[str, Any]) -> None:
    by_key = {
        (row["source"], row["layer"]): row for row in payload["plotted_values"]
    }
    lines = [
        r"\documentclass{article}",
        r"\usepackage[paperwidth=9in,paperheight=4.30in,margin=0in]{geometry}",
        r"\usepackage{xcolor}",
        r"\pagestyle{empty}",
        r"\setlength{\parindent}{0pt}",
        r"\definecolor{qualblue}{RGB}{21,95,160}",
        r"\definecolor{qualorange}{RGB}{180,72,42}",
        r"\definecolor{nongray}{RGB}{112,118,126}",
        r"\definecolor{gridgray}{RGB}{217,221,227}",
        r"\begin{document}",
        r"\noindent\begin{picture}(648,310)(0,0)",
    ]
    for tick in [1e-4, 1e-3, 1e-2, 1e-1, 1.0]:
        low = math.log10(payload["axis"]["minimum"])
        high = math.log10(payload["axis"]["maximum"])
        y = 55 + (math.log10(tick) - low) / (high - low) * 220
        label = "1" if tick == 1.0 else f"{tick:g}"
        lines.extend(
            [
                r"\color{gridgray}\linethickness{0.4pt}" + qline(80, y, 460, y),
                rf"\put(72,{y - 2:.3f}){{\makebox(0,0)[r]{{\scriptsize\color{{black}} {label}}}}}",
            ]
        )
    lines.extend(
        [
            r"\color{black}\linethickness{0.7pt}" + qline(80, 55, 80, 275),
            r"\put(80,293){\makebox(0,0)[l]{\small Largest-component share (log scale)}}",
        ]
    )
    x_positions = {"C2": 120.0, "C3": 290.0, "C5": 460.0}
    for layer in LAYER_ORDER:
        x = x_positions[layer]
        lines.extend(
            [
                r"\color{black}\linethickness{0.7pt}" + qline(x, 55, x, 51),
                rf"\put({x:.3f},37){{\makebox(0,0)[c]{{\scriptsize {tex_escape(LAYER_LABELS[layer])}}}}}",
            ]
        )
    for source in reversed(SOURCE_ORDER):
        qualifier = source in set(payload["qualifying_sources"])
        color = "qualblue" if source == "doc2dial" else "qualorange" if source == "myfixit" else "nongray"
        width = "1.6pt" if qualifier else "0.45pt"
        lines.append(rf"\color{{{color}}}\linethickness{{{width}}}")
        points = [(by_key[(source, layer)]["x"], by_key[(source, layer)]["y"]) for layer in LAYER_ORDER]
        lines.append(qline(*points[0], *points[1]))
        lines.append(qline(*points[1], *points[2]))
        for x, y in points:
            if source == "doc2dial":
                lines.append(rf"\put({x - 3:.3f},{y - 3:.3f}){{\rule{{6pt}}{{6pt}}}}")
            elif source == "myfixit":
                lines.append(rf"\put({x:.3f},{y:.3f}){{\circle*{{6}}}}")
            else:
                lines.append(rf"\put({x:.3f},{y:.3f}){{\circle{{4}}}}")
    endpoints = {row["source"]: row for row in payload["union_endpoint_labels"]}
    for source in SOURCE_ORDER:
        row = endpoints[source]
        color = "qualblue" if source == "doc2dial" else "qualorange" if source == "myfixit" else "nongray"
        lines.append(rf"\color{{{color}}}\linethickness{{0.6pt}}" + qline(464, row["raw_y"], 474, row["label_y"]))
        label = tex_escape(row["label"])
        if source in set(payload["qualifying_sources"]):
            label = rf"\textbf{{{label}}}"
        lines.append(rf"\put(478,{row['label_y'] - 2.5:.3f}){{\makebox(0,0)[l]{{\scriptsize\color{{black}} {label}}}}}")
    lines.extend(
        [
            r"\put(80,13){\makebox(0,0)[l]{\scriptsize Thick filled-marker lines satisfy the frozen source gate; thin open-marker lines do not.}}",
            r"\end{picture}",
            r"\end{document}",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def resolve_tool(explicit: str | None, name: str) -> str:
    if explicit:
        return str(Path(explicit).resolve())
    found = shutil.which(name)
    if found is None:
        raise RuntimeError(f"{name} is required but was not found")
    return found


def compile_figure(tex: Path, destination: Path, tectonic: str) -> None:
    environment = dict(os.environ)
    environment["SOURCE_DATE_EPOCH"] = "0"
    with tempfile.TemporaryDirectory(prefix="hierarepair-figure1-") as raw:
        output = Path(raw) / "out"
        output.mkdir()
        result = subprocess.run(
            [tectonic, "-X", "compile", "--only-cached", str(tex), "--outdir", str(output)],
            capture_output=True,
            text=True,
            env=environment,
        )
        if result.returncode != 0:
            raise RuntimeError(f"Figure 1 Tectonic compile failed:\n{result.stdout}\n{result.stderr}")
        built = output / tex.with_suffix(".pdf").name
        if not built.is_file():
            raise RuntimeError("Figure 1 compile produced no PDF")
        shutil.copy2(built, destination)


def render_png(pdf: Path, png: Path, pdftoppm: str) -> None:
    prefix = png.with_suffix("")
    subprocess.run(
        [pdftoppm, "-png", "-r", "180", "-singlefile", str(pdf), str(prefix)],
        check=True,
        capture_output=True,
        text=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--tectonic")
    parser.add_argument("--pdftoppm")
    args = parser.parse_args()
    project = args.project_root.resolve()
    output = args.output_root.resolve()
    lattice = load_json(project / "raw/phaseB/p3_edge_family_lattice.json", LATTICE_SHA256)
    audit = load_json(project / "raw/phaseB/p3_audit_criteria.json", AUDIT_SHA256)
    csv_rows = load_csv(project / "preprint/tables/section3_lattice.csv")
    rows = select_rows(lattice)
    reconcile_csv(rows, csv_rows)
    qualifiers = set(audit["gate"]["qualifying_sources"])
    if qualifiers != EXPECTED_QUALIFIERS:
        raise ValueError(f"frozen qualifier set changed: {qualifiers}")
    payload = scientific_payload(rows, qualifiers)

    data_dir = output / "data"
    figure_dir = output / "figures"
    data_dir.mkdir(parents=True, exist_ok=True)
    figure_dir.mkdir(parents=True, exist_ok=True)
    json_path = data_dir / "section3_figure_input.json"
    tex_path = figure_dir / "section3_union_collapse.tex"
    pdf_path = figure_dir / "section3_union_collapse.pdf"
    png_path = figure_dir / "section3_union_collapse.png"
    json_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    write_tex(tex_path, payload)
    compile_figure(tex_path, pdf_path, resolve_tool(args.tectonic, "tectonic"))
    render_png(pdf_path, png_path, resolve_tool(args.pdftoppm, "pdftoppm"))
    print(
        "SECTION3_FIGURE_BUILD_OK",
        "values=18",
        "endpoints=6",
        "scale=log10",
        "qualifiers=doc2dial,myfixit",
        sep=" | ",
    )


if __name__ == "__main__":
    main()
