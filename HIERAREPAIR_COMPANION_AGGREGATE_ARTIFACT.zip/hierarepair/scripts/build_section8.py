#!/usr/bin/env python3
"""Build Section 8 from one hash-verified aggregate Gate A report."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
from pathlib import Path
from typing import Any


SOURCE_SHA256 = "b6c09b6b01e63d9cdd6e13e988a522d2534859eee68a9a6dff49e075a43de285"
EVIDENCE_LEVEL = "HASH_VERIFIED_AGGREGATE_REPORT_RECOMPUTATION"
EXPECTED_COUNTS = {
    "myfixit_step": (198544, 75247),
    "myfixit_context": (198544, 195027),
    "myfixit_tools_extracted": (198544, 88757),
    "xwlp_sentence": (2285, 1137),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def integer(value: str) -> int:
    return int(value.replace(",", ""))


def table_rows(section: str) -> list[dict[str, str]]:
    lines = section.splitlines()
    header_index = next(
        index for index, line in enumerate(lines) if line.startswith("| Source |")
    )
    header = [cell.strip() for cell in lines[header_index].strip("|").split("|")]
    rows: list[dict[str, str]] = []
    for line in lines[header_index + 2 :]:
        if not line.startswith("|"):
            break
        values = [cell.strip() for cell in line.strip("|").split("|")]
        if len(values) != len(header):
            raise ValueError(f"malformed construct-validity table row: {line}")
        rows.append(dict(zip(header, values)))
    return rows


def parse_source(text: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    start_marker = "### 4.2 Deterministic lexical lower-bound audit"
    stop_marker = "### 4.3 Requested-value degeneracy"
    if start_marker not in text or stop_marker not in text:
        raise ValueError("required construct-validity subsections are absent")
    audit_text = text.split(start_marker, 1)[1].split(stop_marker, 1)[0]
    rows = table_rows(audit_text)
    if len(rows) != 4:
        raise ValueError(f"expected four aggregate diagnostic rows, found {len(rows)}")

    key_by_warning = {
        "exact frozen-tool mention in step text": "myfixit_step",
        "exact frozen-tool mention in guide title/subject/toolbox context": "myfixit_context",
        "`Tools_extracted` intersects frozen 62-tool universe": "myfixit_tools_extracted",
        "operation sentence contains a frozen location-family lexical cue": "xwlp_sentence",
    }
    parsed: list[dict[str, Any]] = []
    for row in rows:
        warning = row["Lexical warning"]
        if warning not in key_by_warning:
            raise ValueError(f"unrecognized frozen diagnostic: {warning}")
        match = re.fullmatch(r"([\d,]+) \(([0-9]+(?:\.[0-9]+)?)%\)", row["Result"])
        if match is None:
            raise ValueError(f"cannot parse aggregate diagnostic result: {row['Result']}")
        unresolved = integer(row["E1-unresolved units"])
        positive = integer(match.group(1))
        reported_percent = float(match.group(2))
        recomputed_rate = positive / unresolved
        if f"{100 * recomputed_rate:.2f}" != f"{reported_percent:.2f}":
            raise ValueError(f"reported percentage does not reconcile: {warning}")
        key = key_by_warning[warning]
        expected = EXPECTED_COUNTS[key]
        if (unresolved, positive) != expected:
            raise ValueError(
                f"independently parsed counts differ for {key}: "
                f"{(unresolved, positive)} != {expected}"
            )
        source = "myfixit" if row["Source"] == "MyFixit" else "xwlp"
        if row["Source"] not in {"MyFixit", "X-WLP"}:
            raise ValueError(f"unexpected source label: {row['Source']}")
        parsed.append(
            {
                "key": key,
                "source": source,
                "unresolved_count": unresolved,
                "positive_count": positive,
                "rate": recomputed_rate,
                "reported_percent": reported_percent,
                "frozen_diagnostic_wording": warning,
            }
        )

    degeneracy_text = text.split(stop_marker, 1)[1].split("## 5.", 1)[0]
    myfixit_phrase = (
        "MyFixit uses `universe[0]`, the same tool for every unresolved unit."
    )
    xwlp_phrase = (
        "X-WLP uses `universe[0]`, the same location family for every unresolved operation."
    )
    if myfixit_phrase not in degeneracy_text or xwlp_phrase not in degeneracy_text:
        raise ValueError("requested-value degeneracy statements are absent")
    degeneracy = {
        "universe_index": "universe[0]",
        "myfixit": "SAME_TOOL_FOR_EVERY_UNRESOLVED_UNIT",
        "xwlp": "SAME_LOCATION_FAMILY_FOR_EVERY_UNRESOLVED_OPERATION",
        "requested_value_specific_rate": False,
    }
    return parsed, degeneracy


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = [
        "key",
        "source",
        "unresolved_count",
        "positive_count",
        "rate",
        "display_percent",
        "frozen_diagnostic_wording",
    ]
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            out = dict(row)
            out.pop("reported_percent")
            out["display_percent"] = f"{100 * row['rate']:.2f}%"
            writer.writerow(out)


def write_values(path: Path, rows: list[dict[str, Any]]) -> None:
    by_key = {row["key"]: row for row in rows}
    values = {
        "LexicalAuditCorpora": "2",
        "MyFixitUnresolvedUnits": f"{by_key['myfixit_step']['unresolved_count']:,}",
        "MyFixitStepCueCount": f"{by_key['myfixit_step']['positive_count']:,}",
        "MyFixitStepCueRate": f"{100 * by_key['myfixit_step']['rate']:.2f}\\%",
        "MyFixitContextCueCount": f"{by_key['myfixit_context']['positive_count']:,}",
        "MyFixitContextCueRate": f"{100 * by_key['myfixit_context']['rate']:.2f}\\%",
        "MyFixitToolsFieldCueCount": f"{by_key['myfixit_tools_extracted']['positive_count']:,}",
        "MyFixitToolsFieldCueRate": f"{100 * by_key['myfixit_tools_extracted']['rate']:.2f}\\%",
        "XWLPUnresolvedOperations": f"{by_key['xwlp_sentence']['unresolved_count']:,}",
        "XWLPSentenceCueCount": f"{by_key['xwlp_sentence']['positive_count']:,}",
        "XWLPSentenceCueRate": f"{100 * by_key['xwlp_sentence']['rate']:.2f}\\%",
        "RequestedUniverseIndex": "universe[0]",
    }
    lines = [
        "% Generated by build_section8.py from one hash-verified aggregate report; do not edit."
    ]
    lines.extend(
        rf"\newcommand{{\{name}}}{{{value}}}" for name, value in values.items()
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_table(path: Path) -> None:
    lines = [
        "% Generated by build_section8.py; all displayed numbers use reconciled macros.",
        r"\begin{center}",
        r"\begin{minipage}{\linewidth}",
        r"\centering",
        r"\captionsetup{hypcap=false}",
        r"\captionof{table}{Deterministic lexical lower-bound diagnostic reproduced arithmetically from the hash-verified aggregate report. Positive counts identify frozen-vocabulary cues; they are not semantic labels or requested-value-specific mention rates.}",
        r"\label{tab:section8-lexical-diagnostics}",
        r"\small",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{p{0.12\linewidth}p{0.46\linewidth}rrr}",
        r"\toprule",
        r"Corpus & Diagnostic & Unresolved & Positive & Rate \\",
        r"\midrule",
        r"MyFixit & Step text: exact normalized frozen-tool cue & \MyFixitUnresolvedUnits{} & \MyFixitStepCueCount{} & \MyFixitStepCueRate{} \\",
        r"MyFixit & Guide title, subject, or toolbox: exact normalized frozen-tool cue & \MyFixitUnresolvedUnits{} & \MyFixitContextCueCount{} & \MyFixitContextCueRate{} \\",
        r"MyFixit & Structured tools field intersects frozen vocabulary & \MyFixitUnresolvedUnits{} & \MyFixitToolsFieldCueCount{} & \MyFixitToolsFieldCueRate{} \\",
        r"X-WLP & Operation sentence: frozen location-family lexical cue & \XWLPUnresolvedOperations{} & \XWLPSentenceCueCount{} & \XWLPSentenceCueRate{} \\",
        r"\bottomrule",
        r"\end{tabular}",
        r"\end{minipage}",
        r"\end{center}",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    source = args.source.resolve()
    output = args.output_root.resolve()
    actual_hash = sha256(source)
    if actual_hash != SOURCE_SHA256:
        raise ValueError(
            f"construct-validity source hash mismatch: expected {SOURCE_SHA256}, found {actual_hash}"
        )
    rows, degeneracy = parse_source(source.read_text(encoding="utf-8"))
    payload = {
        "version": "section8-recomputed-v0.1",
        "sole_evidence_source": "gates/gate_a_literature_collision_v0_1.md",
        "sole_evidence_source_sha256": SOURCE_SHA256,
        "source_scope": "CONSTRUCT_VALIDITY_DETERMINISTIC_LEXICAL_LOWER_BOUND_AUDIT",
        "evidence_level": EVIDENCE_LEVEL,
        "raw_recount_available": False,
        "semantic_labels": False,
        "requested_value_specific_rate": False,
        "out_of_scope_generalization": False,
        "diagnostics": rows,
        "requested_value_degeneracy": degeneracy,
        "interpretation": {
            "structured_unresolved_certifies_lexical_silence": False,
            "positive_cue_certifies_requested_relation": False,
            "cue_absence_certifies_semantic_silence": False,
            "published_work_critique": False,
        },
    }
    write_json(output / "data/section8_recomputed.json", payload)
    write_csv(output / "tables/section8_lexical_diagnostics.csv", rows)
    write_values(output / "tables/section8_values.tex", rows)
    write_table(output / "tables/section8_lexical_diagnostics.tex")
    print(
        "SECTION8_BUILD_OK",
        f"rows={len(rows)}",
        f"evidence_level={EVIDENCE_LEVEL}",
        "raw_recount=false",
        sep=" | ",
    )


if __name__ == "__main__":
    main()
