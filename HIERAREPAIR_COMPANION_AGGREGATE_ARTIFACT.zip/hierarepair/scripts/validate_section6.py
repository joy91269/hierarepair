#!/usr/bin/env python3
"""Independent validation for Section 6 and its generated artifacts."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
from fractions import Fraction
from pathlib import Path
from typing import Any


HASHES = {
    "gate_c_tau_sweep": "ddebc004c57067aaa6917b3874dc1459d0142cd6fdf6564f881f229da1a564ad",
    "frozen_tables": "5c0edb15b7b7e8d19f0ada6553fe665c97ca6ec758be92971442bf56a4547bf6",
    "p3_lattice": "009e54e3cc5b41289fb140a28e05aaaabb86d72292ffb824523a4298ba3c3e7e",
}
GRID = ["exact", "0.95", "0.90", "0.85", "0.80", "0.70", "0.60", "0.50"]
SOURCES = ["myfixit", "xwlp"]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def verified(path: Path, expected: str) -> str:
    if sha256(path) != expected:
        raise ValueError(f"frozen source hash mismatch: {path}")
    return path.read_text(encoding="utf-8")


def split_cells(line: str) -> list[str]:
    return [value.strip() for value in line.strip().strip("|").split("|")]


def parse_table(text: str, heading: str) -> list[dict[str, str]]:
    lines = text.splitlines()
    start = next(index for index, line in enumerate(lines) if line.startswith(heading))
    header_index = next(index for index in range(start + 1, len(lines)) if "|" in lines[index])
    header = split_cells(lines[header_index])
    rows: list[dict[str, str]] = []
    for line in lines[header_index + 2 :]:
        if "|" not in line:
            break
        values = split_cells(line)
        if len(values) > len(header) and "argmax_method" in header:
            pivot = header.index("argmax_method")
            trailing = len(header) - pivot - 1
            values = values[:pivot] + ["|".join(values[pivot:-trailing])] + values[-trailing:]
        if len(values) != len(header):
            raise ValueError(f"malformed frozen row: {line}")
        rows.append(dict(zip(header, values)))
    return rows


def close(left: float, right: float) -> bool:
    return math.isclose(left, right, rel_tol=0.0, abs_tol=1e-12)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--preprint-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--pdf", type=Path)
    args = parser.parse_args()
    project = args.project_root.resolve()
    preprint = args.preprint_root.resolve()

    gate = verified(
        project / "gates/gate_c_tau_sweep_v0_1.md", HASHES["gate_c_tau_sweep"]
    )
    frozen = verified(
        project / "paper/FROZEN_TABLES.md", HASHES["frozen_tables"]
    )
    lattice = load_json(project / "raw/phaseB/p3_edge_family_lattice.json")
    if sha256(project / "raw/phaseB/p3_edge_family_lattice.json") != HASHES["p3_lattice"]:
        raise ValueError("frozen P3 lattice hash mismatch")
    component = parse_table(gate, "## Table 1")
    winners = parse_table(gate, "## Table 4")
    edge = parse_table(frozen, "## Table 1")
    derived = load_json(preprint / "data/section6_recomputed.json")
    if derived["input_sha256"] != HASHES:
        raise ValueError("Section 6 input hashes differ")

    if derived["scope"]["sources"] != SOURCES or derived["scope"]["tau_grid"] != GRID:
        raise ValueError("Section 6 source scope or registered grid differs")
    if derived["scope"]["six_source_tau_sweep_available"]:
        raise ValueError("Section 6 incorrectly claims a six-source sweep")
    if derived["scope"]["qualifier_set_trajectory_available"]:
        raise ValueError("Section 6 incorrectly claims a qualifier trajectory")

    lattice_configs = {
        (row["source"], row["config"]): row
        for row in lattice["records"]
        if row["source"] in SOURCES and row["config"] in {"C2", "C5"}
    }
    source_units: dict[str, int] = {}
    for source in SOURCES:
        c2_units = int(lattice_configs[(source, "C2")]["n_units"])
        c5_units = int(lattice_configs[(source, "C5")]["n_units"])
        if c2_units != c5_units:
            raise ValueError(f"independent C2/C5 unit-count mismatch for {source}")
        source_units[source] = c2_units
    typed_component = []
    for row in component:
        source = row["source"]
        size_max = int(row["size_max"])
        typed_component.append(
            {
                "source": source,
                "tau": row["tau"],
                "n_components": int(row["n_components"]),
                "n_units": source_units[source],
                "size_max": size_max,
                "top1_share": size_max / source_units[source],
                "top1_share_reported": float(row["top1_share"]),
                "effective_components": float(row["effective_components"]),
            }
        )
    if typed_component != derived["component_rows"]:
        raise ValueError("Section 6 component rows differ from frozen source")
    for source in SOURCES:
        if [row["tau"] for row in typed_component if row["source"] == source] != GRID:
            raise ValueError(f"registered grid differs for {source}")

    for metric in ("n_components", "top1_share", "effective_components"):
        invariant = all(
            len({row[metric] for row in typed_component if row["source"] == source}) == 1
            for source in SOURCES
        )
        if invariant or derived["raw_metric_audit"]["metric_invariance"][metric]:
            raise ValueError(f"raw metric incorrectly marked invariant: {metric}")
    if derived["raw_metric_audit"]["n_invariant_metrics"] != 0:
        raise ValueError("raw metric invariant count is not zero")

    holm = [int(row["n_flips_holm"]) for row in winners]
    raw = [int(row["n_flips_raw"]) for row in winners]
    if len(winners) != 32 or sum(holm) != 0 or sum(raw) != 2:
        raise ValueError("winner-flip counts differ from frozen source")
    if "NO SURVIVING FLIPS" not in gate:
        raise ValueError("frozen no-surviving-flips statement missing")
    decision = derived["holm_decision_audit"]
    if (
        decision["n_rows"] != len(winners)
        or decision["total_holm_flips"] != sum(holm)
        or decision["total_raw_flips"] != sum(raw)
        or not decision["no_surviving_flips_statement_present"]
    ):
        raise ValueError("generated decision audit differs")

    generated_edge = {row["source"]: row for row in derived["edge_family_rows"]}
    for source in SOURCES:
        frozen_rows = {
            row["config"]: row
            for row in edge
            if row["source"] == source and row["config"] in {"C2", "C5"}
        }
        generated = generated_edge[source]
        expected = {
            "c2_n_components": int(frozen_rows["C2"]["n_components"]),
            "c5_n_components": int(frozen_rows["C5"]["n_components"]),
            "c2_top1_share": float(frozen_rows["C2"]["top1_share_units"]),
            "c5_top1_share": float(frozen_rows["C5"]["top1_share_units"]),
            "c2_effective_components": float(frozen_rows["C2"]["effective_components"]),
            "c5_effective_components": float(frozen_rows["C5"]["effective_components"]),
        }
        for field, value in expected.items():
            actual = generated[field]
            if isinstance(value, float):
                if not close(float(actual), value):
                    raise ValueError(f"edge-family value differs: {source} {field}")
            elif actual != value:
                raise ValueError(f"edge-family value differs: {source} {field}")

    myfixit_component = {
        row["tau"]: row for row in typed_component if row["source"] == "myfixit"
    }
    myfixit_edge = {
        row["config"]: row
        for row in lattice["records"]
        if row["source"] == "myfixit" and row["config"] in {"C2", "C5"}
    }
    tau_exact_size = int(myfixit_component["exact"]["size_max"])
    tau_lowest_size = int(myfixit_component["0.50"]["size_max"])
    tau_n_units = int(myfixit_component["exact"]["n_units"])
    if tau_n_units != int(myfixit_component["0.50"]["n_units"]):
        raise ValueError("independent Gate C endpoint unit counts differ")
    c2_top1_size = int(myfixit_edge["C2"]["top1_size"])
    c5_top1_size = int(myfixit_edge["C5"]["top1_size"])
    c2_n_units = int(myfixit_edge["C2"]["n_units"])
    c5_n_units = int(myfixit_edge["C5"]["n_units"])
    c2_tau = float(myfixit_edge["C2"]["tau"])
    c5_tau = float(myfixit_edge["C5"]["tau"])
    if len({tau_n_units, c2_n_units, c5_n_units}) != 1:
        raise ValueError("independent exact-ratio unit counts differ")
    if c2_tau != c5_tau:
        raise ValueError("independent C2/C5 tau identities differ")
    if tau_exact_size != c2_top1_size:
        raise ValueError("equal exact/C2 sizes are not present in independent sources")
    tau_fraction = Fraction(tau_lowest_size, tau_exact_size)
    edge_fraction = Fraction(c5_top1_size, c2_top1_size)
    quotient_fraction = edge_fraction / tau_fraction
    if quotient_fraction != Fraction(c5_top1_size, tau_lowest_size):
        raise ValueError("independent quotient does not reduce exactly")
    expected_tau_ratio = float(tau_fraction)
    expected_edge_ratio = float(edge_fraction)
    expected_quotient = float(quotient_fraction)
    rounded_display_ratio = float(Fraction(70, 17))
    if close(expected_tau_ratio, rounded_display_ratio):
        raise ValueError("exact and rounded-input ratios unexpectedly coincide")
    contrast = derived["same_outcome_magnitude_contrast"]
    expected_contrast = {
        "source": "myfixit",
        "statistic": "largest_component_share",
        "tau_exact_size_max": tau_exact_size,
        "tau_0_50_size_max": tau_lowest_size,
        "tau_n_units": tau_n_units,
        "tau_exact_share_full_precision": tau_exact_size / tau_n_units,
        "tau_0_50_share_full_precision": tau_lowest_size / tau_n_units,
        "tau_endpoint_ratio_fraction": f"{tau_fraction.numerator}/{tau_fraction.denominator}",
        "tau_endpoint_ratio": expected_tau_ratio,
        "edge_c2": c2_top1_size / c2_n_units,
        "edge_c5": c5_top1_size / c5_n_units,
        "c2_top1_size": c2_top1_size,
        "c5_top1_size": c5_top1_size,
        "c2_tau": c2_tau,
        "c5_tau": c5_tau,
        "edge_family_ratio_fraction": f"{edge_fraction.numerator}/{edge_fraction.denominator}",
        "edge_family_ratio": expected_edge_ratio,
        "ratio_quotient_fraction": f"{quotient_fraction.numerator}/{quotient_fraction.denominator}",
        "ratio_quotient": expected_quotient,
        "ratio_input_provenance": {
            "tau_endpoint_numerator": "gates/gate_c_tau_sweep_v0_1.md::Table1::myfixit::tau=0.50::size_max",
            "tau_endpoint_denominator": "gates/gate_c_tau_sweep_v0_1.md::Table1::myfixit::tau=exact::size_max",
            "tau_share_denominator": "raw/phaseB/p3_edge_family_lattice.json::myfixit::C2/C5::n_units",
            "edge_family_numerator": "raw/phaseB/p3_edge_family_lattice.json::myfixit::C5::top1_size",
            "edge_family_denominator": "raw/phaseB/p3_edge_family_lattice.json::myfixit::C2::top1_size",
            "intermediate_display_rounding": False,
            "formatted_table_macro_used_as_ratio_input": False,
        },
        "rounded_display_input_ratio_rejected": rounded_display_ratio,
        "scope": "DESCRIPTIVE_SINGLE_STATISTIC_ONLY",
        "effect_size_test": False,
        "significance_comparison": False,
        "extrapolation_supported": False,
    }
    if set(contrast) != set(expected_contrast):
        raise ValueError("same-outcome contrast fields differ")
    for field, expected in expected_contrast.items():
        actual = contrast[field]
        if isinstance(expected, float):
            if not close(float(actual), expected):
                raise ValueError(f"same-outcome contrast differs: {field}")
        elif actual != expected:
            raise ValueError(f"same-outcome contrast differs: {field}")
    if close(float(contrast["tau_endpoint_ratio"]), rounded_display_ratio):
        raise ValueError("rounded 0.0070/0.0017 input escaped precision regression")
    provenance = contrast["ratio_input_provenance"]
    if provenance["intermediate_display_rounding"]:
        raise ValueError("ratio provenance permits intermediate display rounding")
    if provenance["formatted_table_macro_used_as_ratio_input"]:
        raise ValueError("formatted table macro was used as a ratio input")

    endpoint_csv = read_csv(preprint / "tables/section6_tau_endpoints.csv")
    edge_csv = read_csv(preprint / "tables/section6_edge_family.csv")
    if len(endpoint_csv) != 2 or len(edge_csv) != 2:
        raise ValueError("Section 6 CSV row count differs")
    endpoint_by_source = {row["source"]: row for row in endpoint_csv}
    for source in SOURCES:
        exact = next(
            row for row in typed_component if row["source"] == source and row["tau"] == "exact"
        )
        lowest = next(
            row for row in typed_component if row["source"] == source and row["tau"] == "0.50"
        )
        csv_row = endpoint_by_source[source]
        if int(csv_row["n_units"]) != source_units[source]:
            raise ValueError(f"endpoint CSV n_units differs for {source}")
        if int(csv_row["exact_size_max"]) != exact["size_max"]:
            raise ValueError(f"endpoint CSV exact size differs for {source}")
        if int(csv_row["lowest_size_max"]) != lowest["size_max"]:
            raise ValueError(f"endpoint CSV low size differs for {source}")
        if not close(float(csv_row["exact_top1_share"]), exact["top1_share"]):
            raise ValueError(f"endpoint CSV exact share differs for {source}")
        if not close(float(csv_row["lowest_top1_share"]), lowest["top1_share"]):
            raise ValueError(f"endpoint CSV low share differs for {source}")

    section = (preprint / "sections/06-tau-inertness.tex").read_text(encoding="utf-8")
    normalized = " ".join(section.split())
    for fragment in (
        "registered discrete settings from exact matching",
        "It is not a continuous-interval study and it is not a six-source sweep",
        "The raw component structure is not invariant",
        "Calling these raw statistics unchanged would therefore contradict the frozen sweep",
        "registered multiplicity-adjusted flip decision does not change on the registered discrete grid",
        "absence of Holm-surviving flips is a negative result under the registered decision rule",
        "it is not an equivalence test and does not establish that $\\tau$ has zero effect",
        "do not claim that the frozen qualifier set is invariant",
        "observed configuration contrast; it does not identify a general causal mechanism",
        "descriptive magnitude comparison on a single statistic",
        "not an effect-size test or a significance comparison",
        "not extrapolated beyond the registered grid or this frozen panel",
        "computed from exact integer component sizes rather than the displayed shares",
        "same largest-component size does not make the two configurations identical",
        "These observations concern different outcome levels and are not interpreted as a direct effect-size comparison",
        "observed configuration contrast without a general causal interpretation",
        "does not imply that edge family is universally decisive",
        "a near-duplicate threshold is generally unimportant",
    ):
        if fragment not in normalized:
            raise ValueError(f"required Section 6 boundary missing: {fragment}")
    if re.search(r"(?<![A-Za-z])0\.\d+", section):
        raise ValueError("Section 6 contains a hand-entered bare decimal")
    unsupported_scan = normalized
    for allowed_boundary in (
        "do not claim that the frozen qualifier set is invariant",
        "it is not an equivalence test and does not establish that $\\tau$ has zero effect",
        "not an effect-size test or a significance comparison",
        "not interpreted as a direct effect-size comparison",
    ):
        unsupported_scan = unsupported_scan.replace(allowed_boundary, "")
    for pattern in (
        r"for\s+all\s+tau",
        r"all\s+structural\s+(?:quantities|metrics)\s+(?:are\s+)?unchanged",
        r"(?:tau|threshold)\s+(?:does\s+not\s+matter|is\s+unimportant)",
        r"edge[- ]family\s+(?:choice\s+)?is\s+always\s+decisive",
        r"the\s+frozen\s+qualifier\s+set\s+is\s+invariant",
        r"(?:tau|\\tau)\s+has\s+(?:absolutely\s+)?no\s+effect",
        r"(?:establish(?:es|ed)?|demonstrat(?:es|ed)?)\s+equivalence",
        r"(?:direct\s+)?effect[- ]size\s+(?:test|comparison|estimate)",
    ):
        if re.search(pattern, unsupported_scan, flags=re.I):
            raise ValueError(f"unsupported Section 6 claim: {pattern}")

    main_tex = (preprint / "main.tex").read_text(encoding="utf-8")
    if "sections/06-tau-inertness" not in main_tex:
        raise ValueError("Section 6 is not included in main.tex")
    section_7_started = "sections/07" in main_tex
    section_8_started = "sections/08" in main_tex
    section_9_started = "sections/09-related-work" in main_tex
    if not section_9_started:
        raise ValueError("approved Section 9 is not included in current main.tex")
    section_10_started = bool(re.search(r"sections/10", main_tex))
    if not section_10_started or main_tex.count(r"\input{sections/10-limitations}") != 1:
        raise ValueError("approved Section 10 is not included exactly once")
    if not (preprint / "sections/10-limitations.tex").is_file():
        raise ValueError("approved Section 10 manuscript is missing")
    if main_tex.count(r"\input{sections/11-reproducibility-and-artifact-scope}") != 1:
        raise ValueError("authorized Section 11 is not included exactly once")
    if re.search(r"sections/12", main_tex) or list((preprint / "sections").glob("12-*.tex")):
        raise ValueError("Section 12 was started")

    interpretation = derived["interpretation"]
    if interpretation != {
        "tau_inertness_level": "HOLM_SURVIVING_FLIP_DECISION_ONLY",
        "raw_structure_invariant": False,
        "equivalence_test": False,
        "zero_effect_established": False,
        "continuous_interval_claim_supported": False,
        "general_threshold_unimportance_supported": False,
        "edge_family_claim_scope": "OBSERVED_CONFIGURATION_CONTRAST_ONLY",
    }:
        raise ValueError("Section 6 interpretation boundary differs")

    payload = {
        "status": "PASS",
        "canonical_input_sha256": HASHES,
        "source_scope": SOURCES,
        "registered_tau_grid": GRID,
        "n_component_rows": len(component),
        "raw_metric_invariance": {
            "n_components": False,
            "top1_share": False,
            "effective_components": False,
        },
        "n_winner_rows": len(winners),
        "total_raw_flips": sum(raw),
        "total_holm_flips": sum(holm),
        "same_outcome_magnitude_contrast": contrast,
        "rounded_input_regression": {
            "rounded_ratio": rounded_display_ratio,
            "rounded_ratio_rejected": True,
            "exact_integer_ratio_required": True,
            "formatted_table_macro_rejected": True,
        },
        "six_source_tau_sweep_available": False,
        "qualifier_set_trajectory_available": False,
        "section_7_started": section_7_started,
        "section_8_started": section_8_started,
        "section_9_started": section_9_started,
        "section_10_started": section_10_started,
        "pdf_sha256": sha256(args.pdf.resolve()) if args.pdf else None,
    }
    args.output.resolve().parent.mkdir(parents=True, exist_ok=True)
    args.output.resolve().write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        "SECTION6_VALIDATION_OK",
        "sources=2",
        "tau_points=8",
        "raw_invariant=0/3",
        "holm_flips=0",
        f"section7={'STARTED' if section_7_started else 'NOT_STARTED'}",
        f"section8={'STARTED' if section_8_started else 'NOT_STARTED'}",
        "section9=STARTED_AND_AUTHORIZED",
        "section10=STARTED_AND_AUTHORIZED",
        "section11=STARTED_AND_AUTHORIZED",
        sep=" | ",
    )


if __name__ == "__main__":
    main()
