#!/usr/bin/env python3
"""Build Section 7 from the single hash-verified exploration-review source."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from pathlib import Path
from typing import Any


SOURCE_SHA256 = "7c5c5d28d6731e0ec89e7e4cf76780cfc97d7bf357a2f50d43ac2dad8808f728"
CORPORA = ("myfixit", "xwlp")
LABELS = {"myfixit": "MyFixit", "xwlp": "X-WLP"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def integer(value: str) -> int:
    return int(value.replace(",", ""))


def parse_c1(text: str) -> dict[str, dict[str, int | float]]:
    if "### 12.2 C1 完整人口 census" not in text:
        raise ValueError("C1 census section is absent from the sole evidence source")
    c1 = text.split("### 12.2 C1 完整人口 census", 1)[1]
    if "naive-negative exposure" not in text or "`UNRESOLVED` 的比例" not in text:
        raise ValueError("registered exposure definition is absent")
    result: dict[str, dict[str, int | float]] = {}
    for source in CORPORA:
        label = LABELS[source]
        match = re.search(
            rf"{re.escape(label)}：\s*"
            r"- units=([\d,]+)；\s*"
            r"- complete=([\d,]+)；\s*"
            r"- incomplete=([\d,]+)；\s*"
            r"- licensed REFUTED pairs=([\d,]+)；\s*"
            r"- UNRESOLVED pairs=([\d,]+)；\s*"
            r"- naive-negative pairs=([\d,]+)；\s*"
            r"- exposure=\.([0-9]+)。",
            c1,
        )
        if match is None:
            raise ValueError(f"cannot parse the frozen C1 block for {label}")
        units, complete, incomplete, refuted, unresolved, naive = map(
            integer, match.groups()[:6]
        )
        reported_exposure = float("0." + match.group(7))
        if units != complete + incomplete:
            raise ValueError(f"unit partition does not close for {label}")
        if naive != refuted + unresolved:
            raise ValueError(f"pair partition does not close for {label}")
        exposure = unresolved / naive
        if f"{exposure:.6f}" != f"{reported_exposure:.6f}":
            raise ValueError(f"reported exposure does not reconcile for {label}")
        incomplete_fraction = incomplete / units
        result[source] = {
            "units": units,
            "complete_units": complete,
            "incomplete_units": incomplete,
            "licensed_refuted_pairs": refuted,
            "unresolved_pairs": unresolved,
            "naive_negative_pairs": naive,
            "reported_exposure": reported_exposure,
            "recomputed_exposure": exposure,
            "incomplete_fraction": incomplete_fraction,
            "absolute_fraction_gap": abs(exposure - incomplete_fraction),
            "absolute_percentage_point_gap": abs(exposure - incomplete_fraction) * 100,
            "pairs_per_complete_unit": refuted / complete,
            "pairs_per_incomplete_unit": unresolved / incomplete,
        }
    return result


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def macro_name(source: str, suffix: str) -> str:
    prefix = "MyFixit" if source == "myfixit" else "XWLP"
    return prefix + suffix


def write_values(path: Path, rows: dict[str, dict[str, int | float]]) -> None:
    values: dict[str, str] = {"CoverageExposureCorpora": str(len(rows))}
    for source in CORPORA:
        row = rows[source]
        values.update(
            {
                macro_name(source, "CoverageUnits"): f"{int(row['units']):,}",
                macro_name(source, "CoverageCompleteUnits"): f"{int(row['complete_units']):,}",
                macro_name(source, "CoverageIncompleteUnits"): f"{int(row['incomplete_units']):,}",
                macro_name(source, "CoverageRefutedPairs"): f"{int(row['licensed_refuted_pairs']):,}",
                macro_name(source, "CoverageUnresolvedPairs"): f"{int(row['unresolved_pairs']):,}",
                macro_name(source, "CoverageNaivePairs"): f"{int(row['naive_negative_pairs']):,}",
                macro_name(source, "CoverageExposure"): f"{float(row['recomputed_exposure']):.6f}",
                macro_name(source, "CoverageIncompleteFraction"): f"{float(row['incomplete_fraction']):.6f}",
                macro_name(source, "CoverageFractionGap"): f"{float(row['absolute_fraction_gap']):.6f}",
                macro_name(source, "CoveragePercentagePointGap"): f"{float(row['absolute_percentage_point_gap']):.3f}",
                macro_name(source, "CoverageCompletePairsPerUnit"): f"{float(row['pairs_per_complete_unit']):.1f}",
                macro_name(source, "CoverageIncompletePairsPerUnit"): f"{float(row['pairs_per_incomplete_unit']):.1f}",
            }
        )
    lines = [
        "% Generated by build_section7.py from the hash-verified sole evidence source; do not edit."
    ]
    lines.extend(
        rf"\newcommand{{\{name}}}{{{value}}}" for name, value in values.items()
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_table(path: Path) -> None:
    lines = [
        "% Generated by build_section7.py; all displayed numbers are reconciled macros.",
        r"\begin{center}",
        r"\begin{minipage}{\linewidth}",
        r"\centering",
        r"\captionsetup{hypcap=false}",
        r"\captionof{table}{Coverage exposure and the unit-level incompleteness fraction under the one registered exposure definition.  Gap is the absolute difference in percentage points; the final columns show the corresponding candidate-pair mass per complete and incomplete unit.}",
        r"\label{tab:section7-coverage-exposure}",
        r"\small",
        r"\setlength{\tabcolsep}{4pt}",
        r"\begin{tabular}{lrrrrr}",
        r"\toprule",
        r"Corpus & Exposure & Incomplete & Gap (pp) & Pairs/complete & Pairs/incomplete \\",
        r"\midrule",
        r"MyFixit & \MyFixitCoverageExposure{} & \MyFixitCoverageIncompleteFraction{} & \MyFixitCoveragePercentagePointGap{} & \MyFixitCoverageCompletePairsPerUnit{} & \MyFixitCoverageIncompletePairsPerUnit{} \\",
        r"X-WLP & \XWLPCoverageExposure{} & \XWLPCoverageIncompleteFraction{} & \XWLPCoveragePercentagePointGap{} & \XWLPCoverageCompletePairsPerUnit{} & \XWLPCoverageIncompletePairsPerUnit{} \\",
        r"\bottomrule",
        r"\end{tabular}",
        r"\end{minipage}",
        r"\end{center}",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    source = args.source.resolve()
    output = args.output_root.resolve()
    actual_hash = sha256(source)
    if actual_hash != SOURCE_SHA256:
        raise ValueError(
            f"sole evidence-source hash mismatch: expected {SOURCE_SHA256}, found {actual_hash}"
        )
    text = source.read_text(encoding="utf-8")
    rows = parse_c1(text)
    payload = {
        "version": "section7-recomputed-v0.1",
        "sole_evidence_source": "decisions/HIERAREPAIR_COMPLETE_RESEARCH_EXPLORATION_REVIEW_20260724.md",
        "sole_evidence_source_sha256": SOURCE_SHA256,
        "exposure_definition": "UNRESOLVED_PAIRS / NAIVE_NEGATIVE_PAIRS",
        "incompleteness_definition": "INCOMPLETE_UNITS / ALL_UNITS",
        "corpora": rows,
        "scope": {
            "n_corpora": len(rows),
            "one_exposure_definition_only": True,
            "other_corpora_supported": False,
            "other_exposure_definitions_supported": False,
            "general_uninformativeness_supported": False,
            "published_work_critique": False,
        },
    }
    write_json(output / "data/section7_recomputed.json", payload)
    write_values(output / "tables/section7_values.tex", rows)
    write_table(output / "tables/section7_coverage_exposure.tex")
    print(
        "SECTION7_BUILD_OK",
        f"corpora={len(rows)}",
        f"myfixit_gap={rows['myfixit']['absolute_fraction_gap']:.6f}",
        f"xwlp_gap={rows['xwlp']['absolute_fraction_gap']:.6f}",
        sep=" | ",
    )


if __name__ == "__main__":
    main()
