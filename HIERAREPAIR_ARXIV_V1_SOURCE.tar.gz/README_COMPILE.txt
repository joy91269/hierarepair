FINAL ARXIV SOURCE PACKAGE

Compile from this directory with a standard XeLaTeX/BibTeX sequence:

  xelatex -interaction=nonstopmode main.tex
  bibtex main
  xelatex -interaction=nonstopmode main.tex
  xelatex -interaction=nonstopmode main.tex

The distributed main.bbl is included for submission systems that use a
prebuilt bibliography. The package requires only the TeX files, refs.bib,
the files under sections/, tables/, and figures/, and standard LaTeX packages
used by main.tex. It does not require shell escape or a file outside this
source tree to compile the manuscript.

The repro/ directory contains two deterministic editorial derivatives and
their generator. Rebuilding them requires the separately distributed
companion aggregate inputs described in repro/README.txt; those inputs are not
needed to compile the manuscript.
