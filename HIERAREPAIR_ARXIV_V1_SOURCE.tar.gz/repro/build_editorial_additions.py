#!/usr/bin/env python3
"""Build the two draft-only editorial additions from frozen aggregates."""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
from pathlib import Path


DISPLAY_NAMES = {
    "human_knowhow": "Human Know-How",
    "myfixit": "MyFixit",
    "openpi": "OpenPI",
    "wiqa": "WIQA",
    "doc2dial": "Doc2Dial",
    "xwlp": "X-WLP",
}


def load_json(path: Path):
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def pearson(xs: list[float], ys: list[float]) -> float:
    xbar = sum(xs) / len(xs)
    ybar = sum(ys) / len(ys)
    numerator = sum((x - xbar) * (y - ybar) for x, y in zip(xs, ys))
    xnorm = math.sqrt(sum((x - xbar) ** 2 for x in xs))
    ynorm = math.sqrt(sum((y - ybar) ** 2 for y in ys))
    return numerator / (xnorm * ynorm)


def average_ranks(values: list[float]) -> list[float]:
    ordered = sorted(enumerate(values), key=lambda item: item[1])
    ranks = [0.0] * len(values)
    offset = 0
    while offset < len(ordered):
        end = offset + 1
        while end < len(ordered) and ordered[end][1] == ordered[offset][1]:
            end += 1
        average = ((offset + 1) + end) / 2.0
        for position in range(offset, end):
            ranks[ordered[position][0]] = average
        offset = end
    return ranks


def ranks_from_weak_order(groups: tuple[int, ...]) -> list[float]:
    ranks = [0.0] * len(groups)
    position = 1
    for group in range(max(groups) + 1):
        members = [index for index, value in enumerate(groups) if value == group]
        average = (position + position + len(members) - 1) / 2.0
        for index in members:
            ranks[index] = average
        position += len(members)
    return ranks


def weak_order_feasible(
    groups: tuple[int, ...], intervals: list[tuple[float, float]]
) -> bool:
    previous = -math.inf
    for group in range(max(groups) + 1):
        members = [index for index, value in enumerate(groups) if value == group]
        lower = max(intervals[index][0] for index in members)
        upper = min(intervals[index][1] for index in members)
        if lower > upper:
            return False
        candidate = lower if previous == -math.inf else max(lower, math.nextafter(previous, math.inf))
        if candidate > upper:
            return False
        previous = candidate
    return True


def compatible_spearman_range(
    intervals: list[tuple[float, float]], outcomes: list[float]
) -> tuple[float, float, int]:
    outcome_ranks = average_ranks(outcomes)
    correlations: list[float] = []
    n = len(intervals)
    for groups in itertools.product(range(n), repeat=n):
        if set(groups) != set(range(max(groups) + 1)):
            continue
        if not weak_order_feasible(groups, intervals):
            continue
        correlations.append(pearson(ranks_from_weak_order(groups), outcome_ranks))
    if not correlations:
        raise RuntimeError("No interval-compatible weak rank order was found")
    return min(correlations), max(correlations), len(correlations)


def build(companion_root: Path, output_dir: Path, panel_tex: Path) -> None:
    lattice_path = companion_root / "raw/phaseB/p3_edge_family_lattice.json"
    audit_path = companion_root / "raw/phaseB/p3_audit_criteria.json"
    panel_csv = output_dir / "panel_summary.csv"
    sensitivity_csv = output_dir / "spanning_forest_sensitivity.csv"

    lattice = load_json(lattice_path)
    audit = load_json(audit_path)
    sources = list(audit["gate_eligible_sources"])
    qualifiers = set(audit["gate"]["qualifying_sources"])

    diagnostics = {record["source"]: record for record in lattice["diagnostics"]}
    records = {
        (record["source"], record["config"]): record
        for record in lattice["records"]
    }

    panel_rows = []
    sensitivity_rows = []
    for source in sources:
        diagnostic = diagnostics[source]
        c2 = records[(source, "C2")]
        c3 = records[(source, "C3")]
        c5 = records[(source, "C5")]

        n_units = int(diagnostic["n_units"])
        n_containers = int(diagnostic["n_containers"])
        if not (c2["n_units"] == c3["n_units"] == c5["n_units"] == n_units):
            raise RuntimeError(f"Unit-count disagreement for {source}")
        if c3["n_components"] != n_containers:
            raise RuntimeError(f"C3 component/container disagreement for {source}")
        if c3["top1_size"] != diagnostic["units_per_container"]["max"]:
            raise RuntimeError(f"C3 maximum/container disagreement for {source}")

        mean_units = n_units / n_containers
        frozen_mean = float(diagnostic["units_per_container"]["mean"])
        if not math.isclose(mean_units, frozen_mean, rel_tol=0.0, abs_tol=1e-12):
            raise RuntimeError(f"Mean units/container disagreement for {source}")

        panel_rows.append(
            {
                "source": source,
                "display_name": DISPLAY_NAMES[source],
                "units": n_units,
                "containers": n_containers,
                "mean_units_per_container": mean_units,
                "median_units_per_container": diagnostic["units_per_container"].get("median"),
                "maximum_units_per_container": int(c3["top1_size"]),
            }
        )

        e2 = int(c2["n_edges"])
        e3 = int(c3["n_edges"])
        e5 = int(c5["n_edges"])
        tree_edges = n_units - n_containers
        overlap = e2 + e3 - e5
        overlap_min = max(0, tree_edges - (e3 - overlap))
        overlap_max = min(tree_edges, overlap)
        forest_union_min = e2 + tree_edges - overlap_max
        forest_union_max = e2 + tree_edges - overlap_min
        degree_min = 2.0 * forest_union_min / n_units
        degree_max = 2.0 * forest_union_max / n_units
        sensitivity_rows.append(
            {
                "source": source,
                "display_name": DISPLAY_NAMES[source],
                "qualifier": source in qualifiers,
                "n_units": n_units,
                "n_containers": n_containers,
                "c2_edges": e2,
                "c3_clique_edges": e3,
                "c5_union_edges": e5,
                "forest_edges": tree_edges,
                "c2_c3_clique_overlap_edges": overlap,
                "forest_c2_overlap_min": overlap_min,
                "forest_c2_overlap_max": overlap_max,
                "forest_union_edges_min": forest_union_min,
                "forest_union_edges_max": forest_union_max,
                "forest_mean_degree_min": degree_min,
                "forest_mean_degree_max": degree_max,
                "c5_largest_component_share": float(c5["top1_share_units"]),
            }
        )

    medians = [row["median_units_per_container"] for row in panel_rows]
    median_included = all(value is not None for value in medians)

    intervals = [
        (row["forest_mean_degree_min"], row["forest_mean_degree_max"])
        for row in sensitivity_rows
    ]
    outcomes = [row["c5_largest_component_share"] for row in sensitivity_rows]
    rho_min, rho_max, weak_order_count = compatible_spearman_range(intervals, outcomes)
    qualifier_lower = min(
        row["forest_mean_degree_min"]
        for row in sensitivity_rows
        if row["qualifier"]
    )
    nonqualifier_upper = max(
        row["forest_mean_degree_max"]
        for row in sensitivity_rows
        if not row["qualifier"]
    )

    output_dir.mkdir(parents=True, exist_ok=True)
    with panel_csv.open("w", encoding="utf-8", newline="") as handle:
        fieldnames = [
            "source",
            "display_name",
            "units",
            "containers",
            "mean_units_per_container",
        ]
        if median_included:
            fieldnames.append("median_units_per_container")
        fieldnames.append("maximum_units_per_container")
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in panel_rows:
            rendered = dict(row)
            rendered["mean_units_per_container"] = f"{row['mean_units_per_container']:.12f}"
            writer.writerow(rendered)

    with sensitivity_csv.open("w", encoding="utf-8", newline="") as handle:
        fieldnames = list(sensitivity_rows[0].keys()) + [
            "panel_qualifier_lower_bound",
            "panel_nonqualifier_upper_bound",
            "panel_compatible_spearman_min",
            "panel_compatible_spearman_max",
            "panel_compatible_weak_orders",
        ]
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in sensitivity_rows:
            rendered = dict(row)
            for field in (
                "forest_mean_degree_min",
                "forest_mean_degree_max",
                "c5_largest_component_share",
            ):
                rendered[field] = f"{row[field]:.12f}"
            rendered.update(
                {
                    "panel_qualifier_lower_bound": f"{qualifier_lower:.12f}",
                    "panel_nonqualifier_upper_bound": f"{nonqualifier_upper:.12f}",
                    "panel_compatible_spearman_min": f"{rho_min:.12f}",
                    "panel_compatible_spearman_max": f"{rho_max:.12f}",
                    "panel_compatible_weak_orders": weak_order_count,
                }
            )
            writer.writerow(rendered)

    columns = "lrrrrr" if median_included else "lrrrr"
    by_source = {row["source"]: row for row in panel_rows}
    tex_lines = [
        f"\\providecommand{{\\EditorialXWLPMeanUnitsPerContainer}}{{{by_source['xwlp']['mean_units_per_container']:.2f}}}",
        f"\\providecommand{{\\EditorialMyFixitMeanUnitsPerContainer}}{{{by_source['myfixit']['mean_units_per_container']:.2f}}}",
        f"\\providecommand{{\\EditorialHumanKnowHowMaximumUnitsPerContainer}}{{{by_source['human_knowhow']['maximum_units_per_container']}}}",
        f"\\providecommand{{\\EditorialMyFixitMaximumUnitsPerContainer}}{{{by_source['myfixit']['maximum_units_per_container']}}}",
        f"\\providecommand{{\\EditorialDocTwoDialMeanUnitsPerContainer}}{{{by_source['doc2dial']['mean_units_per_container']:.2f}}}",
        f"\\providecommand{{\\EditorialDocTwoDialMaximumUnitsPerContainer}}{{{by_source['doc2dial']['maximum_units_per_container']}}}",
        f"\\providecommand{{\\EditorialForestQualifierLowerBound}}{{{qualifier_lower:.2f}}}",
        f"\\providecommand{{\\EditorialForestNonqualifierUpperBound}}{{{nonqualifier_upper:.2f}}}",
        f"\\providecommand{{\\EditorialForestSpearmanMinimum}}{{{rho_min:.3f}}}",
        f"\\providecommand{{\\EditorialForestSpearmanMaximum}}{{{rho_max:.3f}}}",
        "",
        "\\begin{center}",
        "\\small",
        f"\\begin{{tabular}}{{{columns}}}",
        "\\toprule",
        (
            "Source & Units & Containers & \\multicolumn{3}{c}{Units per container} \\\\"
            if median_included
            else "Source & Units & Containers & \\multicolumn{2}{c}{Units per container} \\\\"
        ),
        "\\cmidrule(lr){4-6}" if median_included else "\\cmidrule(lr){4-5}",
        (
            " & & & Mean & Median & Maximum \\\\"
            if median_included
            else " & & & Mean & Maximum \\\\"
        ),
        "\\midrule",
    ]
    for row in panel_rows:
        cells = [
            row["display_name"],
            f"{row['units']:,}",
            f"{row['containers']:,}",
            f"{row['mean_units_per_container']:.2f}",
        ]
        if median_included:
            cells.append(f"{float(row['median_units_per_container']):.0f}")
        cells.append(f"{row['maximum_units_per_container']:,}")
        tex_lines.append(" & ".join(cells) + " \\\\")
    tex_lines.extend(["\\bottomrule", "\\end{tabular}", "\\end{center}"])
    panel_tex.parent.mkdir(parents=True, exist_ok=True)
    panel_tex.write_text("\n".join(tex_lines) + "\n", encoding="utf-8")

    print(f"panel_sources={len(panel_rows)}")
    print(f"median_included={'yes' if median_included else 'no'}")
    print(f"qualifier_lower_bound={qualifier_lower:.12f}")
    print(f"nonqualifier_upper_bound={nonqualifier_upper:.12f}")
    print(f"compatible_spearman_range={rho_min:.12f},{rho_max:.12f}")
    print(f"compatible_weak_orders={weak_order_count}")


def parse_args() -> argparse.Namespace:
    script_path = Path(__file__).resolve()
    package_root = script_path.parents[1]
    parser = argparse.ArgumentParser(
        description="Rebuild deterministic editorial derivatives from companion aggregates."
    )
    parser.add_argument(
        "--companion-root",
        type=Path,
        default=script_path.parents[3],
        help="Root containing raw/phaseB/p3_edge_family_lattice.json and p3_audit_criteria.json.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=script_path.parent,
        help="Directory for the two generated CSV files.",
    )
    parser.add_argument(
        "--panel-tex",
        type=Path,
        default=package_root / "tables/panel_summary.tex",
        help="Generated panel-summary TeX path.",
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    build(args.companion_root, args.output_dir, args.panel_tex)
