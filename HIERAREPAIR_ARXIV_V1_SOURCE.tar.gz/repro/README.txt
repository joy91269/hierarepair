DETERMINISTIC EDITORIAL-DERIVATIVE REBUILD

build_editorial_additions.py regenerates panel_summary.csv,
spanning_forest_sensitivity.csv, and tables/panel_summary.tex from two files
in the separately distributed companion aggregate artifact:

  raw/phaseB/p3_edge_family_lattice.json
  raw/phaseB/p3_audit_criteria.json

From a clean working directory containing both final_arxiv_source/ and a
companion_aggregate/ directory, run, for example:

  python3 final_arxiv_source/repro/build_editorial_additions.py \
    --companion-root companion_aggregate \
    --output-dir rebuilt \
    --panel-tex rebuilt/panel_summary.tex

The default output locations, when the optional output flags are omitted, are
repro/ for the two CSV files and tables/panel_summary.tex for the TeX table.
For a non-destructive check, use fresh relative output locations and compare
the rebuilt files byte-for-byte with the distributed versions.

This is a deterministic derived-file rebuild from frozen aggregate inputs. It
is not a raw-data reproduction, does not read third-party corpora, and does
not construct raw graphs. The check uses byte-for-byte comparison and records
no content digest.
